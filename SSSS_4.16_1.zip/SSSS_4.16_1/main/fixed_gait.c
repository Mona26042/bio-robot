/*
 * fixed_gait.c
 *
 * 固定步态演示模块。
 * 该模块把左前腿 1~4 号舵机组织成一组关键帧序列，通过插值和平滑过渡，
 * 形成一次可重复、较平滑的“固定步态”演示。
 *
 * 设计目标：
 * 1. 所有目标位置都先经过软件限位裁剪，避免超出机械安全范围。
 * 2. 每个关键帧既包含姿态，也包含该姿态应该保持多久。
 * 3. 采用单独任务执行，避免阻塞主控制循环。
 */

#include "fixed_gait.h"

#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "esp_log.h"

#include "servo_protocol.h"
#include "servo_control.h"

static const char *TAG = "FIXED_GAIT";

// 一个关键帧描述“左前腿在某一阶段应该摆成什么姿态，以及停留多久”。
typedef struct {
    int16_t lf1;           // 左前腿第 1 关节目标位置
    int16_t lf2;           // 左前腿第 2 关节目标位置
    int16_t lf3;           // 左前腿第 3 关节目标位置
    int16_t lf4;           // 左前腿第 4 关节目标位置
    uint32_t hold_time_ms; // 到达该帧后保持的时间
    const char *phase_name;// 仅用于日志和调试显示
} gait_keyframe_t;

// 固定步态关键帧。
// 这些值是“演示用动作”，不是通用行走算法；重点是姿态自然、过程平滑、
// 并且始终处于软件限位允许范围内。
// 当前左前腿四个关节的安全范围如下：
//   LF1: 1700-2700
//   LF2: 700-3000
//   LF3: 800-3500
//   LF4: 900-3100
static const gait_keyframe_t s_fixed_gait_frames[] =  {
    // 起始准备姿态：腿保持在较稳定、靠近默认站姿的位置。
    {2155, 1036, 3346, 2042, 1676, "起始准备"},
    // 抬腿预备：为摆腿腾出空间。
    {1990, 1167, 3087, 2459, 1752, "抬腿预备"},
    // 前摆阶段：把腿向前送出，为后续落地做准备。
    {1997, 1911, 2389, 2275, 1372, "前摆"},
    // 推进阶段：让腿从支撑位向后推，模拟推动身体前进。
    {2122, 2002, 2199, 1981, 1386, "推进"},
    // 收腿阶段：准备回到起始姿态，完成一个完整步态循环。
    {2120, 1018, 3164, 2024, 1369, "收腿"},
    // 回到起点，便于下一次演示从稳定姿态开始。
    {2155, 1036, 3346, 2042, 1676, "回到起始"},
};

// 任务句柄用于防止重复启动。
static TaskHandle_t s_fixed_gait_task_handle = NULL;

#define INTERPOLATION_STEPS 5

// 在两个关键帧之间做线性插值，生成中间过渡帧。
static void interpolate_keyframes(const gait_keyframe_t *kf_start, const gait_keyframe_t *kf_end,
                                  gait_keyframe_t *kf_out, float t)
{
    // t 取值范围是 [0.0, 1.0]。
    // t=0 表示完全使用起点关键帧，t=1 表示完全使用终点关键帧。
    float inv_t = 1.0f - t;

    kf_out->lf1 = (int16_t)(kf_start->lf1 * inv_t + kf_end->lf1 * t);
    kf_out->lf2 = (int16_t)(kf_start->lf2 * inv_t + kf_end->lf2 * t);
    kf_out->lf3 = (int16_t)(kf_start->lf3 * inv_t + kf_end->lf3 * t);
    kf_out->lf4 = (int16_t)(kf_start->lf4 * inv_t + kf_end->lf4 * t);

    // 过渡帧最终要进入 kf_end，因此保持时间和名称沿用目标帧信息。
    kf_out->hold_time_ms = kf_end->hold_time_ms;
    kf_out->phase_name = kf_end->phase_name;
}

// 把一个关键帧下发到 1~4 号舵机。
static void apply_keyframe(const gait_keyframe_t *kf)
{
    uint8_t id_list[4]     = {1, 2, 3, 4};
    int16_t positions[4]   = {kf->lf1, kf->lf2, kf->lf3, kf->lf4};

    // 演示动作选用较高速度和中等加速度，保证过渡明显但不至于太暴力。
    uint16_t speeds[4]     = {3000, 3000, 3000, 3000};
    uint8_t accs[4]        = {60, 60, 60, 60};

    // 即使关键帧表本身已经按限位设计，这里仍然再次裁剪，避免后续改表时越界。
    for (int i = 0; i < 4; ++i) {
        positions[i] = limit_servo_position(id_list[i], positions[i]);
    }

    SyncWritePosEx(id_list, 4, positions, speeds, accs);
}

// 固定步态后台任务。
// 任务顺序是：首帧直接到位，其余关键帧通过插值平滑过渡。
static void fixed_gait_task(void *arg)
{
    (void)arg;

    const size_t frame_count = sizeof(s_fixed_gait_frames) / sizeof(s_fixed_gait_frames[0]);
    gait_keyframe_t interpolated_frame;

    // 依次执行所有关键帧。
    for (size_t i = 0; i < frame_count; ++i) {
        if (i == 0) {
            // 第一帧直接下发，作为整段动作的起点。
            apply_keyframe(&s_fixed_gait_frames[i]);
            vTaskDelay(pdMS_TO_TICKS(s_fixed_gait_frames[i].hold_time_ms));
        } else {
            // 从上一帧平滑过渡到当前帧。
            const gait_keyframe_t *kf_prev = &s_fixed_gait_frames[i - 1];
            const gait_keyframe_t *kf_curr = &s_fixed_gait_frames[i];

            // 目标帧的保持时间被拆分成若干个插值步长。
            uint32_t transition_time_ms = kf_curr->hold_time_ms / INTERPOLATION_STEPS;
            if (transition_time_ms < 5) {
                // 延时过短时，舵机可能来不及响应；这里设置一个最小值兜底。
                transition_time_ms = 5;
            }

            // 使用 smoothstep 做缓动，让速度变化更自然，减轻“生硬拐点”。
            for (int step = 1; step <= INTERPOLATION_STEPS; step++) {
                float t = (float)step / (float)INTERPOLATION_STEPS;

                // smoothstep: 3t^2 - 2t^3
                float smooth_t = t * t * (3.0f - 2.0f * t);

                interpolate_keyframes(kf_prev, kf_curr, &interpolated_frame, smooth_t);
                apply_keyframe(&interpolated_frame);
                vTaskDelay(pdMS_TO_TICKS(transition_time_ms));
            }
        }
    }

    s_fixed_gait_task_handle = NULL;
    vTaskDelete(NULL);
}

// 对外启动入口。
void fixed_gait_start(void)
{
    // 如果任务已在运行，就不重复创建，避免两套关键帧互相打架。
    if (s_fixed_gait_task_handle != NULL) {
        ESP_LOGW(TAG, "[固定步态] 任务已在运行中，忽略本次启动请求");
        return;
    }

    BaseType_t ret = xTaskCreate(
        fixed_gait_task,
        "fixed_gait_task",
        4096,
        NULL,
        5,
        &s_fixed_gait_task_handle
    );

    if (ret != pdPASS) {
        ESP_LOGE(TAG, "[固定步态] 创建任务失败");
        s_fixed_gait_task_handle = NULL;
    } else {
        // 成功时无需额外动作，任务会在自身结束时清空句柄。
    }
}
