/*
 * main.c
 * 系统主入口与核心控制任务。
 * 负责初始化 NVS、UART、Wi-Fi、Web 服务，并在控制任务中统一调度网页命令、
 * 录制/复现状态机、角度读取以及演示动作。
 */

#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "esp_log.h"
#include "nvs_flash.h"
#include <inttypes.h>
#include <stdio.h>
#include <string.h>

#include "common.h"
#include "fixed_gait.h"
#include "motion_storage.h"
#include "servo_control.h"
#include "servo_motion.h"
#include "servo_protocol.h"
#include "uart_servo.h"
#include "web_server.h"
#include "wifi_ctrl.h"

static const char *TAG __attribute__((unused)) = "STS_WEB";
static const uint32_t looptime_ms = 50;

// 统一描述“某个网页滑块更新对应哪个舵机接口”。
// 这样主循环可以用一段通用逻辑处理所有待下发的位置。
typedef void (*servo_setter_fn_t)(int16_t position);

// 每个表项对应一个网页滑块目标值。
// need_update 为 true 时，表示网页线程已经写入了新的目标位置，
// 主控制任务需要调用 setter 真正下发命令。
typedef struct {
    volatile bool *need_update;
    volatile int16_t *target_position;
    servo_setter_fn_t setter;
} pending_servo_update_t;

// 网页滑块和实际舵机写入函数之间的映射表。
static const pending_servo_update_t s_pending_servo_updates[] = {
    {&g_need_update_pos1, &g_target_position, set_servo_position},
    {&g_need_update_pos2, &g_target_position_2, set_servo_position_2},
    {&g_need_update_pos3, &g_target_position_3, set_servo_position_3},
    {&g_need_update_pos4, &g_target_position_4, set_servo_position_4},
    {&g_need_update_pos6, &g_target_position_6, set_servo_position_6},
    {&g_need_update_pos7, &g_target_position_7, set_servo_position_7},
    {&g_need_update_pos8, &g_target_position_8, set_servo_position_8},
    {&g_need_update_pos9, &g_target_position_9, set_servo_position_9},
    {&g_need_update_pos11, &g_target_position_11, set_servo_position_11},
    {&g_need_update_pos12, &g_target_position_12, set_servo_position_12},
    {&g_need_update_pos13, &g_target_position_13, set_servo_position_13},
    {&g_need_update_pos14, &g_target_position_14, set_servo_position_14},
    {&g_need_update_pos16, &g_target_position_16, set_servo_position_16},
    {&g_need_update_pos17, &g_target_position_17, set_servo_position_17},
    {&g_need_update_pos18, &g_target_position_18, set_servo_position_18},
    {&g_need_update_pos19, &g_target_position_19, set_servo_position_19},
};

typedef struct {
    uint8_t leg_num;
    const char *id_range_text;
    volatile bool *record_mode;
    volatile bool *replay_mode;
    uint16_t *record_frame_count;
    uint16_t *replay_frame_index;
    servo_cmd_t record_cmd;
    servo_cmd_t replay_cmd;
} leg_mode_binding_t;

static const leg_mode_binding_t s_leg_mode_bindings[] = {
    {1, "1-5", &g_record_leg1_mode, &g_replay_leg1_mode, &recorded_frame_count_leg1, &replay_frame_index_leg1, CMD_RECORD_LEG1, CMD_REPLAY_LEG1},
    {2, "6-10", &g_record_leg2_mode, &g_replay_leg2_mode, &recorded_frame_count_leg2, &replay_frame_index_leg2, CMD_RECORD_LEG2, CMD_REPLAY_LEG2},
    {3, "11-15", &g_record_leg3_mode, &g_replay_leg3_mode, &recorded_frame_count_leg3, &replay_frame_index_leg3, CMD_RECORD_LEG3, CMD_REPLAY_LEG3},
    {4, "16-20", &g_record_leg4_mode, &g_replay_leg4_mode, &recorded_frame_count_leg4, &replay_frame_index_leg4, CMD_RECORD_LEG4, CMD_REPLAY_LEG4},
};

static void start_leg_record_mode(uint8_t leg_num, const char *id_range_text);
static void stop_leg_record_mode(uint8_t leg_num, uint16_t frame_count);
static void stop_leg_replay_mode(uint8_t leg_num, volatile bool *replay_mode, uint16_t *frame_index);

static const leg_mode_binding_t *find_leg_binding_by_cmd(servo_cmd_t cmd)
{
    for (size_t i = 0; i < sizeof(s_leg_mode_bindings) / sizeof(s_leg_mode_bindings[0]); ++i) {
        const leg_mode_binding_t *binding = &s_leg_mode_bindings[i];

        if (binding->record_cmd == cmd || binding->replay_cmd == cmd) {
            return binding;
        }
    }

    return NULL;
}

static bool has_active_leg_modes(bool replay_mode)
{
    for (size_t i = 0; i < sizeof(s_leg_mode_bindings) / sizeof(s_leg_mode_bindings[0]); ++i) {
        volatile bool *mode = replay_mode ?
            s_leg_mode_bindings[i].replay_mode :
            s_leg_mode_bindings[i].record_mode;

        if (*mode) {
            return true;
        }
    }

    return false;
}

static void replay_active_leg_frames(void)
{
    for (size_t i = 0; i < sizeof(s_leg_mode_bindings) / sizeof(s_leg_mode_bindings[0]); ++i) {
        if (*s_leg_mode_bindings[i].replay_mode) {
            replay_leg_motion_next_frame(s_leg_mode_bindings[i].leg_num);
        }
    }
}

static void save_active_leg_frames(void)
{
    for (size_t i = 0; i < sizeof(s_leg_mode_bindings) / sizeof(s_leg_mode_bindings[0]); ++i) {
        if (*s_leg_mode_bindings[i].record_mode) {
            save_current_leg_frame(s_leg_mode_bindings[i].leg_num);
        }
    }
}

static bool stop_leg_replay_for_cmd(servo_cmd_t cmd)
{
    const leg_mode_binding_t *binding = find_leg_binding_by_cmd(cmd);

    if (binding == NULL || binding->replay_cmd != cmd) {
        return false;
    }

    stop_leg_replay_mode(binding->leg_num, binding->replay_mode, binding->replay_frame_index);
    return true;
}

static bool stop_leg_record_for_cmd(servo_cmd_t cmd)
{
    const leg_mode_binding_t *binding = find_leg_binding_by_cmd(cmd);

    if (binding == NULL || binding->record_cmd != cmd) {
        return false;
    }

    *binding->record_mode = false;
    stop_leg_record_mode(binding->leg_num, *binding->record_frame_count);
    return true;
}

static bool toggle_leg_record_for_cmd(servo_cmd_t cmd)
{
    const leg_mode_binding_t *binding = find_leg_binding_by_cmd(cmd);

    if (binding == NULL || binding->record_cmd != cmd) {
        return false;
    }

    *binding->record_mode = !*binding->record_mode;
    if (*binding->record_mode) {
        start_leg_record_mode(binding->leg_num, binding->id_range_text);
    } else {
        stop_leg_record_mode(binding->leg_num, *binding->record_frame_count);
    }

    return true;
}

static bool toggle_leg_replay_for_cmd(servo_cmd_t cmd)
{
    const leg_mode_binding_t *binding = find_leg_binding_by_cmd(cmd);

    if (binding == NULL || binding->replay_cmd != cmd) {
        return false;
    }

    if (*binding->replay_mode) {
        stop_leg_replay_mode(binding->leg_num, binding->replay_mode, binding->replay_frame_index);
    } else {
        start_replay_leg_motion(binding->leg_num);
    }

    return true;
}

// 同时刷新网页上的“当前工作状态”和主提示文本。

// 统一更新网页显示区的状态文本。
// 统一刷新网页状态区显示的工作文本和提示文本。
// 所有模式切换、录制结束、回放停止这类状态变更都尽量走这里，避免到处散落 snprintf 逻辑。
static void set_status_text(const char *work_text, const char *message_text)
{
    snprintf(work, sizeof(work), "%s", work_text);
    snprintf(message0, sizeof(message0), "%s", message_text);
}

// 进入单腿录入时：
// 1. 清空这条腿已有录制数据
// 2. 只关闭这条腿自己的 5 个舵机扭矩
// 3. 方便用户直接拖动当前腿做单腿录入
// 进入“单腿录制”时的公共初始化逻辑。
// 包括清空旧录制、关闭该腿扭矩、刷新当前角度缓存等步骤。
// 进入单腿录制模式时先清空旧数据，再关闭该腿扭矩，最后读取一次当前位置作为录制基线。
// 这样用户手动掰动这条腿时不会被舵机反扭，同时网页状态和串口日志也能马上反映当前录制对象。
// 单腿录入时只释放当前腿自己的 5 个舵机。
// 例如腿 1 只处理 1~5 号，不再额外处理 2/3/7/8/12/13/17/18 这些关节。
static void start_leg_record_mode(uint8_t leg_num, const char *id_range_text)
{
    clear_recorded_leg_motion(leg_num);
    lock_off_leg(leg_num);
    snprintf(work, sizeof(work), "Leg%u rec on", (unsigned)leg_num);
    snprintf(message0, sizeof(message0), "Leg%u record enabled", (unsigned)leg_num);
    snprintf(message1, sizeof(message1), "仅释放当前腿 ID %s", id_range_text);
    sync_read_once();
    printf("[record leg%u] start - IDs %s\n", (unsigned)leg_num, id_range_text);
}

// 结束录入后只恢复当前腿自己的扭矩。
// 退出“单腿录制”时的公共收尾逻辑。
// 退出单腿录制模式时重新给这条腿上扭矩，并把最终录到的帧数写到状态栏。
// 这里不负责保存帧本身，帧数据已经在录制循环中持续写入数组。
// 结束单腿录入时，也只恢复当前腿自己的扭矩状态。
static void stop_leg_record_mode(uint8_t leg_num, uint16_t frame_count)
{
    lock_on_leg(leg_num);
    snprintf(work, sizeof(work), "Leg%u rec off", (unsigned)leg_num);
    snprintf(message0, sizeof(message0), "Leg%u record stop: %u", (unsigned)leg_num, (unsigned)frame_count);
    snprintf(message1, sizeof(message1), "仅恢复当前腿扭矩");
    printf("[record leg%u] stop - %u frames\n", (unsigned)leg_num, (unsigned)frame_count);
}

// 停止单腿复现时，清掉复现标志和当前帧索引。
// 停止某条腿的回放，并清空对应回放索引。
// 停止单腿回放时需要同时清掉模式标志和帧索引。
// 如果只关模式不清索引，下次再次开始回放时就会从中间帧继续，导致动作看起来像“断点续播”。
static void stop_leg_replay_mode(uint8_t leg_num, volatile bool *replay_mode, uint16_t *frame_index)
{
    *replay_mode = false;
    *frame_index = 0;
    snprintf(work, sizeof(work), "Leg%u replay off", (unsigned)leg_num);
    snprintf(message0, sizeof(message0), "Leg%u replay stopped", (unsigned)leg_num);
}

// 停止预定义动作 1 的循环复现。
// 停止“教学回放 1”模式。
// 停止教学回放封装成单独函数，便于把“状态复位”和“界面提示”绑定在一起处理。
static void stop_motion1_replay_mode(void)
{
    reset_teach_replay_state();
    set_status_text("Teach replay stop", "Teach replay stopped");
}

// 网页滑块只是置位“待更新”标志，真正写舵机在这里统一执行。
// 把网页线程提交的“待更新位置”真正下发给舵机。
// 网页滑块不会直接在 HTTP 回调里下发串口命令，而是先把目标值写入共享变量。
// 主控制任务在这里统一消费这些待更新目标，避免网络线程和控制线程同时访问舵机总线。
static void update_pending_servo_targets(void)
{
    for (size_t i = 0; i < sizeof(s_pending_servo_updates) / sizeof(s_pending_servo_updates[0]); ++i) {
        if (*s_pending_servo_updates[i].need_update) {
            s_pending_servo_updates[i].setter(*s_pending_servo_updates[i].target_position);
            *s_pending_servo_updates[i].need_update = false;
        }
    }
}

// 判断当前是否还有未真正下发到舵机的位置命令。
// 查询当前是否存在尚未下发到舵机的位置更新。
// 快速判断是否存在待下发的滑块目标值。
// 主循环用它决定是否需要调用 update_pending_servo_targets，以及是否允许状态栏回到 idle。
static bool has_pending_servo_updates(void)
{
    for (size_t i = 0; i < sizeof(s_pending_servo_updates) / sizeof(s_pending_servo_updates[0]); ++i) {
        if (*s_pending_servo_updates[i].need_update) {
            return true;
        }
    }

    return false;
}

static bool should_show_idle_status(void)
{
    return g_cmd == CMD_NONE &&
           !has_pending_servo_updates() &&
           !g_read_angle_mode &&
           !has_active_leg_modes(false) &&
           !has_active_leg_modes(true) &&
           !g_record_full_mode &&
           !g_replay_full_mode &&
           !g_replay_full_transition_mode &&
           !g_replay_motion1_mode &&
           g_servo1_motion_state == SERVO_MOTION_IDLE &&
           g_servo2_motion_state == SERVO_MOTION_IDLE &&
           g_dual_rotate_state == DUAL_ROTATE_IDLE;
}

// 主控制任务按优先级执行：
// 预定义动作复现 > 单腿复现 > 单腿录入 > 读角度 > 普通网页命令。
// 主控制任务。
// 这是整个工程的“调度中心”：网页命令、录制/回放、固定步态、角度读取、
// 以及滑块位置更新都会在这里被统一串行处理。
// 系统核心控制任务：按优先级处理“动作过渡回放 > 整体回放 > 教学回放 > 单腿回放 > 录制 > 读角度 > 普通命令”。
// 这样做的目的，是保证正在进行的连续动作不会被普通按钮命令意外打断，同时仍保留显式停止入口。
static void servo_control_task(void *arg)
{
    (void)arg;

    setEnd(0);

    static TickType_t last_read_time = 0;
    const TickType_t read_interval_ticks = pdMS_TO_TICKS(100);

    while (true) {
                // 先处理整套动作的“平滑衔接阶段”。
        // 这里负责把当前姿态逐步过渡到录制动作首帧，避免直接切入整套动作时出现大幅度跳变。
        if (g_replay_full_transition_mode) {
            static TickType_t last_replay_full_transition_time = 0;
            TickType_t current_time = xTaskGetTickCount();
            const TickType_t replay_interval_ticks =
                pdMS_TO_TICKS(get_full_motion_replay_wait_ms());

            if (last_replay_full_transition_time == 0 ||
                (current_time - last_replay_full_transition_time >= replay_interval_ticks)) {
                replay_full_motion_transition_next_frame();
                last_replay_full_transition_time = current_time;
            }

            if (!g_replay_full_transition_mode) {
                last_replay_full_transition_time = 0;
            }

            servo_cmd_t cmd = g_cmd;
            if (cmd != CMD_NONE) {
                g_cmd = CMD_NONE;
                if (cmd == CMD_REPLAY_FULL) {
                    stop_replay_full_motion();
                }
            }

            blink++;
            vTaskDelay(pdMS_TO_TICKS(looptime_ms));
            continue;
        }

                // 过渡结束后进入完整动作回放。
        // 每次只推进一帧，并根据录制下来的帧间隔决定下一帧何时发送。
        if (g_replay_full_mode) {
            static TickType_t last_replay_full_time = 0;
            TickType_t current_time = xTaskGetTickCount();
            const TickType_t replay_interval_ticks =
                pdMS_TO_TICKS(get_full_motion_replay_wait_ms());

            if (last_replay_full_time == 0 ||
                (current_time - last_replay_full_time >= replay_interval_ticks)) {
                replay_full_motion_next_frame();
                last_replay_full_time = current_time;
            }

            if (!g_replay_full_mode) {
                last_replay_full_time = 0;
            }

            servo_cmd_t cmd = g_cmd;
            if (cmd != CMD_NONE) {
                g_cmd = CMD_NONE;
                if (cmd == CMD_REPLAY_FULL) {
                    stop_replay_full_motion();
                }
            }

            blink++;
            vTaskDelay(pdMS_TO_TICKS(looptime_ms));
            continue;
        }
        // 最高优先级：预定义动作 1 复现时，只维持该动作并允许停止。
                // 教学回放模式会按预定义顺序依次播放几条腿的录制数据。
        // 这里保持独立节拍，让教学演示不会被普通轮询逻辑打乱。
        if (g_replay_motion1_mode) {
            static TickType_t last_replay_motion1_time = 0;
            const TickType_t replay_interval_ticks = pdMS_TO_TICKS(200);
            TickType_t current_time = xTaskGetTickCount();

            if (last_replay_motion1_time == 0 ||
                (current_time - last_replay_motion1_time >= replay_interval_ticks)) {
                replay_teach_next_frame();
                last_replay_motion1_time = current_time;
            }

            if (!g_replay_motion1_mode) {
                last_replay_motion1_time = 0;
            }

            servo_cmd_t cmd = g_cmd;
            if (cmd != CMD_NONE) {
                g_cmd = CMD_NONE;
                if (cmd == CMD_REPLAY_MOTION1) {
                    stop_motion1_replay_mode();
                }
            }

            blink++;
            vTaskDelay(pdMS_TO_TICKS(looptime_ms));
            continue;
        }

        // 第二优先级：任意一条腿正在复现时，按固定时间间隔推进下一帧。
                // 如果任意一条腿处于单独回放状态，就进入按腿分发的回放分支。
        // 这里允许多条腿同时回放，因此会逐个检查对应模式标志并分别推进各自帧索引。
        bool any_leg_replaying = g_replay_leg1_mode || g_replay_leg2_mode ||
                                 g_replay_leg3_mode || g_replay_leg4_mode;
        if (any_leg_replaying) {
            static TickType_t last_replay_time = 0;
            const TickType_t replay_interval_ticks = pdMS_TO_TICKS(200);
            TickType_t current_time = xTaskGetTickCount();

            if (last_replay_time == 0 || (current_time - last_replay_time >= replay_interval_ticks)) {
                replay_active_leg_frames();
                last_replay_time = current_time;
            }

            servo_cmd_t cmd = g_cmd;
            if (cmd != CMD_NONE) {
                g_cmd = CMD_NONE;
                (void)stop_leg_replay_for_cmd(cmd);
            }

            any_leg_replaying = has_active_leg_modes(true);
            if (!any_leg_replaying) {
                last_replay_time = 0;
            }

            blink++;
            vTaskDelay(pdMS_TO_TICKS(looptime_ms));
            continue;
        }

        // 第三优先级：录入模式下周期性读取当前角度并存入动作序列。
                // 录制模式的核心工作是“定时读当前位置 + 追加到录制数组”。
        // 整体录制和单腿录制可以并存，所以这里会在同一次采样中分别保存不同粒度的数据。
        bool any_leg_recording = has_active_leg_modes(false);
        bool any_recording = g_record_full_mode || any_leg_recording;
        if (any_recording) {
            TickType_t current_time = xTaskGetTickCount();
            if (last_read_time == 0 || (current_time - last_read_time >= read_interval_ticks)) {
                TickType_t sample_dt_ticks = read_interval_ticks;
                if (last_read_time != 0) {
                    sample_dt_ticks = current_time - last_read_time;
                    if (sample_dt_ticks > pdMS_TO_TICKS(1000)) {
                        sample_dt_ticks = read_interval_ticks;
                    }
                }
                uint16_t sample_dt_ms = (uint16_t)pdTICKS_TO_MS(sample_dt_ticks);
                sync_read_once();
                if (g_record_full_mode) {
                    save_current_full_frame(sample_dt_ms);
                }
                save_active_leg_frames();
                last_read_time = current_time;
            }

            servo_cmd_t cmd = g_cmd;
            if (cmd != CMD_NONE) {
                g_cmd = CMD_NONE;
                if (cmd == CMD_RECORD_FULL) {
                    stop_record_full_motion();
                } else {
                    (void)stop_leg_record_for_cmd(cmd);
                }
            }

            blink++;
            vTaskDelay(pdMS_TO_TICKS(looptime_ms));
            continue;
        }

        // 读角度模式只刷新反馈值，不执行其他运动命令。
                // 读角度模式只做周期性同步读取，不主动发位置命令。
        // 这个模式主要用于校准和观察当前姿态，因此节奏上比动作回放简单很多。
        if (g_read_angle_mode) {
            TickType_t current_time = xTaskGetTickCount();
            if (current_time - last_read_time >= read_interval_ticks) {
                sync_read_once();
                last_read_time = current_time;
            }

            servo_cmd_t cmd = g_cmd;
            if (cmd != CMD_NONE) {
                g_cmd = CMD_NONE;
                if (cmd == CMD_READ_ANGLE_MODE) {
                    g_read_angle_mode = false;
                    set_status_text("Read angle off", "Read angle mode disabled");
                }
            }

            blink++;
            vTaskDelay(pdMS_TO_TICKS(looptime_ms));
            continue;
        }

        // 常规网页命令入口：锁扭矩、录入、复现、固定步态等都从这里分发。
        servo_cmd_t cmd = g_cmd;
        if (cmd != CMD_NONE) {
            g_cmd = CMD_NONE;

                        // 进入普通命令分发区。
            // 只有当前没有更高优先级的连续任务占用主循环时，网页按钮命令才会在这里被执行。
            switch (cmd) {
                case CMD_LOCK_ON:
                    lock_on_all();
                    break;
                case CMD_LOCK_OFF:
                    lock_off_all();
                    break;
                case CMD_LOCK_LEG1:
                    lock_toggle_leg(1);
                    break;
                case CMD_LOCK_LEG2:
                    lock_toggle_leg(2);
                    break;
                case CMD_LOCK_LEG3:
                    lock_toggle_leg(3);
                    break;
                case CMD_LOCK_LEG4:
                    lock_toggle_leg(4);
                    break;
                case CMD_RESTORE_POSE:
                    restore_default_pose();
                    break;
                case CMD_SYNC_READ:
                    sync_read_once();
                    break;
                case CMD_WRITE_SHOW:
                    start_servo1_demo();
                    break;
                case CMD_PING_ID1:
                    ping_servo_id_1();
                    break;
                case CMD_WRITE_SHOW_2:
                    start_servo2_demo();
                    break;
                case CMD_SET_POSITION:
                    set_servo_position(g_target_position);
                    break;
                case CMD_SET_POSITION_2:
                    set_servo_position_2(g_target_position_2);
                    break;
                case CMD_SET_POSITION_SYNC:
                    set_servo_positions_sync(g_target_position, g_target_position_2);
                    break;
                case CMD_DUAL_SERVO_ROTATE:
                    start_dual_servo_rotate();
                    break;
                case CMD_FIXED_GAIT:
                    fixed_gait_start();
                    set_status_text("Fixed gait", "Fixed gait started");
                    break;
                case CMD_READ_ANGLE_MODE:
                    g_read_angle_mode = !g_read_angle_mode;
                    if (g_read_angle_mode) {
                        set_status_text("Read angle on", "Read angle mode enabled");
                    } else {
                        set_status_text("Read angle off", "Read angle mode disabled");
                    }
                    break;
                case CMD_RECORD_LEG1:
                case CMD_RECORD_LEG2:
                case CMD_RECORD_LEG3:
                case CMD_RECORD_LEG4:
                    (void)toggle_leg_record_for_cmd(cmd);
                    break;
                case CMD_RECORD_FULL:
                    g_record_full_mode = !g_record_full_mode;
                    if (g_record_full_mode) {
                        start_record_full_motion();
                    } else {
                        stop_record_full_motion();
                    }
                    break;
                case CMD_REPLAY_LEG1:
                case CMD_REPLAY_LEG2:
                case CMD_REPLAY_LEG3:
                case CMD_REPLAY_LEG4:
                    (void)toggle_leg_replay_for_cmd(cmd);
                    break;
                case CMD_REPLAY_MOTION1:
                    if (g_replay_motion1_mode) {
                        stop_motion1_replay_mode();
                    } else {
                        start_teach_replay();
                    }
                    break;
                case CMD_REPLAY_FULL:
                    if (g_replay_full_mode) {
                        stop_replay_full_motion();
                    } else {
                        start_replay_full_motion();
                    }
                    break;
                case CMD_SAVE_FULL_TO_STORAGE: {
                    char saved_name[FULL_MOTION_NAME_MAX_LEN];
                    uint32_t saved_checksum = 0;
                    esp_err_t err = motion_storage_save_current_full_motion(
                        saved_name,
                        sizeof(saved_name),
                        &saved_checksum);

                    if (err == ESP_OK) {
                        snprintf(work, sizeof(work), "Motion saved");
                        snprintf(message0, sizeof(message0), "Saved: %s", saved_name);
                        snprintf(message1, sizeof(message1), "hash=%08" PRIX32, saved_checksum);
                    } else {
                        snprintf(work, sizeof(work), "Motion save fail");
                        snprintf(message0, sizeof(message0), "Save failed");
                        snprintf(message1, sizeof(message1), "%s", esp_err_to_name(err));
                    }
                    break;
                }
                case CMD_LOAD_AND_REPLAY_FULL_FROM_STORAGE: {
                    uint32_t loaded_checksum = 0;
                    esp_err_t err = motion_storage_load_full_motion(
                        g_motion_storage_target_name,
                        &loaded_checksum);

                    if (err == ESP_OK) {
                        snprintf(work, sizeof(work), "Motion replay");
                        snprintf(message0, sizeof(message0), "Loaded: %s", g_motion_storage_target_name);
                        snprintf(message1, sizeof(message1), "hash=%08" PRIX32, loaded_checksum);
                        start_replay_full_motion();
                    } else {
                        snprintf(work, sizeof(work), "Motion load fail");
                        snprintf(message0, sizeof(message0), "Load failed");
                        snprintf(message1, sizeof(message1), "%s", esp_err_to_name(err));
                    }
                    break;
                }
                case CMD_NONE:
                default:
                    break;
            }
        }

        // 把网页端累计的单舵机目标位置真正下发到总线。
                // 在普通命令之后补发滑块产生的单舵机目标值。
        // 这样可以保证页面拖动滑块时，位置更新仍由同一个控制任务串行地下发。
        if (has_pending_servo_updates()) {
            update_pending_servo_targets();
        }

        // 维护非阻塞动作状态机。
                // 更新演示动作和双舵机联动这类内部状态机。
        // 它们本质上也是“随时间推进”的逻辑，所以每个主循环周期都要轮询一次。
        update_servo_motion_state();
        update_dual_rotate_state();

        // 没有待执行命令时，更新为空闲状态。
                // 当没有待处理命令、也没有待发送位置时，把状态栏恢复为 idle。
        // 这样网页能明确反映当前系统处于空闲等待状态，而不是保留上一次动作名称。
        if (should_show_idle_status() && strcmp(work, "System idle") != 0) {
            set_status_text("System idle", "System idle");
        }

        blink++;
        vTaskDelay(pdMS_TO_TICKS(looptime_ms));
    }
}

// 应用入口：完成底层初始化，并启动统一的舵机控制任务。
// 应用入口。
// 完成 NVS、UART、Wi-Fi、Web 服务和主控制任务的初始化。
// ESP-IDF 应用入口：先初始化 NVS、串口、Wi-Fi 和 Web 服务，再启动舵机控制任务。
// 真正的控制逻辑都跑在 servo_control_task 中，这里更像系统启动编排器。
void app_main(void)
{
    esp_err_t nvs_err = nvs_flash_init();
    if (nvs_err == ESP_ERR_NVS_NO_FREE_PAGES || nvs_err == ESP_ERR_NVS_NEW_VERSION_FOUND) {
        ESP_ERROR_CHECK(nvs_flash_erase());
        nvs_err = nvs_flash_init();
    }
    ESP_ERROR_CHECK(nvs_err);

    ESP_LOGI(TAG, "Initializing servo UART");
    servo_uart_init();

    ESP_LOGI(TAG, "Initializing Wi-Fi AP");
    wifi_init_ap();

    ESP_LOGI(TAG, "Starting web server");
    httpd_handle_t web_server = start_webserver();
    if (web_server == NULL) {
        ESP_LOGW(TAG, "Web server failed to start");
    } else {
        ESP_LOGI(TAG, "Web server started");
    }

    ESP_LOGI(TAG, "Initializing motion storage");
    esp_err_t motion_storage_err = motion_storage_init();
    if (motion_storage_err != ESP_OK) {
        ESP_LOGW(TAG, "Motion storage init failed, Wi-Fi/Web stay available: %s",
                 esp_err_to_name(motion_storage_err));
        snprintf(message0, sizeof(message0), "Motion storage init failed");
        snprintf(message1, sizeof(message1), "%s", esp_err_to_name(motion_storage_err));
    } else {
        ESP_LOGI(TAG, "Motion storage ready");
    }

    ESP_LOGI(TAG, "Starting servo control task");
    xTaskCreate(servo_control_task, "servo_ctrl", 6144, NULL, 5, NULL);
}
