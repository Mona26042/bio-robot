#include "motion_storage.h"

#include <ctype.h>
#include <dirent.h>
#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "esp_log.h"
#include "esp_spiffs.h"
#include "freertos/FreeRTOS.h"
#include "freertos/semphr.h"

#include "common.h"

#define MOTION_STORAGE_BASE_PATH "/spiffs"
#define MOTION_STORAGE_FILE_EXT ".json"
#define MOTION_STORAGE_LEGACY_FILE_EXT ".mot"
#define MOTION_STORAGE_FORMAT "motion_v2"
#define MOTION_STORAGE_MAX_JSON_BYTES (512U * 1024U)
#define MOTION_STORAGE_METADATA_SCAN_BYTES 4096U

typedef struct {
    char name[MOTION_STORAGE_NAME_MAX_LEN];
    uint16_t frame_count;
    uint32_t total_duration_ms;
    uint32_t payload_checksum;
    int16_t (*positions)[FULL_MOTION_SERVO_COUNT];
    uint16_t *dts;
} parsed_motion_doc_t;

static const char *TAG = "MOTION_STORAGE";
static SemaphoreHandle_t s_motion_storage_mutex = NULL;
static bool s_motion_storage_ready = false;
static volatile bool s_motion_storage_busy = false;
static char s_current_motion_name[MOTION_STORAGE_NAME_MAX_LEN] = "No motion";
static int16_t s_parsed_positions[FULL_MOTION_FRAMES][FULL_MOTION_SERVO_COUNT];
static uint16_t s_parsed_dts[FULL_MOTION_FRAMES];

static bool lock_motion_storage(TickType_t timeout_ticks)
{
    return s_motion_storage_mutex != NULL &&
           xSemaphoreTake(s_motion_storage_mutex, timeout_ticks) == pdTRUE;
}

static void unlock_motion_storage(void)
{
    if (s_motion_storage_mutex != NULL) {
        xSemaphoreGive(s_motion_storage_mutex);
    }
}

static uint32_t checksum_update(uint32_t checksum, const void *data, size_t len)
{
    const uint8_t *bytes = (const uint8_t *)data;

    for (size_t i = 0; i < len; ++i) {
        checksum ^= bytes[i];
        checksum *= 16777619u;
    }

    return checksum;
}

static bool has_file_extension(const char *filename, const char *extension)
{
    if (filename == NULL || extension == NULL) {
        return false;
    }

    const size_t filename_len = strlen(filename);
    const size_t ext_len = strlen(extension);

    return filename_len > ext_len &&
           strcmp(filename + filename_len - ext_len, extension) == 0;
}

static bool has_motion_file_extension(const char *filename)
{
    return has_file_extension(filename, MOTION_STORAGE_FILE_EXT);
}

static bool has_legacy_motion_file_extension(const char *filename)
{
    return has_file_extension(filename, MOTION_STORAGE_LEGACY_FILE_EXT);
}

static void extract_motion_name(const char *filename, char *name_buf, size_t name_buf_len)
{
    if (name_buf == NULL || name_buf_len == 0) {
        return;
    }

    name_buf[0] = '\0';
    if (filename == NULL) {
        return;
    }

    const char *dot = strrchr(filename, '.');
    const size_t copy_len = (dot != NULL) ? (size_t)(dot - filename) : strlen(filename);
    snprintf(name_buf, name_buf_len, "%.*s", (int)copy_len, filename);
}

static void build_motion_path(const char *motion_name, char *path_buf, size_t path_buf_len)
{
    snprintf(path_buf, path_buf_len, "%s/%s%s",
             MOTION_STORAGE_BASE_PATH,
             motion_name,
             MOTION_STORAGE_FILE_EXT);
}

static void build_motion_path_with_ext(const char *motion_name,
                                       const char *extension,
                                       char *path_buf,
                                       size_t path_buf_len)
{
    snprintf(path_buf, path_buf_len, "%s/%s%s",
             MOTION_STORAGE_BASE_PATH,
             motion_name,
             extension);
}

static void build_motion_aux_path(const char *motion_name,
                                  const char *suffix,
                                  char *path_buf,
                                  size_t path_buf_len)
{
    snprintf(path_buf, path_buf_len, "%s/%s%s%s",
             MOTION_STORAGE_BASE_PATH,
             motion_name,
             MOTION_STORAGE_FILE_EXT,
             suffix != NULL ? suffix : "");
}

static bool is_valid_motion_name_internal(const char *motion_name)
{
    if (motion_name == NULL || motion_name[0] == '\0') {
        return false;
    }

    const size_t length = strlen(motion_name);
    if (length >= MOTION_STORAGE_NAME_MAX_LEN) {
        return false;
    }

    for (size_t i = 0; i < length; ++i) {
        const unsigned char ch = (unsigned char)motion_name[i];
        if (!(isalnum(ch) || ch == '_' || ch == '-')) {
            return false;
        }
    }

    return true;
}

static bool motion_file_exists_locked(const char *motion_name)
{
    if (!is_valid_motion_name_internal(motion_name)) {
        return false;
    }

    char path[64];
    build_motion_path(motion_name, path, sizeof(path));

    FILE *file = fopen(path, "rb");
    if (file == NULL) {
        return false;
    }

    fclose(file);
    return true;
}

static int compare_motion_info(const void *lhs, const void *rhs)
{
    const stored_motion_info_t *left = (const stored_motion_info_t *)lhs;
    const stored_motion_info_t *right = (const stored_motion_info_t *)rhs;
    return strcmp(left->name, right->name);
}

static void parsed_motion_doc_reset(parsed_motion_doc_t *doc)
{
    if (doc == NULL) {
        return;
    }

    memset(doc, 0, sizeof(*doc));
}

static bool parsed_motion_doc_alloc(parsed_motion_doc_t *doc, const char *motion_name)
{
    if (doc == NULL) {
        return false;
    }

    memset(doc, 0, sizeof(*doc));
    memset(s_parsed_positions, 0, sizeof(s_parsed_positions));
    memset(s_parsed_dts, 0, sizeof(s_parsed_dts));
    doc->positions = s_parsed_positions;
    doc->dts = s_parsed_dts;

    snprintf(doc->name,
             sizeof(doc->name),
             "%s",
             (motion_name != NULL && motion_name[0] != '\0') ? motion_name : "No motion");
    return true;
}

static void skip_json_ws(const char **cursor)
{
    while (cursor != NULL && *cursor != NULL && **cursor != '\0' &&
           isspace((unsigned char)**cursor)) {
        ++(*cursor);
    }
}

static void skip_utf8_bom(const char **cursor)
{
    if (cursor == NULL || *cursor == NULL) {
        return;
    }

    const unsigned char *bytes = (const unsigned char *)(*cursor);
    if (bytes[0] == 0xEF && bytes[1] == 0xBB && bytes[2] == 0xBF) {
        *cursor += 3;
    }
}

static bool skip_json_string(const char **cursor)
{
    if (cursor == NULL || *cursor == NULL || **cursor != '"') {
        return false;
    }

    ++(*cursor);
    while (**cursor != '\0') {
        if (**cursor == '\\') {
            ++(*cursor);
            if (**cursor == '\0') {
                return false;
            }
            if (**cursor == 'u') {
                for (int i = 0; i < 4; ++i) {
                    ++(*cursor);
                    if (!isxdigit((unsigned char)**cursor)) {
                        return false;
                    }
                }
            }
            ++(*cursor);
            continue;
        }

        if (**cursor == '"') {
            ++(*cursor);
            return true;
        }

        ++(*cursor);
    }

    return false;
}

static int hex_char_to_int(char ch)
{
    if (ch >= '0' && ch <= '9') {
        return ch - '0';
    }
    if (ch >= 'a' && ch <= 'f') {
        return 10 + (ch - 'a');
    }
    if (ch >= 'A' && ch <= 'F') {
        return 10 + (ch - 'A');
    }
    return -1;
}

static bool parse_json_string_copy(const char **cursor, char *out_buf, size_t out_buf_len)
{
    if (cursor == NULL || *cursor == NULL || **cursor != '"' ||
        out_buf == NULL || out_buf_len == 0) {
        return false;
    }

    size_t out_index = 0;
    out_buf[0] = '\0';
    ++(*cursor);

    while (**cursor != '\0') {
        char ch = **cursor;
        if (ch == '\\') {
            ++(*cursor);
            ch = **cursor;
            if (ch == '\0') {
                return false;
            }

            switch (ch) {
                case '"':
                case '\\':
                case '/':
                    break;
                case 'b':
                    ch = '\b';
                    break;
                case 'f':
                    ch = '\f';
                    break;
                case 'n':
                    ch = '\n';
                    break;
                case 'r':
                    ch = '\r';
                    break;
                case 't':
                    ch = '\t';
                    break;
                case 'u': {
                    int value = 0;
                    for (int i = 0; i < 4; ++i) {
                        ++(*cursor);
                        const int nibble = hex_char_to_int(**cursor);
                        if (nibble < 0) {
                            return false;
                        }
                        value = (value << 4) | nibble;
                    }
                    ch = (value >= 0 && value <= 0x7f) ? (char)value : '?';
                    break;
                }
                default:
                    return false;
            }
        } else if (ch == '"') {
            ++(*cursor);
            break;
        }

        if (out_index + 1 >= out_buf_len) {
            return false;
        }

        out_buf[out_index++] = ch;
        ++(*cursor);
    }

    if (**cursor == '\0' && (*cursor)[-1] != '"') {
        return false;
    }

    out_buf[out_index] = '\0';
    return true;
}

static bool parse_json_int32(const char **cursor, int32_t *out_value)
{
    if (cursor == NULL || *cursor == NULL || out_value == NULL) {
        return false;
    }

    errno = 0;
    char *end_ptr = NULL;
    long value = strtol(*cursor, &end_ptr, 10);
    if (end_ptr == *cursor || end_ptr == NULL) {
        return false;
    }

    if (errno == ERANGE || value < INT32_MIN || value > INT32_MAX) {
        return false;
    }

    if (*end_ptr == '.' || *end_ptr == 'e' || *end_ptr == 'E') {
        return false;
    }

    *out_value = (int32_t)value;
    *cursor = end_ptr;
    return true;
}

static bool parse_json_uint32(const char **cursor, uint32_t *out_value)
{
    if (cursor == NULL || *cursor == NULL || out_value == NULL) {
        return false;
    }

    if (**cursor == '-') {
        return false;
    }

    errno = 0;
    char *end_ptr = NULL;
    unsigned long value = strtoul(*cursor, &end_ptr, 10);
    if (end_ptr == *cursor || end_ptr == NULL) {
        return false;
    }

    if (errno == ERANGE || value > UINT32_MAX) {
        return false;
    }

    if (*end_ptr == '.' || *end_ptr == 'e' || *end_ptr == 'E') {
        return false;
    }

    *out_value = (uint32_t)value;
    *cursor = end_ptr;
    return true;
}

static bool skip_json_number(const char **cursor)
{
    if (cursor == NULL || *cursor == NULL) {
        return false;
    }

    const char *p = *cursor;
    if (*p == '-') {
        ++p;
    }

    if (!isdigit((unsigned char)*p)) {
        return false;
    }

    while (isdigit((unsigned char)*p)) {
        ++p;
    }

    if (*p == '.') {
        ++p;
        if (!isdigit((unsigned char)*p)) {
            return false;
        }
        while (isdigit((unsigned char)*p)) {
            ++p;
        }
    }

    if (*p == 'e' || *p == 'E') {
        ++p;
        if (*p == '+' || *p == '-') {
            ++p;
        }
        if (!isdigit((unsigned char)*p)) {
            return false;
        }
        while (isdigit((unsigned char)*p)) {
            ++p;
        }
    }

    *cursor = p;
    return true;
}

static bool skip_json_value(const char **cursor)
{
    if (cursor == NULL || *cursor == NULL) {
        return false;
    }

    skip_json_ws(cursor);
    if (**cursor == '"') {
        return skip_json_string(cursor);
    }

    if (**cursor == '{') {
        ++(*cursor);
        skip_json_ws(cursor);
        if (**cursor == '}') {
            ++(*cursor);
            return true;
        }

        while (**cursor != '\0') {
            if (!skip_json_string(cursor)) {
                return false;
            }
            skip_json_ws(cursor);
            if (**cursor != ':') {
                return false;
            }
            ++(*cursor);
            if (!skip_json_value(cursor)) {
                return false;
            }
            skip_json_ws(cursor);
            if (**cursor == ',') {
                ++(*cursor);
                skip_json_ws(cursor);
                continue;
            }
            if (**cursor == '}') {
                ++(*cursor);
                return true;
            }
            return false;
        }
        return false;
    }

    if (**cursor == '[') {
        ++(*cursor);
        skip_json_ws(cursor);
        if (**cursor == ']') {
            ++(*cursor);
            return true;
        }

        while (**cursor != '\0') {
            if (!skip_json_value(cursor)) {
                return false;
            }
            skip_json_ws(cursor);
            if (**cursor == ',') {
                ++(*cursor);
                skip_json_ws(cursor);
                continue;
            }
            if (**cursor == ']') {
                ++(*cursor);
                return true;
            }
            return false;
        }
        return false;
    }

    if (**cursor == '-' || isdigit((unsigned char)**cursor)) {
        return skip_json_number(cursor);
    }

    if (strncmp(*cursor, "true", 4) == 0) {
        *cursor += 4;
        return true;
    }
    if (strncmp(*cursor, "false", 5) == 0) {
        *cursor += 5;
        return true;
    }
    if (strncmp(*cursor, "null", 4) == 0) {
        *cursor += 4;
        return true;
    }

    return false;
}

static bool parse_frame_positions(const char **cursor, int16_t *positions)
{
    if (cursor == NULL || *cursor == NULL || positions == NULL) {
        return false;
    }

    skip_json_ws(cursor);
    if (**cursor != '[') {
        return false;
    }

    ++(*cursor);
    for (int i = 0; i < FULL_MOTION_SERVO_COUNT; ++i) {
        int32_t value = 0;
        skip_json_ws(cursor);
        if (!parse_json_int32(cursor, &value) ||
            value < INT16_MIN || value > INT16_MAX) {
            return false;
        }

        positions[i] = (int16_t)value;
        skip_json_ws(cursor);

        if (i + 1 < FULL_MOTION_SERVO_COUNT) {
            if (**cursor != ',') {
                return false;
            }
            ++(*cursor);
        }
    }

    skip_json_ws(cursor);
    if (**cursor != ']') {
        return false;
    }

    ++(*cursor);
    return true;
}

static bool parse_frame_object(const char **cursor,
                               uint16_t *dt_ms,
                               int16_t *positions)
{
    if (cursor == NULL || *cursor == NULL || dt_ms == NULL || positions == NULL) {
        return false;
    }

    bool has_dt = false;
    bool has_positions = false;
    uint16_t parsed_dt = FULL_MOTION_FRAME_DT_DEFAULT_MS;

    skip_json_ws(cursor);
    if (**cursor != '{') {
        return false;
    }

    ++(*cursor);
    skip_json_ws(cursor);
    if (**cursor == '}') {
        return false;
    }

    while (**cursor != '\0') {
        char key[32];
        uint32_t uvalue = 0;

        skip_json_ws(cursor);
        if (!parse_json_string_copy(cursor, key, sizeof(key))) {
            return false;
        }

        skip_json_ws(cursor);
        if (**cursor != ':') {
            return false;
        }
        ++(*cursor);
        skip_json_ws(cursor);

        if (strcmp(key, "dtMs") == 0) {
            if (!parse_json_uint32(cursor, &uvalue) ||
                uvalue > UINT16_MAX) {
                return false;
            }
            parsed_dt = (uint16_t)(uvalue == 0 ? FULL_MOTION_FRAME_DT_DEFAULT_MS : uvalue);
            has_dt = true;
        } else if (strcmp(key, "positions") == 0) {
            if (!parse_frame_positions(cursor, positions)) {
                return false;
            }
            has_positions = true;
        } else if (!skip_json_value(cursor)) {
            return false;
        }

        skip_json_ws(cursor);
        if (**cursor == ',') {
            ++(*cursor);
            continue;
        }
        if (**cursor == '}') {
            ++(*cursor);
            break;
        }
        return false;
    }

    if (!has_dt || !has_positions) {
        return false;
    }

    *dt_ms = parsed_dt;
    return true;
}

static bool parse_motion_frames(const char **cursor, parsed_motion_doc_t *doc)
{
    if (cursor == NULL || *cursor == NULL || doc == NULL) {
        return false;
    }

    skip_json_ws(cursor);
    if (**cursor != '[') {
        return false;
    }

    ++(*cursor);
    skip_json_ws(cursor);
    if (**cursor == ']') {
        return false;
    }

    doc->frame_count = 0;
    doc->total_duration_ms = 0;
    doc->payload_checksum = 2166136261u;

    while (**cursor != '\0') {
        if (doc->frame_count >= FULL_MOTION_FRAMES) {
            return false;
        }

        if (!parse_frame_object(cursor,
                                &doc->dts[doc->frame_count],
                                doc->positions[doc->frame_count])) {
            return false;
        }

        doc->total_duration_ms += doc->dts[doc->frame_count];
        doc->payload_checksum = checksum_update(doc->payload_checksum,
                                                &doc->dts[doc->frame_count],
                                                sizeof(doc->dts[doc->frame_count]));
        doc->payload_checksum = checksum_update(doc->payload_checksum,
                                                doc->positions[doc->frame_count],
                                                sizeof(doc->positions[doc->frame_count]));
        ++doc->frame_count;

        skip_json_ws(cursor);
        if (**cursor == ',') {
            ++(*cursor);
            continue;
        }
        if (**cursor == ']') {
            ++(*cursor);
            return doc->frame_count > 0;
        }
        return false;
    }

    return false;
}

static esp_err_t parse_motion_json_document(const char *json_text,
                                            const char *motion_name,
                                            parsed_motion_doc_t *doc)
{
    if (json_text == NULL || motion_name == NULL || doc == NULL) {
        return ESP_ERR_INVALID_ARG;
    }

    const char *cursor = json_text;
    bool has_frames = false;

    if (!parsed_motion_doc_alloc(doc, motion_name)) {
        return ESP_ERR_NO_MEM;
    }

    skip_utf8_bom(&cursor);
    skip_json_ws(&cursor);
    if (*cursor != '{') {
        parsed_motion_doc_reset(doc);
        return ESP_ERR_INVALID_RESPONSE;
    }

    ++cursor;
    skip_json_ws(&cursor);
    if (*cursor == '}') {
        parsed_motion_doc_reset(doc);
        return ESP_ERR_INVALID_RESPONSE;
    }

    while (*cursor != '\0') {
        char key[32];

        skip_json_ws(&cursor);
        if (!parse_json_string_copy(&cursor, key, sizeof(key))) {
            parsed_motion_doc_reset(doc);
            return ESP_ERR_INVALID_RESPONSE;
        }

        skip_json_ws(&cursor);
        if (*cursor != ':') {
            parsed_motion_doc_reset(doc);
            return ESP_ERR_INVALID_RESPONSE;
        }
        ++cursor;
        skip_json_ws(&cursor);

        if (strcmp(key, "frames") == 0) {
            if (!parse_motion_frames(&cursor, doc)) {
                parsed_motion_doc_reset(doc);
                return ESP_ERR_INVALID_RESPONSE;
            }
            has_frames = true;
        } else if (strcmp(key, "name") == 0 ||
                   strcmp(key, "format") == 0) {
            if (!skip_json_string(&cursor)) {
                parsed_motion_doc_reset(doc);
                return ESP_ERR_INVALID_RESPONSE;
            }
        } else if (strcmp(key, "servoCount") == 0 ||
                   strcmp(key, "frameCount") == 0 ||
                   strcmp(key, "totalDurationMs") == 0 ||
                   strcmp(key, "payloadChecksum") == 0) {
            uint32_t ignored_number = 0;
            if (!parse_json_uint32(&cursor, &ignored_number)) {
                parsed_motion_doc_reset(doc);
                return ESP_ERR_INVALID_RESPONSE;
            }
        } else if (!skip_json_value(&cursor)) {
            parsed_motion_doc_reset(doc);
            return ESP_ERR_INVALID_RESPONSE;
        }

        skip_json_ws(&cursor);
        if (*cursor == ',') {
            ++cursor;
            continue;
        }
        if (*cursor == '}') {
            ++cursor;
            break;
        }

        parsed_motion_doc_reset(doc);
        return ESP_ERR_INVALID_RESPONSE;
    }

    skip_json_ws(&cursor);
    if (!has_frames || *cursor != '\0') {
        parsed_motion_doc_reset(doc);
        return ESP_ERR_INVALID_RESPONSE;
    }

    snprintf(doc->name, sizeof(doc->name), "%s", motion_name);
    return ESP_OK;
}

static esp_err_t load_motion_json_file_into_doc_locked(const char *path,
                                                       const char *motion_name,
                                                       parsed_motion_doc_t *doc)
{
    if (path == NULL || motion_name == NULL || doc == NULL) {
        return ESP_ERR_INVALID_ARG;
    }

    FILE *file = fopen(path, "rb");
    if (file == NULL) {
        return ESP_ERR_NOT_FOUND;
    }

    if (!parsed_motion_doc_alloc(doc, motion_name)) {
        fclose(file);
        return ESP_ERR_NO_MEM;
    }

    char line[512];
    bool in_frames = false;
    bool saw_frames_end = false;
    esp_err_t err = ESP_OK;

    doc->frame_count = 0;
    doc->total_duration_ms = 0;
    doc->payload_checksum = 2166136261u;

    while (fgets(line, sizeof(line), file) != NULL) {
        if (strchr(line, '\n') == NULL && !feof(file)) {
            err = ESP_ERR_INVALID_RESPONSE;
            break;
        }

        const char *cursor = line;
        skip_utf8_bom(&cursor);
        skip_json_ws(&cursor);

        if (*cursor == '\0') {
            continue;
        }

        if (!in_frames) {
            if (strstr(cursor, "\"frames\"") != NULL) {
                const char *frames_begin = strchr(cursor, '[');
                if (frames_begin == NULL) {
                    err = ESP_ERR_INVALID_RESPONSE;
                    break;
                }
                in_frames = true;
            }
            continue;
        }

        if (*cursor == ']') {
            saw_frames_end = true;
            break;
        }

        if (doc->frame_count >= FULL_MOTION_FRAMES) {
            err = ESP_ERR_INVALID_SIZE;
            break;
        }

        if (!parse_frame_object(&cursor,
                                &doc->dts[doc->frame_count],
                                doc->positions[doc->frame_count])) {
            err = ESP_ERR_INVALID_RESPONSE;
            break;
        }

        skip_json_ws(&cursor);
        if (*cursor == ',') {
            ++cursor;
            skip_json_ws(&cursor);
        }
        if (*cursor != '\0') {
            err = ESP_ERR_INVALID_RESPONSE;
            break;
        }

        doc->total_duration_ms += doc->dts[doc->frame_count];
        doc->payload_checksum = checksum_update(doc->payload_checksum,
                                                &doc->dts[doc->frame_count],
                                                sizeof(doc->dts[doc->frame_count]));
        doc->payload_checksum = checksum_update(doc->payload_checksum,
                                                doc->positions[doc->frame_count],
                                                sizeof(doc->positions[doc->frame_count]));
        ++doc->frame_count;
    }

    if (ferror(file)) {
        err = ESP_FAIL;
    }

    fclose(file);

    if (err != ESP_OK) {
        parsed_motion_doc_reset(doc);
        return err;
    }

    if (!in_frames || !saw_frames_end || doc->frame_count == 0) {
        parsed_motion_doc_reset(doc);
        return ESP_ERR_INVALID_RESPONSE;
    }

    snprintf(doc->name, sizeof(doc->name), "%s", motion_name);
    return ESP_OK;
}

static esp_err_t write_recorded_full_motion_json_file_locked(const char *motion_name,
                                                             uint32_t *saved_checksum)
{
    if (motion_name == NULL || motion_name[0] == '\0' ||
        !has_recorded_motion_full || recorded_frame_count_full == 0) {
        return ESP_ERR_INVALID_ARG;
    }

    char path[64];
    char temp_path[72];
    char backup_path[72];
    const bool had_existing_file = motion_file_exists_locked(motion_name);
    uint32_t total_duration_ms = 0;
    uint32_t payload_checksum = 2166136261u;

    for (uint16_t frame_index = 0; frame_index < recorded_frame_count_full; ++frame_index) {
        const uint16_t dt_ms = recorded_motion_full_dt_ms[frame_index] == 0 ?
            FULL_MOTION_FRAME_DT_DEFAULT_MS :
            recorded_motion_full_dt_ms[frame_index];

        total_duration_ms += dt_ms;
        payload_checksum = checksum_update(payload_checksum, &dt_ms, sizeof(dt_ms));
        payload_checksum = checksum_update(payload_checksum,
                                           recorded_motion_full[frame_index],
                                           sizeof(recorded_motion_full[frame_index]));
    }

    build_motion_path(motion_name, path, sizeof(path));
    build_motion_aux_path(motion_name, "~t", temp_path, sizeof(temp_path));
    build_motion_aux_path(motion_name, "~b", backup_path, sizeof(backup_path));

    remove(temp_path);

    FILE *file = fopen(temp_path, "wb");
    if (file == NULL) {
        return ESP_FAIL;
    }

    bool write_ok = true;

#define WRITE_FMT(...)                        \
    do {                                      \
        if (write_ok && fprintf(file, __VA_ARGS__) < 0) { \
            write_ok = false;                 \
        }                                     \
    } while (0)

    WRITE_FMT("{\n");
    WRITE_FMT("  \"format\": \"%s\",\n", MOTION_STORAGE_FORMAT);
    WRITE_FMT("  \"name\": \"%s\",\n", motion_name);
    WRITE_FMT("  \"servoCount\": %u,\n", (unsigned)FULL_MOTION_SERVO_COUNT);
    WRITE_FMT("  \"frameCount\": %u,\n", (unsigned)recorded_frame_count_full);
    WRITE_FMT("  \"totalDurationMs\": %u,\n", (unsigned)total_duration_ms);
    WRITE_FMT("  \"payloadChecksum\": %u,\n", (unsigned)payload_checksum);
    WRITE_FMT("  \"frames\": [\n");

    for (uint16_t frame_index = 0; write_ok && frame_index < recorded_frame_count_full; ++frame_index) {
        const uint16_t dt_ms = recorded_motion_full_dt_ms[frame_index] == 0 ?
            FULL_MOTION_FRAME_DT_DEFAULT_MS :
            recorded_motion_full_dt_ms[frame_index];

        WRITE_FMT("    {\"dtMs\": %u, \"positions\": [",
                  (unsigned)dt_ms);

        for (int servo_index = 0; write_ok && servo_index < FULL_MOTION_SERVO_COUNT; ++servo_index) {
            WRITE_FMT("%s%d",
                      servo_index == 0 ? "" : ", ",
                      recorded_motion_full[frame_index][servo_index]);
        }

        WRITE_FMT("]}%s\n",
                  (frame_index + 1 < recorded_frame_count_full) ? "," : "");
    }

    WRITE_FMT("  ]\n");
    WRITE_FMT("}\n");

#undef WRITE_FMT

    if (fflush(file) != 0) {
        write_ok = false;
    }

    if (fclose(file) != 0) {
        write_ok = false;
    }

    if (!write_ok) {
        remove(temp_path);
        return ESP_FAIL;
    }

    if (had_existing_file) {
        remove(backup_path);
        if (rename(path, backup_path) != 0) {
            remove(temp_path);
            return ESP_FAIL;
        }
    }

    if (rename(temp_path, path) != 0) {
        remove(temp_path);
        if (had_existing_file) {
            rename(backup_path, path);
        }
        return ESP_FAIL;
    }

    if (had_existing_file) {
        remove(backup_path);
    }

    if (saved_checksum != NULL) {
        *saved_checksum = payload_checksum;
    }

    return ESP_OK;
}

static void apply_doc_to_recorded_motion(const parsed_motion_doc_t *doc)
{
    if (doc == NULL || doc->frame_count == 0) {
        return;
    }

    clear_recorded_full_motion();
    memcpy(recorded_motion_full,
           doc->positions,
           (size_t)doc->frame_count * sizeof(recorded_motion_full[0]));
    memcpy(recorded_motion_full_dt_ms,
           doc->dts,
           (size_t)doc->frame_count * sizeof(recorded_motion_full_dt_ms[0]));
    recorded_frame_count_full = doc->frame_count;
    has_recorded_motion_full = true;
    replay_frame_index_full = 0;
    dropped_frame_count_full = 0;
    motion_storage_set_current_motion_name(doc->name);
}

static esp_err_t write_motion_json_file_locked(const char *motion_name,
                                               const parsed_motion_doc_t *doc)
{
    if (motion_name == NULL || motion_name[0] == '\0' ||
        doc == NULL || doc->frame_count == 0) {
        return ESP_ERR_INVALID_ARG;
    }

    char path[64];
    char temp_path[72];
    char backup_path[72];
    const bool had_existing_file = motion_file_exists_locked(motion_name);

    build_motion_path(motion_name, path, sizeof(path));
    build_motion_aux_path(motion_name, "~t", temp_path, sizeof(temp_path));
    build_motion_aux_path(motion_name, "~b", backup_path, sizeof(backup_path));

    remove(temp_path);

    FILE *file = fopen(temp_path, "wb");
    if (file == NULL) {
        return ESP_FAIL;
    }

    bool write_ok = true;

#define WRITE_FMT(...)                        \
    do {                                      \
        if (write_ok && fprintf(file, __VA_ARGS__) < 0) { \
            write_ok = false;                 \
        }                                     \
    } while (0)

    WRITE_FMT("{\n");
    WRITE_FMT("  \"format\": \"%s\",\n", MOTION_STORAGE_FORMAT);
    WRITE_FMT("  \"name\": \"%s\",\n", motion_name);
    WRITE_FMT("  \"servoCount\": %u,\n", (unsigned)FULL_MOTION_SERVO_COUNT);
    WRITE_FMT("  \"frameCount\": %u,\n", (unsigned)doc->frame_count);
    WRITE_FMT("  \"totalDurationMs\": %u,\n", (unsigned)doc->total_duration_ms);
    WRITE_FMT("  \"payloadChecksum\": %u,\n", (unsigned)doc->payload_checksum);
    WRITE_FMT("  \"frames\": [\n");

    for (uint16_t frame_index = 0; write_ok && frame_index < doc->frame_count; ++frame_index) {
        WRITE_FMT("    {\"dtMs\": %u, \"positions\": [",
                  (unsigned)doc->dts[frame_index]);

        for (int servo_index = 0; write_ok && servo_index < FULL_MOTION_SERVO_COUNT; ++servo_index) {
            WRITE_FMT("%s%d",
                      servo_index == 0 ? "" : ", ",
                      doc->positions[frame_index][servo_index]);
        }

        WRITE_FMT("]}%s\n",
                  (frame_index + 1 < doc->frame_count) ? "," : "");
    }

    WRITE_FMT("  ]\n");
    WRITE_FMT("}\n");

#undef WRITE_FMT

    if (fflush(file) != 0) {
        write_ok = false;
    }

    if (fclose(file) != 0) {
        write_ok = false;
    }

    if (!write_ok) {
        remove(temp_path);
        return ESP_FAIL;
    }

    if (had_existing_file) {
        remove(backup_path);
        if (rename(path, backup_path) != 0) {
            remove(temp_path);
            return ESP_FAIL;
        }
    }

    if (rename(temp_path, path) != 0) {
        remove(temp_path);
        if (had_existing_file) {
            rename(backup_path, path);
        }
        return ESP_FAIL;
    }

    if (had_existing_file) {
        remove(backup_path);
    }

    return ESP_OK;
}

static esp_err_t read_file_into_buffer_locked(const char *path,
                                              char **text_out,
                                              size_t *text_len_out)
{
    if (path == NULL || text_out == NULL) {
        return ESP_ERR_INVALID_ARG;
    }

    *text_out = NULL;
    if (text_len_out != NULL) {
        *text_len_out = 0;
    }

    FILE *file = fopen(path, "rb");
    if (file == NULL) {
        return ESP_ERR_NOT_FOUND;
    }

    if (fseek(file, 0, SEEK_END) != 0) {
        fclose(file);
        return ESP_FAIL;
    }

    const long file_size = ftell(file);
    if (file_size < 0 || (unsigned long)file_size > MOTION_STORAGE_MAX_JSON_BYTES) {
        fclose(file);
        return ESP_ERR_INVALID_SIZE;
    }

    if (fseek(file, 0, SEEK_SET) != 0) {
        fclose(file);
        return ESP_FAIL;
    }

    char *buffer = malloc((size_t)file_size + 1U);
    if (buffer == NULL) {
        fclose(file);
        return ESP_ERR_NO_MEM;
    }

    const size_t bytes_to_read = (size_t)file_size;
    const size_t bytes_read = fread(buffer, 1, bytes_to_read, file);
    fclose(file);

    if (bytes_read != bytes_to_read) {
        free(buffer);
        return ESP_FAIL;
    }

    buffer[bytes_read] = '\0';
    *text_out = buffer;
    if (text_len_out != NULL) {
        *text_len_out = bytes_read;
    }

    return ESP_OK;
}

static bool extract_json_string_field(const char *text,
                                      const char *field_name,
                                      char *out_buf,
                                      size_t out_buf_len)
{
    if (text == NULL || field_name == NULL || out_buf == NULL || out_buf_len == 0) {
        return false;
    }

    char pattern[32];
    snprintf(pattern, sizeof(pattern), "\"%s\"", field_name);

    const char *field = strstr(text, pattern);
    if (field == NULL) {
        return false;
    }

    const char *cursor = strchr(field + strlen(pattern), ':');
    if (cursor == NULL) {
        return false;
    }

    ++cursor;
    skip_json_ws(&cursor);
    return parse_json_string_copy(&cursor, out_buf, out_buf_len);
}

static bool extract_json_uint_field(const char *text,
                                    const char *field_name,
                                    uint32_t *out_value)
{
    if (text == NULL || field_name == NULL || out_value == NULL) {
        return false;
    }

    char pattern[32];
    snprintf(pattern, sizeof(pattern), "\"%s\"", field_name);

    const char *field = strstr(text, pattern);
    if (field == NULL) {
        return false;
    }

    const char *cursor = strchr(field + strlen(pattern), ':');
    if (cursor == NULL) {
        return false;
    }

    ++cursor;
    skip_json_ws(&cursor);
    if (!parse_json_uint32(&cursor, out_value)) {
        return false;
    }
    return true;
}

static esp_err_t read_motion_metadata_locked(const char *path, stored_motion_info_t *entry)
{
    if (path == NULL || entry == NULL) {
        return ESP_ERR_INVALID_ARG;
    }

    FILE *file = fopen(path, "rb");
    if (file == NULL) {
        return ESP_ERR_NOT_FOUND;
    }

    char *prefix = malloc(MOTION_STORAGE_METADATA_SCAN_BYTES + 1U);
    if (prefix == NULL) {
        fclose(file);
        return ESP_ERR_NO_MEM;
    }

    size_t total_read = 0;
    bool found_frames = false;

    while (total_read < MOTION_STORAGE_METADATA_SCAN_BYTES) {
        const size_t remaining = MOTION_STORAGE_METADATA_SCAN_BYTES - total_read;
        const size_t bytes_read = fread(prefix + total_read, 1, remaining, file);
        total_read += bytes_read;
        prefix[total_read] = '\0';

        char *frames_field = strstr(prefix, "\"frames\"");
        if (frames_field != NULL) {
            *frames_field = '\0';
            found_frames = true;
            break;
        }

        if (bytes_read == 0) {
            break;
        }
    }

    fclose(file);

    if (!found_frames) {
        free(prefix);
        return ESP_ERR_INVALID_RESPONSE;
    }

    memset(entry, 0, sizeof(*entry));
    if (!extract_json_string_field(prefix, "name", entry->name, sizeof(entry->name))) {
        free(prefix);
        return ESP_ERR_INVALID_RESPONSE;
    }

    uint32_t frame_count = 0;
    uint32_t total_duration_ms = 0;
    if (!extract_json_uint_field(prefix, "frameCount", &frame_count) ||
        !extract_json_uint_field(prefix, "totalDurationMs", &total_duration_ms) ||
        frame_count == 0 || frame_count > FULL_MOTION_FRAMES) {
        free(prefix);
        return ESP_ERR_INVALID_RESPONSE;
    }

    entry->frame_count = (uint16_t)frame_count;
    entry->total_duration_ms = total_duration_ms;
    entry->is_current = strcmp(entry->name, s_current_motion_name) == 0;
    free(prefix);
    return ESP_OK;
}

static void cleanup_legacy_motion_files_locked(void)
{
    DIR *dir = opendir(MOTION_STORAGE_BASE_PATH);
    if (dir == NULL) {
        return;
    }

    struct dirent *entry = NULL;
    while ((entry = readdir(dir)) != NULL) {
        if (!has_legacy_motion_file_extension(entry->d_name)) {
            continue;
        }

        char legacy_name[MOTION_STORAGE_NAME_MAX_LEN];
        char legacy_path[64];

        extract_motion_name(entry->d_name, legacy_name, sizeof(legacy_name));
        build_motion_path_with_ext(legacy_name,
                                   MOTION_STORAGE_LEGACY_FILE_EXT,
                                   legacy_path,
                                   sizeof(legacy_path));
        if (remove(legacy_path) == 0) {
            ESP_LOGI(TAG, "Removed legacy motion file: %s", entry->d_name);
        } else {
            ESP_LOGW(TAG, "Failed to remove legacy motion file: %s", entry->d_name);
        }
    }

    closedir(dir);
}

static uint16_t find_next_motion_index_locked(void)
{
    uint16_t max_index = 0;
    DIR *dir = opendir(MOTION_STORAGE_BASE_PATH);

    if (dir == NULL) {
        return 1;
    }

    struct dirent *entry = NULL;
    while ((entry = readdir(dir)) != NULL) {
        if (!has_motion_file_extension(entry->d_name)) {
            continue;
        }

        unsigned int index = 0;
        if (sscanf(entry->d_name, "motion_%u.json", &index) == 1 && index > max_index) {
            max_index = (uint16_t)index;
        }
    }

    closedir(dir);
    return (uint16_t)(max_index + 1);
}

esp_err_t motion_storage_init(void)
{
    if (s_motion_storage_mutex == NULL) {
        s_motion_storage_mutex = xSemaphoreCreateMutex();
        if (s_motion_storage_mutex == NULL) {
            return ESP_ERR_NO_MEM;
        }
    }

    esp_vfs_spiffs_conf_t conf = {
        .base_path = MOTION_STORAGE_BASE_PATH,
        .partition_label = "storage",
        .max_files = 8,
        .format_if_mount_failed = true,
    };

    esp_err_t err = esp_vfs_spiffs_register(&conf);
    if (err != ESP_OK) {
        ESP_LOGE(TAG, "Failed to mount storage partition: %s", esp_err_to_name(err));
        s_motion_storage_ready = false;
        return err;
    }

    size_t total = 0;
    size_t used = 0;
    err = esp_spiffs_info(conf.partition_label, &total, &used);
    if (err == ESP_OK) {
        ESP_LOGI(TAG, "Storage ready: total=%u bytes used=%u bytes",
                 (unsigned)total,
                 (unsigned)used);
    }

    if (lock_motion_storage(pdMS_TO_TICKS(1000))) {
        cleanup_legacy_motion_files_locked();
        unlock_motion_storage();
    }

    s_motion_storage_ready = true;
    return ESP_OK;
}

bool motion_storage_is_ready(void)
{
    return s_motion_storage_ready;
}

bool motion_storage_is_busy(void)
{
    return s_motion_storage_busy;
}

const char *motion_storage_get_current_motion_name(void)
{
    return s_current_motion_name;
}

void motion_storage_set_current_motion_name(const char *motion_name)
{
    const char *source_name = motion_name;

    if (source_name == NULL || source_name[0] == '\0') {
        source_name = "No motion";
    }

    snprintf(s_current_motion_name, sizeof(s_current_motion_name), "%s", source_name);
}

size_t motion_storage_list(stored_motion_info_t *entries, size_t max_entries)
{
    if (!s_motion_storage_ready || entries == NULL || max_entries == 0) {
        return 0;
    }

    if (!lock_motion_storage(pdMS_TO_TICKS(1000))) {
        return 0;
    }

    size_t count = 0;
    DIR *dir = opendir(MOTION_STORAGE_BASE_PATH);
    if (dir == NULL) {
        unlock_motion_storage();
        return 0;
    }

    struct dirent *entry = NULL;
    while ((entry = readdir(dir)) != NULL && count < max_entries) {
        if (!has_motion_file_extension(entry->d_name)) {
            continue;
        }

        char motion_name[MOTION_STORAGE_NAME_MAX_LEN];
        char path[64];
        extract_motion_name(entry->d_name, motion_name, sizeof(motion_name));
        build_motion_path(motion_name, path, sizeof(path));

        if (read_motion_metadata_locked(path, &entries[count]) == ESP_OK) {
            ++count;
        }
    }

    closedir(dir);
    qsort(entries, count, sizeof(entries[0]), compare_motion_info);
    unlock_motion_storage();
    return count;
}

esp_err_t motion_storage_save_current_full_motion(char *saved_name,
                                                  size_t saved_name_len,
                                                  uint32_t *saved_checksum)
{
    if (!s_motion_storage_ready) {
        return ESP_ERR_INVALID_STATE;
    }

    if (!has_recorded_motion_full || recorded_frame_count_full == 0) {
        return ESP_ERR_NOT_FOUND;
    }

    if (!lock_motion_storage(pdMS_TO_TICKS(2000))) {
        return ESP_ERR_TIMEOUT;
    }

    s_motion_storage_busy = true;

    const uint16_t next_index = find_next_motion_index_locked();
    char motion_name[MOTION_STORAGE_NAME_MAX_LEN];
    uint32_t payload_checksum = 0;
    esp_err_t err = ESP_OK;

    snprintf(motion_name, sizeof(motion_name), "motion_%03u", (unsigned)next_index);

    err = write_recorded_full_motion_json_file_locked(motion_name, &payload_checksum);
    if (err != ESP_OK) {
        goto cleanup;
    }

    motion_storage_set_current_motion_name(motion_name);
    if (saved_name != NULL && saved_name_len > 0) {
        snprintf(saved_name, saved_name_len, "%s", motion_name);
    }
    if (saved_checksum != NULL) {
        *saved_checksum = payload_checksum;
    }

cleanup:
    s_motion_storage_busy = false;
    unlock_motion_storage();
    return err;
}

esp_err_t motion_storage_load_full_motion(const char *motion_name, uint32_t *loaded_checksum)
{
    if (!s_motion_storage_ready || motion_name == NULL || motion_name[0] == '\0') {
        return ESP_ERR_INVALID_ARG;
    }

    if (!lock_motion_storage(pdMS_TO_TICKS(2000))) {
        return ESP_ERR_TIMEOUT;
    }

    s_motion_storage_busy = true;

    char path[64];
    parsed_motion_doc_t doc = {0};
    esp_err_t err = ESP_OK;

    build_motion_path(motion_name, path, sizeof(path));

    err = load_motion_json_file_into_doc_locked(path, motion_name, &doc);
    if (err != ESP_OK) {
        goto cleanup;
    }

    apply_doc_to_recorded_motion(&doc);
    if (loaded_checksum != NULL) {
        *loaded_checksum = doc.payload_checksum;
    }

cleanup:
    parsed_motion_doc_reset(&doc);
    s_motion_storage_busy = false;
    unlock_motion_storage();
    return err;
}

esp_err_t motion_storage_read_json_full_motion(const char *motion_name,
                                               char **json_text,
                                               size_t *json_len)
{
    if (!s_motion_storage_ready || motion_name == NULL || motion_name[0] == '\0' ||
        json_text == NULL) {
        return ESP_ERR_INVALID_ARG;
    }

    if (!lock_motion_storage(pdMS_TO_TICKS(2000))) {
        return ESP_ERR_TIMEOUT;
    }

    s_motion_storage_busy = true;

    char path[64];
    build_motion_path(motion_name, path, sizeof(path));
    const esp_err_t err = read_file_into_buffer_locked(path, json_text, json_len);

    s_motion_storage_busy = false;
    unlock_motion_storage();
    return err;
}

esp_err_t motion_storage_update_json_full_motion(const char *motion_name,
                                                 const char *json_text,
                                                 uint32_t *saved_checksum)
{
    if (!s_motion_storage_ready ||
        motion_name == NULL || motion_name[0] == '\0' ||
        json_text == NULL || json_text[0] == '\0') {
        return ESP_ERR_INVALID_ARG;
    }

    if (strlen(json_text) > MOTION_STORAGE_MAX_JSON_BYTES) {
        return ESP_ERR_INVALID_SIZE;
    }

    if (!lock_motion_storage(pdMS_TO_TICKS(2000))) {
        return ESP_ERR_TIMEOUT;
    }

    s_motion_storage_busy = true;

    parsed_motion_doc_t doc = {0};
    esp_err_t err = parse_motion_json_document(json_text, motion_name, &doc);
    if (err != ESP_OK) {
        goto cleanup;
    }

    err = write_motion_json_file_locked(motion_name, &doc);
    if (err == ESP_OK && saved_checksum != NULL) {
        *saved_checksum = doc.payload_checksum;
    }
    if (err == ESP_OK) {
        motion_storage_set_current_motion_name(motion_name);
    }

cleanup:
    parsed_motion_doc_reset(&doc);
    s_motion_storage_busy = false;
    unlock_motion_storage();
    return err;
}

esp_err_t motion_storage_rename_full_motion(const char *motion_name,
                                            const char *new_motion_name,
                                            uint32_t *saved_checksum)
{
    if (!s_motion_storage_ready) {
        return ESP_ERR_INVALID_STATE;
    }

    if (!is_valid_motion_name_internal(motion_name) ||
        !is_valid_motion_name_internal(new_motion_name)) {
        return ESP_ERR_INVALID_ARG;
    }

    if (strcmp(motion_name, new_motion_name) == 0) {
        if (saved_checksum != NULL) {
            *saved_checksum = 0;
        }
        return ESP_OK;
    }

    if (!lock_motion_storage(pdMS_TO_TICKS(2000))) {
        return ESP_ERR_TIMEOUT;
    }

    s_motion_storage_busy = true;

    char old_path[64];
    char new_path[64];
    parsed_motion_doc_t doc = {0};
    esp_err_t err = ESP_OK;

    build_motion_path(motion_name, old_path, sizeof(old_path));
    build_motion_path(new_motion_name, new_path, sizeof(new_path));

    if (!motion_file_exists_locked(motion_name)) {
        err = ESP_ERR_NOT_FOUND;
        goto cleanup;
    }

    if (motion_file_exists_locked(new_motion_name)) {
        err = ESP_ERR_INVALID_STATE;
        goto cleanup;
    }

    err = load_motion_json_file_into_doc_locked(old_path, new_motion_name, &doc);
    if (err != ESP_OK) {
        goto cleanup;
    }

    err = write_motion_json_file_locked(new_motion_name, &doc);
    if (err != ESP_OK) {
        goto cleanup;
    }

    if (remove(old_path) != 0) {
        remove(new_path);
        err = ESP_FAIL;
        goto cleanup;
    }

    if (strcmp(motion_name, s_current_motion_name) == 0) {
        motion_storage_set_current_motion_name(new_motion_name);
    }

    if (saved_checksum != NULL) {
        *saved_checksum = doc.payload_checksum;
    }

cleanup:
    parsed_motion_doc_reset(&doc);
    s_motion_storage_busy = false;
    unlock_motion_storage();
    return err;
}

esp_err_t motion_storage_delete_full_motion(const char *motion_name)
{
    if (!s_motion_storage_ready) {
        return ESP_ERR_INVALID_STATE;
    }

    if (motion_name == NULL || motion_name[0] == '\0') {
        return ESP_ERR_INVALID_ARG;
    }

    if (!lock_motion_storage(pdMS_TO_TICKS(2000))) {
        return ESP_ERR_TIMEOUT;
    }

    s_motion_storage_busy = true;

    char path[64];
    build_motion_path(motion_name, path, sizeof(path));

    FILE *file = fopen(path, "rb");
    if (file == NULL) {
        s_motion_storage_busy = false;
        unlock_motion_storage();
        return ESP_ERR_NOT_FOUND;
    }
    fclose(file);

    if (remove(path) != 0) {
        s_motion_storage_busy = false;
        unlock_motion_storage();
        return ESP_FAIL;
    }

    if (strcmp(motion_name, s_current_motion_name) == 0) {
        motion_storage_set_current_motion_name(NULL);
    }

    s_motion_storage_busy = false;
    unlock_motion_storage();
    return ESP_OK;
}

esp_err_t motion_storage_delete_all_full_motion(size_t *deleted_count)
{
    if (!s_motion_storage_ready) {
        return ESP_ERR_INVALID_STATE;
    }

    if (!lock_motion_storage(pdMS_TO_TICKS(2000))) {
        return ESP_ERR_TIMEOUT;
    }

    s_motion_storage_busy = true;

    size_t local_deleted_count = 0;
    bool had_any_motion = false;
    bool current_deleted = false;
    bool delete_failed = false;
    DIR *dir = opendir(MOTION_STORAGE_BASE_PATH);

    if (dir == NULL) {
        s_motion_storage_busy = false;
        unlock_motion_storage();
        return ESP_FAIL;
    }

    struct dirent *entry = NULL;
    while ((entry = readdir(dir)) != NULL) {
        if (!has_motion_file_extension(entry->d_name) &&
            !has_legacy_motion_file_extension(entry->d_name)) {
            continue;
        }

        had_any_motion = true;

        char motion_name[MOTION_STORAGE_NAME_MAX_LEN];
        char path[64];
        const char *extension = has_motion_file_extension(entry->d_name) ?
            MOTION_STORAGE_FILE_EXT :
            MOTION_STORAGE_LEGACY_FILE_EXT;

        extract_motion_name(entry->d_name, motion_name, sizeof(motion_name));
        build_motion_path_with_ext(motion_name, extension, path, sizeof(path));

        if (remove(path) != 0) {
            delete_failed = true;
            continue;
        }

        local_deleted_count++;
        if (strcmp(motion_name, s_current_motion_name) == 0) {
            current_deleted = true;
        }
    }

    closedir(dir);

    if (deleted_count != NULL) {
        *deleted_count = local_deleted_count;
    }

    if (current_deleted || (had_any_motion && !delete_failed)) {
        motion_storage_set_current_motion_name(NULL);
    }

    s_motion_storage_busy = false;
    unlock_motion_storage();
    return delete_failed ? ESP_FAIL : ESP_OK;
}
