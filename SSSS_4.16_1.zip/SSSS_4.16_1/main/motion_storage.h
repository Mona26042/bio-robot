#ifndef MOTION_STORAGE_H
#define MOTION_STORAGE_H

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

#include "esp_err.h"

#define MOTION_STORAGE_NAME_MAX_LEN 24
#define MOTION_STORAGE_LIST_MAX 40

typedef struct {
    char name[MOTION_STORAGE_NAME_MAX_LEN];
    uint16_t frame_count;
    uint32_t total_duration_ms;
    bool is_current;
} stored_motion_info_t;

esp_err_t motion_storage_init(void);
bool motion_storage_is_ready(void);
bool motion_storage_is_busy(void);
const char *motion_storage_get_current_motion_name(void);
void motion_storage_set_current_motion_name(const char *motion_name);
size_t motion_storage_list(stored_motion_info_t *entries, size_t max_entries);
esp_err_t motion_storage_save_current_full_motion(char *saved_name,
                                                  size_t saved_name_len,
                                                  uint32_t *saved_checksum);
esp_err_t motion_storage_load_full_motion(const char *motion_name,
                                          uint32_t *loaded_checksum);
esp_err_t motion_storage_read_json_full_motion(const char *motion_name,
                                               char **json_text,
                                               size_t *json_len);
esp_err_t motion_storage_update_json_full_motion(const char *motion_name,
                                                 const char *json_text,
                                                 uint32_t *saved_checksum);
esp_err_t motion_storage_rename_full_motion(const char *motion_name,
                                            const char *new_motion_name,
                                            uint32_t *saved_checksum);
esp_err_t motion_storage_delete_full_motion(const char *motion_name);
esp_err_t motion_storage_delete_all_full_motion(size_t *deleted_count);

#endif // MOTION_STORAGE_H
