/*
 * web_server.h
 *
 * HTTP 服务器对外接口。
 * Web 页面、状态接口、按钮命令和滑块控制都由 web_server.c 注册到该服务器。
 */

#ifndef WEB_SERVER_H
#define WEB_SERVER_H

#include "esp_http_server.h"

// 创建并启动 HTTP 服务器，返回服务器句柄。
httpd_handle_t start_webserver(void);

#endif // WEB_SERVER_H
