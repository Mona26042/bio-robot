/*
 * servo_protocol.c
 * 飞特串行舵机协议实现。
 * 负责协议组包、校验、应答解析、同步读写以及 SMS/STS 系列的常用高级指令。
 */

#include <stdlib.h>
#include <string.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "driver/uart.h"
#include "esp_log.h"
#include "servo_protocol.h"
#include "uart_servo.h"  // 需要 SERVO_UART 宏和 ftUart_Send/Read/Delay 函数

// ============================================================================
// SCS.c - SCS协议实现
// ============================================================================

// 声明UART编号（由uart_servo.h定义，通过宏）
#ifndef SERVO_UART
#define SERVO_UART UART_NUM_1  // 默认值，如果uart_servo.h已经定义则使用uart_servo.h的值
#endif

// 底层协议状态集中放在这里：包括字节序、应答状态、错误码以及同步读缓存指针。
static uint8_t Level = 1;     // 应答等级：1 表示普通写指令需要应答
static uint8_t End   = 0;     // 字节序：0 小端（默认），1 大端
static uint8_t u8Status;      // 舵机返回的状态字节
static uint8_t u8Error;       // 通信错误码
uint8_t syncReadRxPacketIndex;
uint8_t syncReadRxPacketLen;
uint8_t *syncReadRxPacket;
static uint8_t s_sync_read_rx_storage[SCS_SYNC_READ_RX_BUFFER_SIZE];
uint8_t *syncReadRxBuff = NULL;
uint16_t syncReadRxBuffLen = 0;
uint16_t syncReadRxBuffMax = 0;

#ifndef SCS_TX_BUFFER_SIZE
#define SCS_TX_BUFFER_SIZE 256
#endif

static const char *TAG = "SERVO_PROTOCOL";

// 设置协议使用的高低字节顺序。
// 设置协议使用的高低字节排列方式。
void setEnd(uint8_t _End)
{
	End = _End;
}

// 获取当前协议字节序配置。
// 读取当前协议字节序配置。
uint8_t getEnd(void)
{
	return End;
}

// 设置写指令是否等待应答。
// 设置写指令后是否等待应答包。
void setLevel(uint8_t _Level)
{
	Level = _Level;
}

// 返回最近一次舵机应答中的状态字节。
// 返回最近一次协议交互中的状态字节。
int getState(void)
{
	return u8Status;
}

// 返回最近一次通信错误码。
// 返回最近一次协议收发解析得到的错误码。
int getLastError(void)
{
	return u8Error;
}

// 1 个 16 位数据拆分为 2 个 8 位（低/高字节）
// DataL 为低字节，DataH 为高字节
// 按当前字节序把主机整数拆成协议需要的两个字节。
void Host2SCS(uint8_t *DataL, uint8_t* DataH, int Data)
{
	if(End){
		*DataL = (Data>>8);
		*DataH = (Data&0xff);
	}else{
		*DataH = (Data>>8);
		*DataL = (Data&0xff);
	}
}

// 2 个 8 位数据合成为 1 个 16 位
// DataL 为低字节，DataH 为高字节
// 按当前字节序把协议中的两个字节还原为主机整数。
int SCS2Host(uint8_t DataL, uint8_t DataH)
{
	int Data;
	if(End){
		Data = DataL;
		Data<<=8;
		Data |= DataH;
	}else{
		Data = DataH;
		Data<<=8;
		Data |= DataL;
	}
	return Data;
}

// 按飞特协议格式组包并写入发送缓冲。
// 组装最基础的协议包头、长度、参数区和校验和，并写入发送缓冲。
void writeBuf(uint8_t ID, uint8_t MemAddr, uint8_t *nDat, uint8_t nLen, uint8_t Fun)
{
	uint8_t i;
	uint8_t msgLen = 2;
	uint8_t bBuf[6];
	uint8_t CheckSum = 0;
	bBuf[0] = 0xff;
	bBuf[1] = 0xff;
	bBuf[2] = ID;
	bBuf[4] = Fun;
	if(nDat){
		msgLen += nLen + 1;
		bBuf[3] = msgLen;
		bBuf[5] = MemAddr;
		writeSCS(bBuf, 6);
		
	}else{
		bBuf[3] = msgLen;
		writeSCS(bBuf, 5);
	}
	CheckSum = ID + msgLen + Fun + MemAddr;
	if(nDat){
		for(i=0; i<nLen; i++){
			CheckSum += nDat[i];
		}
		writeSCS(nDat, nLen);
	}
	CheckSum = ~CheckSum;
	writeSCS(&CheckSum, 1);
}

// 普通写指令：向指定 ID、内存地址写入连续 nLen 字节
// 发送普通写寄存器指令，并在需要时等待单个舵机应答。
int genWrite(uint8_t ID, uint8_t MemAddr, uint8_t *nDat, uint8_t nLen)
{
    rFlushSCS();
    writeBuf(ID, MemAddr, nDat, nLen, INST_WRITE);
    wFlushSCS();
    return Ack(ID);
}

// 异步写指令：仅写入寄存器，不立即执行
// 发送寄存器写指令，数据先写入舵机缓存，动作暂不立即执行。
int regWrite(uint8_t ID, uint8_t MemAddr, uint8_t *nDat, uint8_t nLen)
{
	rFlushSCS();
	writeBuf(ID, MemAddr, nDat, nLen, INST_REG_WRITE);
	wFlushSCS();
	return Ack(ID);
}

// 寄存器写执行（执行之前通过 regWrite 写入的寄存器数据）
// 触发之前通过 regWrite 缓存下来的动作统一生效。
int regAction(uint8_t ID)
{
	rFlushSCS();
	writeBuf(ID, 0, NULL, 0, INST_REG_ACTION);
	wFlushSCS();
	return Ack(ID);
}

// 同步写指令：一次同时控制多个舵机写入相同类型的数据
// 向多个舵机广播同一寄存器块的数据，是整组联动下发的基础能力。
void syncWrite(uint8_t ID[], uint8_t IDN, uint8_t MemAddr, uint8_t *nDat, uint8_t nLen)
{
	uint8_t mesLen = ((nLen+1)*IDN+4);
	uint16_t packetLen = (uint16_t)(7 + ((nLen + 1) * IDN) + 1);
	uint8_t Sum = 0;
	uint8_t bBuf[7];
	uint8_t i, j;

	if(packetLen > SCS_TX_BUFFER_SIZE){
		ESP_LOGE(TAG,
		         "syncWrite packet too long: packet=%u, buffer=%u, id_count=%u, data_len=%u",
		         (unsigned)packetLen,
		         (unsigned)SCS_TX_BUFFER_SIZE,
		         (unsigned)IDN,
		         (unsigned)nLen);
	} else if (IDN >= 10) {
		ESP_LOGI(TAG,
		         "syncWrite packet=%u, buffer=%u, id_count=%u, data_len=%u",
		         (unsigned)packetLen,
		         (unsigned)SCS_TX_BUFFER_SIZE,
		         (unsigned)IDN,
		         (unsigned)nLen);
	}
	
	bBuf[0] = 0xff;
	bBuf[1] = 0xff;
	bBuf[2] = 0xfe;
	bBuf[3] = mesLen;
	bBuf[4] = INST_SYNC_WRITE;
	bBuf[5] = MemAddr;
	bBuf[6] = nLen;
	
	rFlushSCS();
	writeSCS(bBuf, 7);

	Sum = 0xfe + mesLen + INST_SYNC_WRITE + MemAddr + nLen;

	for(i=0; i<IDN; i++){
		writeSCS(&ID[i], 1);
		writeSCS(nDat+i*nLen, nLen);
		Sum += ID[i];
		for(j=0; j<nLen; j++){
			Sum += nDat[i*nLen+j];
		}
	}
	Sum = ~Sum;
	writeSCS(&Sum, 1);
	wFlushSCS();
}

// 向指定寄存器写入 1 个字节数据。
// 写 1 字节寄存器的便捷封装。
int writeByte(uint8_t ID, uint8_t MemAddr, uint8_t bDat)
{
	rFlushSCS();
	writeBuf(ID, MemAddr, &bDat, 1, INST_WRITE);
	wFlushSCS();
	return Ack(ID);
}

// 向指定寄存器写入 1 个 16 位数据。
// 写 2 字节寄存器的便捷封装。
int writeWord(uint8_t ID, uint8_t MemAddr, uint16_t wDat)
{
	uint8_t buf[2];
	Host2SCS(buf+0, buf+1, wDat);
	rFlushSCS();
	writeBuf(ID, MemAddr, buf, 2, INST_WRITE);
	wFlushSCS();
	return Ack(ID);
}

// 读指令：从指定 ID、内存地址开始读取 nLen 字节
// 发送读指令并完整校验返回包头、长度、校验和，再把有效数据拷到输出缓冲。
int Read(uint8_t ID, uint8_t MemAddr, uint8_t *nData, uint8_t nLen)
{
	int Size;
	uint8_t bBuf[4];
	uint8_t calSum;
	uint8_t i;
	rFlushSCS();
	writeBuf(ID, MemAddr, &nLen, 1, INST_READ);
	wFlushSCS();
	u8Error = 0;
	if(!checkHead()){
		u8Error = SCS_ERR_NO_REPLY;
		return 0;
	}
	if(readSCS(bBuf, 3)!=3){
		u8Error = SCS_ERR_NO_REPLY;
		return 0;
	}
	if(bBuf[0]!=ID && ID!=0xfe){
		u8Error = SCS_ERR_SLAVE_ID;
		return 0;
	}
	if(bBuf[1]!=(nLen+2)){
		u8Error = SCS_ERR_BUFF_LEN;
		return 0;
	}
	Size = readSCS(nData, nLen);
	if(Size!=nLen){
		u8Error = SCS_ERR_NO_REPLY;
		return 0;
	}
	if(readSCS(bBuf+3, 1)!=1){
		u8Error = SCS_ERR_NO_REPLY;
		return 0;
	}
	calSum = bBuf[0]+bBuf[1]+bBuf[2];
	for(i=0; i<Size; i++){
		calSum += nData[i];
	}
	calSum = ~calSum;
	if(calSum!=bBuf[3]){
		u8Error = SCS_ERR_CRC_CMP;
		return 0;
	}
	u8Status = bBuf[2];
	return Size;
}

// 读 1 字节，失败时返回 -1
// 读取 1 字节寄存器的便捷封装。
int readByte(uint8_t ID, uint8_t MemAddr)
{
	uint8_t bDat;
	int Size = Read(ID, MemAddr, &bDat, 1);
	if(Size!=1){
		return -1;
	}else{
		return bDat;
	}
}

// 读 2 字节（16 位），失败时返回 -1
// 读取 2 字节寄存器的便捷封装。
int readWord(uint8_t ID, uint8_t MemAddr)
{	
	uint8_t nDat[2];
	int Size;
	uint16_t wDat;
	Size = Read(ID, MemAddr, nDat, 2);
	if(Size!=2)
		return -1;
	wDat = SCS2Host(nDat[0], nDat[1]);
	return wDat;
}

// Ping 指令，成功返回舵机 ID，失败返回 -1
// 发送 Ping 指令确认目标舵机是否在线并可正常应答。
int	Ping(uint8_t ID)
{
	uint8_t bBuf[4];
	uint8_t calSum;
	rFlushSCS();
	writeBuf(ID, 0, NULL, 0, INST_PING);
	wFlushSCS();
	u8Status = 0;
	if(!checkHead()){
		u8Error = SCS_ERR_NO_REPLY;
		return -1;
	}
	u8Error = 0;
	if(readSCS(bBuf, 4)!=4){
		u8Error = SCS_ERR_NO_REPLY;
		return -1;
	}
	if(bBuf[0]!=ID && ID!=0xfe){
		u8Error = SCS_ERR_SLAVE_ID;
		return -1;
	}
	if(bBuf[1]!=2){
		u8Error = SCS_ERR_BUFF_LEN;
		return -1;
	}
	calSum = ~(bBuf[0]+bBuf[1]+bBuf[2]);
	if(calSum!=bBuf[3]){
		u8Error = SCS_ERR_CRC_CMP;
		return -1;			
	}
	u8Status = bBuf[2];
	return bBuf[0];
}

// Reset 指令，恢复默认状态（包括圈数），失败返回 -1
// 发送复位指令，把舵机恢复到默认配置。
int	Reset(uint8_t ID)
{
	uint8_t bBuf[4];
	uint8_t calSum;
	rFlushSCS();
	writeBuf(ID, 0, NULL, 0, INST_RESET);
	wFlushSCS();
	u8Status = 0;
	if(!checkHead()){
		u8Error = SCS_ERR_NO_REPLY;
		return -1;
	}
	u8Error = 0;
	if(readSCS(bBuf, 4)!=4){
		u8Error = SCS_ERR_NO_REPLY;
		return -1;
	}
	if(bBuf[0]!=ID && ID!=0xfe){
		u8Error = SCS_ERR_SLAVE_ID;
		return -1;
	}
	if(bBuf[1]!=2){
		u8Error = SCS_ERR_BUFF_LEN;
		return -1;
	}
	calSum = ~(bBuf[0]+bBuf[1]+bBuf[2]);
	if(calSum!=bBuf[3]){
		u8Error = SCS_ERR_CRC_CMP;
		return -1;			
	}
	u8Status = bBuf[2];
	return bBuf[0];
}

// 在接收流里查找连续两个 0xFF 作为协议包头起点。
int checkHead(void)
{
	uint8_t bDat;
	uint8_t bBuf[2] = {0, 0};
	uint8_t Cnt = 0;
	while(1){
		if(!readSCS(&bDat, 1)){
			return 0;
		}
		bBuf[1] = bBuf[0];
		bBuf[0] = bDat;
		if(bBuf[0]==0xff && bBuf[1]==0xff){
			break;
		}
		Cnt++;
		if(Cnt>10){
			return 0;
		}
	}
	return 1;
}

// 指令应答解析
// 解析普通写指令后的应答包，并更新状态字节和错误码。
int	Ack(uint8_t ID)
{
	uint8_t bBuf[4];
	uint8_t calSum;
	u8Error = 0;
	if(ID!=0xfe && Level){
		if(!checkHead()){
			u8Error = SCS_ERR_NO_REPLY;
			return 0;
		}
		u8Status = 0;
		if(readSCS(bBuf, 4)!=4){
			u8Error = SCS_ERR_NO_REPLY;
			return 0;
		}
		if(bBuf[0]!=ID){
			u8Error = SCS_ERR_SLAVE_ID;
			return 0;
		}
		if(bBuf[1]!=2){
			u8Error = SCS_ERR_BUFF_LEN;
			return 0;
		}
		calSum = ~(bBuf[0]+bBuf[1]+bBuf[2]);
		if(calSum!=bBuf[3]){
			u8Error = SCS_ERR_CRC_CMP;
			return 0;			
		}
		u8Status = bBuf[2];
	}
	return 1;
}

// 发送同步读请求并尽可能把本轮收到的原始字节一次性收进缓存。
int	syncReadPacketTx(uint8_t ID[], uint8_t IDN, uint8_t MemAddr, uint8_t nLen)
{
	uint8_t checkSum;
	uint8_t i;
	rFlushSCS();
	syncReadRxPacketLen = nLen;
	checkSum = (4+0xfe)+IDN+MemAddr+nLen+INST_SYNC_READ;
	writeByteSCS(0xff);
	writeByteSCS(0xff);
	writeByteSCS(0xfe);
	writeByteSCS(IDN+4);
	writeByteSCS(INST_SYNC_READ);
	writeByteSCS(MemAddr);
	writeByteSCS(nLen);
	for(i=0; i<IDN; i++){
		writeByteSCS(ID[i]);
		checkSum += ID[i];
	}
	checkSum = ~checkSum;
	writeByteSCS(checkSum);
	wFlushSCS();
	
	// 清零缓冲区，准备读取
	syncReadRxBuffLen = 0;
	
	// 优化的读取策略
	// 第一阶段：等待初始响应（根据5个舵机计算，每个约10ms，总共约50ms）
	vTaskDelay(pdMS_TO_TICKS(20));  // 等待20ms，让舵机有时间响应
	int initial_read_len = uart_read_bytes(SERVO_UART,
	                                       syncReadRxBuff,
	                                       syncReadRxBuffMax,
	                                       pdMS_TO_TICKS(100));  // 读取超时100ms
	if(initial_read_len < 0) {
		syncReadRxBuffLen = 0;  // 错误时重置为0
	} else {
		syncReadRxBuffLen = (uint16_t)initial_read_len;
	}
	
	// 第二阶段：追加读取延迟到达的响应（一次即可）
	vTaskDelay(pdMS_TO_TICKS(30));  // 额外等待30ms
	int append_len = syncReadPacketAppend();
	if(append_len > 0) {
		syncReadRxBuffLen += append_len;
	}
	
	return syncReadRxBuffLen;
}

// 追加读取同步读取响应数据（在等待后调用，用于读取延迟到达的响应）
// 增加超时时间，确保能读取到延迟到达的数据
// 在首次读取后追加补收剩余串口字节，尽量拼全同步读响应。
int syncReadPacketAppend(void)
{
	{
		if(!syncReadRxBuff || syncReadRxBuffLen >= syncReadRxBuffMax){
			return 0;
		}

		int remaining = (int)(syncReadRxBuffMax - syncReadRxBuffLen);
		if(remaining <= 0){
			return 0;
		}

		int read_len = uart_read_bytes(SERVO_UART,
		                               syncReadRxBuff + syncReadRxBuffLen,
		                               remaining,
		                               pdMS_TO_TICKS(SCS_SYNC_READ_APPEND_TIMEOUT_MS));
		if(read_len > 0){
			syncReadRxBuffLen = (uint16_t)(syncReadRxBuffLen + read_len);
			return read_len;
		}

		return 0;
	}

	if(!syncReadRxBuff || syncReadRxBuffLen >= syncReadRxBuffMax){
		return 0;
	}
	int remaining = syncReadRxBuffMax - syncReadRxBuffLen;
	if(remaining > 0){
		// 增加超时到100ms，确保能读取到延迟到达的响应
		int read_len = uart_read_bytes(SERVO_UART, 
		                               syncReadRxBuff + syncReadRxBuffLen, 
		                               remaining, 
		                               pdMS_TO_TICKS(100));
		if(read_len > 0){
			syncReadRxBuffLen += read_len;
			return read_len;
		} else if(read_len < -1) {  // -1是超时（正常），其他负数为错误
			// 错误，返回0表示没有新数据
			return 0;
		}
		return 0;  // 超时或没有数据
	}
	return 0;
}

// 为本轮同步读按舵机数量和单包长度分配接收缓存。
void syncReadBegin(uint8_t IDN, uint8_t rxLen)
{
	{
		const uint16_t required_len = (uint16_t)IDN * (uint16_t)(rxLen + 6U);

		syncReadRxBuff = s_sync_read_rx_storage;
		syncReadRxBuffLen = 0;
		syncReadRxBuffMax = required_len;
		if(syncReadRxBuffMax > sizeof(s_sync_read_rx_storage)){
			u8Error = SCS_ERR_BUFF_LEN;
			syncReadRxBuffMax = sizeof(s_sync_read_rx_storage);
			ESP_LOGW(TAG,
			         "syncReadBegin buffer capped: required=%u cap=%u",
			         (unsigned)required_len,
			         (unsigned)syncReadRxBuffMax);
		}
		return;
	}

	syncReadRxBuffMax = IDN*(rxLen+6);
	syncReadRxBuff = malloc(syncReadRxBuffMax);
}

// 释放同步读过程中申请的接收缓存。
void syncReadEnd(void)
{
	syncReadRxBuff = NULL;
	syncReadRxBuffLen = 0;
	syncReadRxBuffMax = 0;
	return;

	if(syncReadRxBuff){
		free(syncReadRxBuff);
		syncReadRxBuff = NULL;
	}
}

// 在同步读缓存中找到指定舵机的数据包，校验通过后把数据段提取出来。
int syncReadPacketRx(uint8_t ID, uint8_t *nDat)
{
	// 重新实现解析逻辑：按包遍历，遇到非目标ID的包直接跳过整个包，避免错位导致后续ID CRC/ID错误
	uint16_t idx = 0;
	syncReadRxPacket = nDat;
	syncReadRxPacketIndex = 0;
	u8Status = 0;
	u8Error = SCS_ERR_NO_REPLY;

	while (idx + 4 <= syncReadRxBuffLen) {
		// 找包头 0xFF 0xFF
		if (!(syncReadRxBuff[idx] == 0xff && syncReadRxBuff[idx + 1] == 0xff)) {
			idx++;
			continue;
		}

		uint8_t packet_id  = syncReadRxBuff[idx + 2];
		uint8_t packet_len = syncReadRxBuff[idx + 3]; // LEN = 参数字节数 + 2（错误+校验），总包长 = LEN + 4
		uint16_t packet_total = (uint16_t)packet_len + 4;

		// 如果当前缓冲区剩余数据不足一个完整包，跳出等待追加数据
		if (idx + packet_total > syncReadRxBuffLen) {
				break;
		}

		// 不是目标ID则跳过整个包，继续找下一个包头
		if (packet_id != ID) {
			u8Error = SCS_ERR_SLAVE_ID;
			idx += packet_total;
			continue;
		}

		// 目标ID，校验长度是否匹配期望参数长度
		if (packet_len != (syncReadRxPacketLen + 2)) {
			// 长度异常，跳过此包
			idx += packet_total;
			continue;
		}

		// 解析错误字节与数据
		uint16_t data_idx = idx + 4; // 指向错误字节
		u8Status = syncReadRxBuff[data_idx++];
		uint8_t calSum = packet_id + packet_len + u8Status;
		for (uint8_t i = 0; i < syncReadRxPacketLen; i++) {
			syncReadRxPacket[i] = syncReadRxBuff[data_idx++];
			calSum += syncReadRxBuff[idx + 4 + i];
		}
		calSum = ~calSum;

		// 校验和
		if (calSum != syncReadRxBuff[idx + packet_total - 1]) {
			u8Error = SCS_ERR_CRC_CMP;
			return 0;
		}

		u8Error = 0;
		return syncReadRxPacketLen;
	}

	// 未找到目标ID的有效包
	return 0;
}

// 从当前同步读数据包中顺序取出 1 字节数据。
int syncReadRxPacketToByte(void)
{
	if(syncReadRxPacketIndex>=syncReadRxPacketLen){
		return -1;
	}
	return syncReadRxPacket[syncReadRxPacketIndex++];
}

// 从当前同步读数据包中顺序取出 2 字节数据，并按符号位规则转成有符号值。
int syncReadRxPacketToWord(uint8_t negBit)
{
	if((syncReadRxPacketIndex+1)>=syncReadRxPacketLen){
		return -1;
	}
	int Word = SCS2Host(syncReadRxPacket[syncReadRxPacketIndex], syncReadRxPacket[syncReadRxPacketIndex+1]);
	syncReadRxPacketIndex += 2;
	if(negBit){
		if(Word&(1<<negBit)){
			Word = -(Word & ~(1<<negBit));
		}
	}
	return Word;
}

// ============================================================================
// SCSerail.c - 串口适配层实现
// ============================================================================

// UART 发送缓冲区，协议层先把数据写到这里，再统一刷到串口。
uint8_t wBuf[SCS_TX_BUFFER_SIZE];
uint16_t wLen = 0;

// UART 接收数据接口
// 从底层 UART 读取指定长度字节，是协议层唯一的读入口。
int readSCS(unsigned char *nDat, int nLen)
{
	return ftUart_Read(nDat, nLen);
}

// UART 发送数据接口
// 把一段数据追加到发送缓冲区，暂不立即真正发串口。
int writeSCS(unsigned char *nDat, int nLen)
{
	int dropped = 0;
	while(nLen--){
		if(wLen<sizeof(wBuf)){
			wBuf[wLen] = *nDat;
			wLen++;
		}else{
			dropped++;
		}
		nDat++;
	}
	if(dropped > 0){
		ESP_LOGE(TAG,
		         "writeSCS truncated: dropped=%d, buffered=%u, capacity=%u",
		         dropped,
		         (unsigned)wLen,
		         (unsigned)sizeof(wBuf));
	}
	return wLen;
}

// 把单个字节追加到发送缓冲区。
int writeByteSCS(unsigned char bDat)
{
	if(wLen<sizeof(wBuf)){
		wBuf[wLen] = bDat;
		wLen++;
	}else{
		ESP_LOGE(TAG,
		         "writeByteSCS truncated: buffered=%u, capacity=%u",
		         (unsigned)wLen,
		         (unsigned)sizeof(wBuf));
	}
	return wLen;
}

// 接收缓冲区刷新（在读取前做总线延时和清空缓冲区）
// 读操作前做总线方向和时序准备。
void rFlushSCS()
{
	ftBus_Delay();
	// 注意：实际的缓冲区清空应该在 ftUart_Read 层面处理
	// 这里只做延时，等待总线稳定
}

// 发送缓冲区刷新（将缓冲区内容真正通过 UART 发送出去）
// 把累计在缓冲区里的待发字节一次性送到 UART。
void wFlushSCS()
{
	if(wLen){
		if(wLen >= 40){
			ESP_LOGI(TAG, "wFlushSCS tx_len=%u", (unsigned)wLen);
		}
		ftUart_Send(wBuf, wLen);
		wLen = 0;
	}
}

// ============================================================================
// SMS_STS.c - SMS/STS系列应用层实现
// ============================================================================

// 写入舵机目标位置、速度和加速度，是最常用的位置控制接口。
int WritePosEx(uint8_t ID, int16_t Position, uint16_t Speed, uint8_t ACC)
{
	uint8_t bBuf[7];
	if(Position<0){
		Position = -Position;
		Position |= (1<<15);
	}

	bBuf[0] = ACC;
	Host2SCS(bBuf+1, bBuf+2, Position);
	Host2SCS(bBuf+3, bBuf+4, 0);
	Host2SCS(bBuf+5, bBuf+6, Speed);
	
	return genWrite(ID, SMS_STS_ACC, bBuf, 7);
}

// 以寄存器写方式缓存目标位置参数，等待后续统一触发。
int RegWritePosEx(uint8_t ID, int16_t Position, uint16_t Speed, uint8_t ACC)
{
	uint8_t bBuf[7];
	if(Position<0){
		Position = -Position;
		Position |= (1<<15);
	}

	bBuf[0] = ACC;
	Host2SCS(bBuf+1, bBuf+2, Position);
	Host2SCS(bBuf+3, bBuf+4, 0);
	Host2SCS(bBuf+5, bBuf+6, Speed);
	
	return regWrite(ID, SMS_STS_ACC, bBuf, 7);
}

// 把多舵机目标位置、速度和加速度打包成一次同步写，常用于整腿或整机联动。
void SyncWritePosEx(uint8_t ID[], uint8_t IDN, int16_t Position[], uint16_t Speed[], uint8_t ACC[])
{
	uint8_t offbuf[32*7];
	uint8_t i;
	uint16_t V;
  for(i = 0; i<IDN; i++){
		if(Position[i]<0){
			Position[i] = -Position[i];
			Position[i] |= (1<<15);
		}

		if(Speed){
			V = Speed[i];
		}else{
			V = 0;
		}
		if(ACC){
			offbuf[i*7] = ACC[i];
		}else{
			offbuf[i*7] = 0;
		}
		Host2SCS(offbuf+i*7+1, offbuf+i*7+2, Position[i]);
    Host2SCS(offbuf+i*7+3, offbuf+i*7+4, 0);
    Host2SCS(offbuf+i*7+5, offbuf+i*7+6, V);
	}
  syncWrite(ID, IDN, SMS_STS_ACC, offbuf, 7);
}

// 把指定舵机切到轮模式。
int WheelMode(uint8_t ID)
{
	return writeByte(ID, SMS_STS_MODE, 1);		
}

// 在轮模式下给舵机设置转速和加速度。
int WriteSpe(uint8_t ID, int16_t Speed, uint8_t ACC)
{
	uint8_t bBuf[2];
	if(Speed<0){
		Speed = -Speed;
		Speed |= (1<<15);
	}
	bBuf[0] = ACC;
	genWrite(ID, SMS_STS_ACC, bBuf, 1);
	
	Host2SCS(bBuf+0, bBuf+1, Speed);

	genWrite(ID, SMS_STS_GOAL_SPEED_L, bBuf, 2);
	return 1;
}

// 触发舵机当前位置偏移校准。
int CalibrationOfs(uint8_t ID)
{
	return writeByte(ID, SMS_STS_TORQUE_ENABLE, 128);
}

// 解锁舵机 EEPROM，允许修改持久配置。
int unLockEpromEx(uint8_t ID)
{
	return writeByte(ID, SMS_STS_LOCK, 0);
}

// 重新锁定舵机 EEPROM，防止配置被误改。
int LockEpromEx(uint8_t ID)
{
	return writeByte(ID, SMS_STS_LOCK, 1);
}
