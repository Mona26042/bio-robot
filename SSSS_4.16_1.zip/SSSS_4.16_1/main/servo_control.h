/*
 * servo_control.h
 *
 * 舵机控制模块对外接口。
 * 这一层负责“真正向舵机下发控制命令”的动作，包括：
 * 1. 限位裁剪
 * 2. 单个/多个舵机位置写入
 * 3. 整体或按腿开关扭矩
 * 4. 默认姿态恢复
 * 5. 当前角度同步读取
 */

#ifndef SERVO_CONTROL_H
#define SERVO_CONTROL_H

#include <stdint.h>
#include <stdbool.h>
#include "common.h"

// 按舵机 ID 对目标位置进行软件限位裁剪。
// 返回值一定落在该舵机允许的安全范围内。
int16_t limit_servo_position(uint8_t servo_id, int16_t position);

// 打开全部舵机扭矩，使全部关节进入“保持/受控”状态。
void lock_on_all(void);

// 关闭全部舵机扭矩，使全部关节进入“可手动拖动”状态。
void lock_off_all(void);

// 仅打开指定腿的舵机扭矩，leg_num 取值 1~4。
void lock_on_leg(uint8_t leg_num);

// 仅关闭指定腿的舵机扭矩，leg_num 取值 1~4。
void lock_off_leg(uint8_t leg_num);

// 切换指定腿的扭矩状态：开则关、关则开。
void lock_toggle_leg(uint8_t leg_num);

// 将机器人恢复到默认姿态。
// 这通常用于回零、动作结束收尾或调试时快速回到稳定状态。
void restore_default_pose(void);

// 构造“恢复默认姿态”时要发送给 1~count 号舵机的位置数组。
// 如果某个舵机在默认姿态表中没有专门定义，就优先使用 fallback_positions，
// 若 fallback_positions 为 NULL，则退回当前读取到的位置。
void build_restore_default_pose_positions(int16_t *positions,
                                          int count,
                                          const int16_t *fallback_positions);

// 读取全部舵机当前位置，并同步刷新全局位置缓存与网页状态文本。
void sync_read_once(void);

// 以下接口分别对应网页中的单舵机滑块。
// 它们会对目标位置做限位，然后立即给对应 ID 下发位置命令。
void set_servo_position(int16_t position);
void set_servo_position_2(int16_t position);
void set_servo_position_3(int16_t position);
void set_servo_position_4(int16_t position);
void set_servo_position_6(int16_t position);
void set_servo_position_7(int16_t position);
void set_servo_position_8(int16_t position);
void set_servo_position_9(int16_t position);
void set_servo_position_11(int16_t position);
void set_servo_position_12(int16_t position);
void set_servo_position_13(int16_t position);
void set_servo_position_14(int16_t position);
void set_servo_position_16(int16_t position);
void set_servo_position_17(int16_t position);
void set_servo_position_18(int16_t position);
void set_servo_position_19(int16_t position);

// 同步设置 1 号和 2 号舵机位置，使用一帧同步写命令下发。
void set_servo_positions_sync(int16_t pos1, int16_t pos2);

// 通过 Ping 检查 1 号舵机在线状态和总线通信情况。
void ping_servo_id_1(void);

#endif // SERVO_CONTROL_H
