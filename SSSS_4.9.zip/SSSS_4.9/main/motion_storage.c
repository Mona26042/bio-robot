#include "motion_storage.h"

#include <dirent.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "esp_log.h"
#include "esp_spiffs.h"
#include "freertos/FreeRTOS.h"
#include "freertos/semphr.h"

#include "common.h"

#define MOTION_STORAGE_BASE_PATH "/spiffs"
#define MOTION_STORAGE_FILE_EXT ".mot"
#define MOTION_STORAGE_MAGIC "MOT1"
#define MOTION_STORAGE_VERSION 1

typedef struct __attribute__((packed)) {
    char magic[4];
    uint16_t version;
    uint16_t servo_count;
    uint16_t frame_count;
    uint16_t reserved;
    uint32_t total_duration_ms;
    uint32_t payload_checksum;
    char name[MOTION_STORAGE_NAME_MAX_LEN];
} motion_file_header_t;

typedef struct __attribute__((packed)) {
    uint16_t dt_ms;
    int16_t positions[FULL_MOTION_SERVO_COUNT];
} motion_file_frame_t;

static const char *TAG = "MOTION_STORAGE";
static SemaphoreHandle_t s_motion_storage_mutex = NULL;
static bool s_motion_storage_ready = false;
static volatile bool s_motion_storage_busy = false;
static char s_current_motion_name[MOTION_STORAGE_NAME_MAX_LEN] = "No motion";

static bool lock_motion_storage(TickType_t timeout_ticks)
{
    return s_motion_storage_mutex != NULL &&
           xSemaphoreTake(s_motion_storage_mutex, timeout_ticks) == pdTRUE;
}

static void unlock_motion_storage(void)
{
    if (s_motion_storage_mutex != NULL) {
        xSemaphoreGive(s_motion_storage_mutex);
    }
}

static uint32_t checksum_update(uint32_t checksum, const void *data, size_t len)
{
    const uint8_t *bytes = (const uint8_t *)data;

    for (size_t i = 0; i < len; ++i) {
        checksum ^= bytes[i];
        checksum *= 16777619u;
    }

    return checksum;
}

static bool has_motion_file_extension(const char *filename)
{
    if (filename == NULL) {
        return false;
    }

    const size_t filename_len = strlen(filename);
    const size_t ext_len = strlen(MOTION_STORAGE_FILE_EXT);

    return filename_len > ext_len &&
           strcmp(filename + filename_len - ext_len, MOTION_STORAGE_FILE_EXT) == 0;
}

static void extract_motion_name(const char *filename, char *name_buf, size_t name_buf_len)
{
    if (name_buf == NULL || name_buf_len == 0) {
        return;
    }

    name_buf[0] = '\0';
    if (filename == NULL) {
        return;
    }

    const char *dot = strrchr(filename, '.');
    const size_t copy_len = (dot != NULL) ? (size_t)(dot - filename) : strlen(filename);
    snprintf(name_buf, name_buf_len, "%.*s", (int)copy_len, filename);
}

static void build_motion_path(const char *motion_name, char *path_buf, size_t path_buf_len)
{
    snprintf(path_buf, path_buf_len, "%s/%s%s",
             MOTION_STORAGE_BASE_PATH,
             motion_name,
             MOTION_STORAGE_FILE_EXT);
}

static int compare_motion_info(const void *lhs, const void *rhs)
{
    const stored_motion_info_t *left = (const stored_motion_info_t *)lhs;
    const stored_motion_info_t *right = (const stored_motion_info_t *)rhs;
    return strcmp(left->name, right->name);
}

static esp_err_t read_motion_header(FILE *file, motion_file_header_t *header)
{
    if (file == NULL || header == NULL) {
        return ESP_ERR_INVALID_ARG;
    }

    if (fread(header, sizeof(*header), 1, file) != 1) {
        return ESP_FAIL;
    }

    if (memcmp(header->magic, MOTION_STORAGE_MAGIC, sizeof(header->magic)) != 0 ||
        header->version != MOTION_STORAGE_VERSION ||
        header->servo_count != FULL_MOTION_SERVO_COUNT ||
        header->frame_count == 0 ||
        header->frame_count > FULL_MOTION_FRAMES) {
        return ESP_ERR_INVALID_RESPONSE;
    }

    header->name[MOTION_STORAGE_NAME_MAX_LEN - 1] = '\0';
    return ESP_OK;
}

static uint16_t find_next_motion_index_locked(void)
{
    uint16_t max_index = 0;
    DIR *dir = opendir(MOTION_STORAGE_BASE_PATH);

    if (dir == NULL) {
        return 1;
    }

    struct dirent *entry = NULL;
    while ((entry = readdir(dir)) != NULL) {
        if (!has_motion_file_extension(entry->d_name)) {
            continue;
        }

        unsigned int index = 0;
        if (sscanf(entry->d_name, "motion_%u.mot", &index) == 1 && index > max_index) {
            max_index = (uint16_t)index;
        }
    }

    closedir(dir);
    return (uint16_t)(max_index + 1);
}

esp_err_t motion_storage_init(void)
{
    if (s_motion_storage_mutex == NULL) {
        s_motion_storage_mutex = xSemaphoreCreateMutex();
        if (s_motion_storage_mutex == NULL) {
            return ESP_ERR_NO_MEM;
        }
    }

    esp_vfs_spiffs_conf_t conf = {
        .base_path = MOTION_STORAGE_BASE_PATH,
        .partition_label = "storage",
        .max_files = 8,
        .format_if_mount_failed = true,
    };

    esp_err_t err = esp_vfs_spiffs_register(&conf);
    if (err != ESP_OK) {
        ESP_LOGE(TAG, "Failed to mount storage partition: %s", esp_err_to_name(err));
        s_motion_storage_ready = false;
        return err;
    }

    size_t total = 0;
    size_t used = 0;
    err = esp_spiffs_info(conf.partition_label, &total, &used);
    if (err == ESP_OK) {
        ESP_LOGI(TAG, "Storage ready: total=%u bytes used=%u bytes",
                 (unsigned)total,
                 (unsigned)used);
    }

    s_motion_storage_ready = true;
    return ESP_OK;
}

bool motion_storage_is_ready(void)
{
    return s_motion_storage_ready;
}

bool motion_storage_is_busy(void)
{
    return s_motion_storage_busy;
}

const char *motion_storage_get_current_motion_name(void)
{
    return s_current_motion_name;
}

void motion_storage_set_current_motion_name(const char *motion_name)
{
    const char *source_name = motion_name;

    if (source_name == NULL || source_name[0] == '\0') {
        source_name = "No motion";
    }

    snprintf(s_current_motion_name, sizeof(s_current_motion_name), "%s", source_name);
}

size_t motion_storage_list(stored_motion_info_t *entries, size_t max_entries)
{
    if (!s_motion_storage_ready || entries == NULL || max_entries == 0) {
        return 0;
    }

    if (!lock_motion_storage(pdMS_TO_TICKS(1000))) {
        return 0;
    }

    size_t count = 0;
    DIR *dir = opendir(MOTION_STORAGE_BASE_PATH);
    if (dir == NULL) {
        unlock_motion_storage();
        return 0;
    }

    struct dirent *entry = NULL;
    while ((entry = readdir(dir)) != NULL && count < max_entries) {
        if (!has_motion_file_extension(entry->d_name)) {
            continue;
        }

        char motion_name[MOTION_STORAGE_NAME_MAX_LEN];
        char path[64];
        extract_motion_name(entry->d_name, motion_name, sizeof(motion_name));
        build_motion_path(motion_name, path, sizeof(path));

        FILE *file = fopen(path, "rb");
        if (file == NULL) {
            continue;
        }

        motion_file_header_t header;
        esp_err_t err = read_motion_header(file, &header);
        fclose(file);
        if (err != ESP_OK) {
            continue;
        }

        snprintf(entries[count].name, sizeof(entries[count].name), "%s", header.name);
        entries[count].frame_count = header.frame_count;
        entries[count].total_duration_ms = header.total_duration_ms;
        entries[count].is_current = strcmp(header.name, s_current_motion_name) == 0;
        count++;
    }

    closedir(dir);
    qsort(entries, count, sizeof(entries[0]), compare_motion_info);
    unlock_motion_storage();
    return count;
}

esp_err_t motion_storage_save_current_full_motion(char *saved_name,
                                                  size_t saved_name_len,
                                                  uint32_t *saved_checksum)
{
    if (!s_motion_storage_ready) {
        return ESP_ERR_INVALID_STATE;
    }

    if (!has_recorded_motion_full || recorded_frame_count_full == 0) {
        return ESP_ERR_NOT_FOUND;
    }

    if (!lock_motion_storage(pdMS_TO_TICKS(2000))) {
        return ESP_ERR_TIMEOUT;
    }

    s_motion_storage_busy = true;

    const uint16_t next_index = find_next_motion_index_locked();
    char motion_name[MOTION_STORAGE_NAME_MAX_LEN];
    char path[64];
    motion_file_header_t header = {0};
    motion_file_frame_t frame = {0};
    uint32_t checksum = 2166136261u;
    uint32_t total_duration_ms = 0;

    snprintf(motion_name, sizeof(motion_name), "motion_%03u", (unsigned)next_index);
    build_motion_path(motion_name, path, sizeof(path));

    memcpy(header.magic, MOTION_STORAGE_MAGIC, sizeof(header.magic));
    header.version = MOTION_STORAGE_VERSION;
    header.servo_count = FULL_MOTION_SERVO_COUNT;
    header.frame_count = recorded_frame_count_full;
    snprintf(header.name, sizeof(header.name), "%s", motion_name);

    for (uint16_t i = 0; i < recorded_frame_count_full; ++i) {
        total_duration_ms += recorded_motion_full_dt_ms[i];
        checksum = checksum_update(checksum, &recorded_motion_full_dt_ms[i], sizeof(recorded_motion_full_dt_ms[i]));
        checksum = checksum_update(checksum, recorded_motion_full[i], sizeof(recorded_motion_full[i]));
    }

    header.total_duration_ms = total_duration_ms;
    header.payload_checksum = checksum;

    FILE *file = fopen(path, "wb");
    if (file == NULL) {
        s_motion_storage_busy = false;
        unlock_motion_storage();
        return ESP_FAIL;
    }

    bool write_ok = fwrite(&header, sizeof(header), 1, file) == 1;
    for (uint16_t i = 0; write_ok && i < recorded_frame_count_full; ++i) {
        frame.dt_ms = recorded_motion_full_dt_ms[i];
        memcpy(frame.positions, recorded_motion_full[i], sizeof(frame.positions));
        write_ok = fwrite(&frame, sizeof(frame), 1, file) == 1;
    }

    fflush(file);
    fclose(file);

    if (!write_ok) {
        remove(path);
        s_motion_storage_busy = false;
        unlock_motion_storage();
        return ESP_FAIL;
    }

    motion_storage_set_current_motion_name(motion_name);
    if (saved_name != NULL && saved_name_len > 0) {
        snprintf(saved_name, saved_name_len, "%s", motion_name);
    }
    if (saved_checksum != NULL) {
        *saved_checksum = checksum;
    }

    s_motion_storage_busy = false;
    unlock_motion_storage();
    return ESP_OK;
}

esp_err_t motion_storage_load_full_motion(const char *motion_name, uint32_t *loaded_checksum)
{
    if (!s_motion_storage_ready || motion_name == NULL || motion_name[0] == '\0') {
        return ESP_ERR_INVALID_ARG;
    }

    if (!lock_motion_storage(pdMS_TO_TICKS(2000))) {
        return ESP_ERR_TIMEOUT;
    }

    s_motion_storage_busy = true;

    char path[64];
    build_motion_path(motion_name, path, sizeof(path));

    FILE *file = fopen(path, "rb");
    if (file == NULL) {
        s_motion_storage_busy = false;
        unlock_motion_storage();
        return ESP_ERR_NOT_FOUND;
    }

    motion_file_header_t header;
    esp_err_t err = read_motion_header(file, &header);
    if (err != ESP_OK) {
        fclose(file);
        s_motion_storage_busy = false;
        unlock_motion_storage();
        return err;
    }

    const size_t positions_bytes =
        (size_t)header.frame_count * sizeof(recorded_motion_full[0]);
    const size_t dts_bytes =
        (size_t)header.frame_count * sizeof(recorded_motion_full_dt_ms[0]);

    int16_t (*loaded_positions)[FULL_MOTION_SERVO_COUNT] = malloc(positions_bytes);
    uint16_t *loaded_dts = malloc(dts_bytes);
    if (loaded_positions == NULL || loaded_dts == NULL) {
        free(loaded_positions);
        free(loaded_dts);
        fclose(file);
        s_motion_storage_busy = false;
        unlock_motion_storage();
        return ESP_ERR_NO_MEM;
    }

    uint32_t checksum = 2166136261u;
    motion_file_frame_t frame = {0};
    bool read_ok = true;

    for (uint16_t i = 0; i < header.frame_count; ++i) {
        if (fread(&frame, sizeof(frame), 1, file) != 1) {
            read_ok = false;
            break;
        }

        loaded_dts[i] = frame.dt_ms;
        memcpy(loaded_positions[i], frame.positions, sizeof(frame.positions));
        checksum = checksum_update(checksum, &loaded_dts[i], sizeof(loaded_dts[i]));
        checksum = checksum_update(checksum, loaded_positions[i], sizeof(loaded_positions[i]));
    }

    fclose(file);

    if (!read_ok || checksum != header.payload_checksum) {
        free(loaded_positions);
        free(loaded_dts);
        s_motion_storage_busy = false;
        unlock_motion_storage();
        return !read_ok ? ESP_FAIL : ESP_ERR_INVALID_CRC;
    }

    clear_recorded_full_motion();
    memcpy(recorded_motion_full, loaded_positions, positions_bytes);
    memcpy(recorded_motion_full_dt_ms, loaded_dts, dts_bytes);
    recorded_frame_count_full = header.frame_count;
    has_recorded_motion_full = true;
    replay_frame_index_full = 0;
    dropped_frame_count_full = 0;

    motion_storage_set_current_motion_name(header.name);
    if (loaded_checksum != NULL) {
        *loaded_checksum = checksum;
    }

    free(loaded_positions);
    free(loaded_dts);
    s_motion_storage_busy = false;
    unlock_motion_storage();
    return ESP_OK;
}

esp_err_t motion_storage_delete_full_motion(const char *motion_name)
{
    if (!s_motion_storage_ready) {
        return ESP_ERR_INVALID_STATE;
    }

    if (motion_name == NULL || motion_name[0] == '\0') {
        return ESP_ERR_INVALID_ARG;
    }

    if (!lock_motion_storage(pdMS_TO_TICKS(2000))) {
        return ESP_ERR_TIMEOUT;
    }

    s_motion_storage_busy = true;

    char path[64];
    build_motion_path(motion_name, path, sizeof(path));

    FILE *file = fopen(path, "rb");
    if (file == NULL) {
        s_motion_storage_busy = false;
        unlock_motion_storage();
        return ESP_ERR_NOT_FOUND;
    }
    fclose(file);

    if (remove(path) != 0) {
        s_motion_storage_busy = false;
        unlock_motion_storage();
        return ESP_FAIL;
    }

    if (strcmp(motion_name, s_current_motion_name) == 0) {
        motion_storage_set_current_motion_name(NULL);
    }

    s_motion_storage_busy = false;
    unlock_motion_storage();
    return ESP_OK;
}

esp_err_t motion_storage_delete_all_full_motion(size_t *deleted_count)
{
    if (!s_motion_storage_ready) {
        return ESP_ERR_INVALID_STATE;
    }

    if (!lock_motion_storage(pdMS_TO_TICKS(2000))) {
        return ESP_ERR_TIMEOUT;
    }

    s_motion_storage_busy = true;

    size_t local_deleted_count = 0;
    bool had_any_motion = false;
    bool current_deleted = false;
    bool delete_failed = false;
    DIR *dir = opendir(MOTION_STORAGE_BASE_PATH);

    if (dir == NULL) {
        s_motion_storage_busy = false;
        unlock_motion_storage();
        return ESP_FAIL;
    }

    struct dirent *entry = NULL;
    while ((entry = readdir(dir)) != NULL) {
        if (!has_motion_file_extension(entry->d_name)) {
            continue;
        }

        had_any_motion = true;

        char motion_name[MOTION_STORAGE_NAME_MAX_LEN];
        char path[64];
        extract_motion_name(entry->d_name, motion_name, sizeof(motion_name));
        build_motion_path(motion_name, path, sizeof(path));

        if (remove(path) != 0) {
            delete_failed = true;
            continue;
        }

        local_deleted_count++;
        if (strcmp(motion_name, s_current_motion_name) == 0) {
            current_deleted = true;
        }
    }

    closedir(dir);

    if (deleted_count != NULL) {
        *deleted_count = local_deleted_count;
    }

    if (current_deleted || (had_any_motion && !delete_failed)) {
        motion_storage_set_current_motion_name(NULL);
    }

    s_motion_storage_busy = false;
    unlock_motion_storage();
    return delete_failed ? ESP_FAIL : ESP_OK;
}
