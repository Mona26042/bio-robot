#include "wifi_ctrl.h"
#include "esp_event.h"
#include "esp_log.h"
#include "esp_netif.h"
#include "esp_netif_ip_addr.h"
#include "esp_wifi.h"

#include <assert.h>
#include <string.h>

// 当前工程固定连接这个热点，Web 控制页面也依赖这条链路。
#define WIFI_SSID "MRAN 0787"
#define WIFI_PASS "12345678"

static const char *TAG __attribute__((unused)) = "WIFI_CTRL";

// 记录连续断线次数，主要用于日志观察网络稳定性。
static int s_wifi_disconnect_count = 0;

// Wi-Fi 和 IP 事件统一回调。
// 这里处理三个关键阶段：启动、掉线、获取到 IP。
static void wifi_event_handler(void *arg, esp_event_base_t event_base,
                               int32_t event_id, void *event_data)
{
    (void)arg;

    if (event_base == WIFI_EVENT && event_id == WIFI_EVENT_STA_START) {
        // STA 启动后立即尝试连接热点。
        ESP_LOGI(TAG, "Wi-Fi started, connecting to \"%s\"", WIFI_SSID);
        esp_wifi_connect();
    } else if (event_base == WIFI_EVENT && event_id == WIFI_EVENT_STA_DISCONNECTED) {
        // 掉线时自动重连，并输出断线原因。
        wifi_event_sta_disconnected_t *disconnected =
            (wifi_event_sta_disconnected_t *)event_data;
        s_wifi_disconnect_count++;
        ESP_LOGW(TAG, "Wi-Fi disconnected, reason=%d, reconnect_count=%d",
                 disconnected ? disconnected->reason : -1,
                 s_wifi_disconnect_count);
        esp_wifi_connect();
    } else if (event_base == IP_EVENT && event_id == IP_EVENT_STA_GOT_IP) {
        // 一旦拿到 IP，说明当前网络已经可用，断线计数清零。
        ip_event_got_ip_t *got_ip = (ip_event_got_ip_t *)event_data;
        s_wifi_disconnect_count = 0;
        ESP_LOGI(TAG, "Got IP: " IPSTR, IP2STR(&got_ip->ip_info.ip));
    }
}

// 初始化 Wi-Fi 站点模式。
// 这是整个网络子系统的入口，会被 app_main() 在启动阶段调用。
void wifi_init_sta(void)
{
    ESP_ERROR_CHECK(esp_netif_init());
    ESP_ERROR_CHECK(esp_event_loop_create_default());

    // 创建默认 STA 网络接口，供后续 Wi-Fi 驱动绑定。
    esp_netif_t *sta_netif = esp_netif_create_default_wifi_sta();
    assert(sta_netif);

    wifi_init_config_t cfg = WIFI_INIT_CONFIG_DEFAULT();
    ESP_ERROR_CHECK(esp_wifi_init(&cfg));

    ESP_ERROR_CHECK(esp_event_handler_instance_register(WIFI_EVENT,
                                                        ESP_EVENT_ANY_ID,
                                                        &wifi_event_handler,
                                                        NULL,
                                                        NULL));
    ESP_ERROR_CHECK(esp_event_handler_instance_register(IP_EVENT,
                                                        IP_EVENT_STA_GOT_IP,
                                                        &wifi_event_handler,
                                                        NULL,
                                                        NULL));

    // 把 SSID、密码和安全策略写入配置结构体。
    wifi_config_t wifi_config = { 0 };
    strcpy((char *)wifi_config.sta.ssid, WIFI_SSID);
    strcpy((char *)wifi_config.sta.password, WIFI_PASS);
    wifi_config.sta.threshold.authmode = WIFI_AUTH_WPA2_PSK;
    wifi_config.sta.pmf_cfg.capable = true;
    wifi_config.sta.pmf_cfg.required = false;

    ESP_ERROR_CHECK(esp_wifi_set_mode(WIFI_MODE_STA));
    ESP_ERROR_CHECK(esp_wifi_set_config(WIFI_IF_STA, &wifi_config));
    ESP_ERROR_CHECK(esp_wifi_start());

    // Web 控制依赖网络响应，关闭省电能换取更稳定的交互时延。
    ESP_ERROR_CHECK(esp_wifi_set_ps(WIFI_PS_NONE));

    ESP_LOGI(TAG, "Wi-Fi power save disabled for better web responsiveness");
}
