/*
 * wifi_ctrl.h
 *
 * Wi-Fi 站点模式初始化接口。
 * 工程启动后会调用这里完成网络栈、事件循环以及 STA 连接配置。
 */

#ifndef WIFI_CTRL_H
#define WIFI_CTRL_H

// 初始化 Wi-Fi 站点模式并开始连接预设热点。
void wifi_init_sta(void);

#endif // WIFI_CTRL_H
