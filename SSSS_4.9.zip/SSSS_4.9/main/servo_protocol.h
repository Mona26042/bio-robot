/*
 * servo_protocol.h
 *
 * 舵机协议层声明。
 * 这一层封装了 SMS/STS 舵机常用的读写命令、同步读写命令、应答解析、
 * 以及协议字节与主机整数之间的转换逻辑。
 */

#ifndef _SERVO_PROTOCOL_H
#define _SERVO_PROTOCOL_H

#include <stdint.h>

#ifndef NULL
#define NULL ((void *)0)
#endif

// 协议指令码。
#define INST_PING 0x01
#define INST_READ 0x02
#define INST_WRITE 0x03
#define INST_REG_WRITE 0x04
#define INST_REG_ACTION 0x05
#define INST_SYNC_READ 0x82
#define INST_SYNC_WRITE 0x83
#define INST_RESET 0x0A
#define INST_OFSCAL 0x0B

// 协议解析时可能记录的错误类型。
enum SCS_ERR_LIST
{
    SCS_ERR_NO_REPLY = 1,
    SCS_ERR_CRC_CMP  = 2,
    SCS_ERR_SLAVE_ID = 3,
    SCS_ERR_BUFF_LEN = 4,
};

// 基础读写接口。
extern int genWrite(uint8_t ID, uint8_t MemAddr, uint8_t *nDat, uint8_t nLen);
extern int regWrite(uint8_t ID, uint8_t MemAddr, uint8_t *nDat, uint8_t nLen);
extern int regAction(uint8_t ID);
extern void syncWrite(uint8_t ID[], uint8_t IDN, uint8_t MemAddr, uint8_t *nDat,
                      uint8_t nLen);
extern int writeByte(uint8_t ID, uint8_t MemAddr, uint8_t bDat);
extern int writeWord(uint8_t ID, uint8_t MemAddr, uint16_t wDat);
extern int Read(uint8_t ID, uint8_t MemAddr, uint8_t *nData, uint8_t nLen);
extern int readByte(uint8_t ID, uint8_t MemAddr);
extern int readWord(uint8_t ID, uint8_t MemAddr);
extern int Ping(uint8_t ID);
extern int Reset(uint8_t ID);

// 同步读相关接口与调试变量。
extern int syncReadPacketTx(uint8_t ID[], uint8_t IDN, uint8_t MemAddr, uint8_t nLen);
extern int syncReadPacketRx(uint8_t ID, uint8_t *nDat);
extern int syncReadRxPacketToByte(void);
extern int syncReadRxPacketToWord(uint8_t negBit);
extern void syncReadBegin(uint8_t IDN, uint8_t rxLen);
extern void syncReadEnd(void);
extern int syncReadPacketAppend(void);
extern uint16_t syncReadRxBuffLen;
extern uint16_t syncReadRxBuffMax;

// 数据打包、字节序转换和应答解析辅助函数。
extern void writeBuf(uint8_t ID, uint8_t MemAddr, uint8_t *nDat,
                     uint8_t nLen, uint8_t Fun);
extern void Host2SCS(uint8_t *DataL, uint8_t *DataH, int Data);
extern int SCS2Host(uint8_t DataL, uint8_t DataH);
extern int Ack(uint8_t ID);
extern int checkHead(void);

// 协议层内部状态访问接口。
extern void setEnd(uint8_t _End);
extern uint8_t getEnd(void);
extern void setLevel(uint8_t _Level);
extern int getState(void);
extern int getLastError(void);

// 与 uart_servo.c 对接的底层收发接口。
extern int writeSCS(uint8_t *nDat, int nLen);
extern int writeByteSCS(unsigned char bDat);
extern int readSCS(uint8_t *nDat, int nLen);
extern void rFlushSCS(void);
extern void wFlushSCS(void);

// SCSCL 波特率枚举值。
#define SCSCL_1M 0
#define SCSCL_0_5M 1
#define SCSCL_250K 2
#define SCSCL_128K 3
#define SCSCL_115200 4
#define SCSCL_76800 5
#define SCSCL_57600 6
#define SCSCL_38400 7

// SCSCL EPROM 区寄存器地址。
#define SCSCL_MODEL_L 3
#define SCSCL_MODEL_H 4
#define SCSCL_ID 5
#define SCSCL_BAUD_RATE 6
#define SCSCL_MIN_ANGLE_LIMIT_L 9
#define SCSCL_MIN_ANGLE_LIMIT_H 10
#define SCSCL_MAX_ANGLE_LIMIT_L 11
#define SCSCL_MAX_ANGLE_LIMIT_H 12
#define SCSCL_CW_DEAD 26
#define SCSCL_CCW_DEAD 27

// SCSCL SRAM 区寄存器地址。
#define SCSCL_TORQUE_ENABLE 40
#define SCSCL_GOAL_POSITION_L 42
#define SCSCL_GOAL_POSITION_H 43
#define SCSCL_GOAL_TIME_L 44
#define SCSCL_GOAL_TIME_H 45
#define SCSCL_GOAL_SPEED_L 46
#define SCSCL_GOAL_SPEED_H 47
#define SCSCL_LOCK 48
#define SCSCL_PRESENT_POSITION_L 56
#define SCSCL_PRESENT_POSITION_H 57
#define SCSCL_PRESENT_SPEED_L 58
#define SCSCL_PRESENT_SPEED_H 59
#define SCSCL_PRESENT_LOAD_L 60
#define SCSCL_PRESENT_LOAD_H 61
#define SCSCL_PRESENT_VOLTAGE 62
#define SCSCL_PRESENT_TEMPERATURE 63
#define SCSCL_MOVING 66
#define SCSCL_PRESENT_CURRENT_L 69
#define SCSCL_PRESENT_CURRENT_H 70

// SMS/STS 波特率枚举值。
#define SMS_STS_1M 0
#define SMS_STS_0_5M 1
#define SMS_STS_250K 2
#define SMS_STS_128K 3
#define SMS_STS_115200 4
#define SMS_STS_76800 5
#define SMS_STS_57600 6
#define SMS_STS_38400 7

// SMS/STS EPROM 区寄存器地址。
#define SMS_STS_MODEL_L 3
#define SMS_STS_MODEL_H 4
#define SMS_STS_ID 5
#define SMS_STS_BAUD_RATE 6
#define SMS_STS_MIN_ANGLE_LIMIT_L 9
#define SMS_STS_MIN_ANGLE_LIMIT_H 10
#define SMS_STS_MAX_ANGLE_LIMIT_L 11
#define SMS_STS_MAX_ANGLE_LIMIT_H 12
#define SMS_STS_CW_DEAD 26
#define SMS_STS_CCW_DEAD 27
#define SMS_STS_OFS_L 31
#define SMS_STS_OFS_H 32
#define SMS_STS_MODE 33

// SMS/STS SRAM 区寄存器地址。
#define SMS_STS_TORQUE_ENABLE 40
#define SMS_STS_ACC 41
#define SMS_STS_GOAL_POSITION_L 42
#define SMS_STS_GOAL_POSITION_H 43
#define SMS_STS_GOAL_TIME_L 44
#define SMS_STS_GOAL_TIME_H 45
#define SMS_STS_GOAL_SPEED_L 46
#define SMS_STS_GOAL_SPEED_H 47
#define SMS_STS_LOCK 55
#define SMS_STS_PRESENT_POSITION_L 56
#define SMS_STS_PRESENT_POSITION_H 57
#define SMS_STS_PRESENT_SPEED_L 58
#define SMS_STS_PRESENT_SPEED_H 59
#define SMS_STS_PRESENT_LOAD_L 60
#define SMS_STS_PRESENT_LOAD_H 61
#define SMS_STS_PRESENT_VOLTAGE 62
#define SMS_STS_PRESENT_TEMPERATURE 63
#define SMS_STS_MOVING 66
#define SMS_STS_PRESENT_CURRENT_L 69
#define SMS_STS_PRESENT_CURRENT_H 70

// 面向 SMS/STS 常用控制场景的高级接口。
extern int WritePosEx(uint8_t ID, int16_t Position, uint16_t Speed, uint8_t ACC);
extern int RegWritePosEx(uint8_t ID, int16_t Position, uint16_t Speed, uint8_t ACC);
extern void SyncWritePosEx(uint8_t ID[], uint8_t IDN, int16_t Position[], uint16_t Speed[], uint8_t ACC[]);
extern int WheelMode(uint8_t ID);
extern int WriteSpe(uint8_t ID, int16_t Speed, uint8_t ACC);
extern int CalibrationOfs(uint8_t ID);
extern int unLockEpromEx(uint8_t ID);
extern int LockEpromEx(uint8_t ID);

#endif // _SERVO_PROTOCOL_H
