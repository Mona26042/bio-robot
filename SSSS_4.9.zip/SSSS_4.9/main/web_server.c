﻿/*
 * web_server.c
 * 内置网页控制界面实现。
 * 提供静态首页、状态面板、按钮状态 JSON 接口以及 `/set` 控制入口，
 * 用于把浏览器操作转换成全局命令或目标位置。
 */

#include "web_server.h"
#include "common.h"
#include "motion_storage.h"
#include "servo_control.h"
#include "esp_log.h"
#include "esp_http_server.h"
#include <ctype.h>
#include <string.h>
#include <stdlib.h>

static const char *TAG = "WEB_SERVER";
static char s_motion_list_json_buf[8192];

// 把网页滑块前缀、对应舵机、限位范围和目标缓存绑定成统一表项，便于集中解析。
typedef struct {
    const char *prefix;
    size_t prefix_len;
    uint8_t servo_id;
    int16_t min_pos;
    int16_t max_pos;
    volatile int16_t *target_position;
    volatile bool *need_update;
} slider_binding_t;

typedef struct {
    const char *value;
    servo_cmd_t cmd;
} button_command_binding_t;

// 每个网页滑块都在这里映射到具体的舵机 ID、限位范围和待更新标志。
static const slider_binding_t s_slider_bindings[] = {
    {"Slider_Pos_", 11, 1, SERVO_LF1_POS_MIN, SERVO_LF1_POS_MAX, &g_target_position, &g_need_update_pos1},
    {"Slider_Pos2_", 12, 2, SERVO_LF2_POS_MIN, SERVO_LF2_POS_MAX, &g_target_position_2, &g_need_update_pos2},
    {"Slider_Pos3_", 12, 3, SERVO_LF3_POS_MIN, SERVO_LF3_POS_MAX, &g_target_position_3, &g_need_update_pos3},
    {"Slider_Pos4_", 12, 4, SERVO_LF4_POS_MIN, SERVO_LF4_POS_MAX, &g_target_position_4, &g_need_update_pos4},
    {"Slider_Pos6_", 12, 6, SERVO_6_POS_MIN, SERVO_6_POS_MAX, &g_target_position_6, &g_need_update_pos6},
    {"Slider_Pos7_", 12, 7, SERVO_7_POS_MIN, SERVO_7_POS_MAX, &g_target_position_7, &g_need_update_pos7},
    {"Slider_Pos8_", 12, 8, SERVO_8_POS_MIN, SERVO_8_POS_MAX, &g_target_position_8, &g_need_update_pos8},
    {"Slider_Pos9_", 12, 9, SERVO_9_POS_MIN, SERVO_9_POS_MAX, &g_target_position_9, &g_need_update_pos9},
    {"Slider_Pos11_", 13, 11, SERVO_11_POS_MIN, SERVO_11_POS_MAX, &g_target_position_11, &g_need_update_pos11},
    {"Slider_Pos12_", 13, 12, SERVO_12_POS_MIN, SERVO_12_POS_MAX, &g_target_position_12, &g_need_update_pos12},
    {"Slider_Pos13_", 13, 13, SERVO_13_POS_MIN, SERVO_13_POS_MAX, &g_target_position_13, &g_need_update_pos13},
    {"Slider_Pos14_", 13, 14, SERVO_14_POS_MIN, SERVO_14_POS_MAX, &g_target_position_14, &g_need_update_pos14},
    {"Slider_Pos16_", 13, 16, SERVO_16_POS_MIN, SERVO_16_POS_MAX, &g_target_position_16, &g_need_update_pos16},
    {"Slider_Pos17_", 13, 17, SERVO_17_POS_MIN, SERVO_17_POS_MAX, &g_target_position_17, &g_need_update_pos17},
    {"Slider_Pos18_", 13, 18, SERVO_18_POS_MIN, SERVO_18_POS_MAX, &g_target_position_18, &g_need_update_pos18},
    {"Slider_Pos19_", 13, 19, SERVO_19_POS_MIN, SERVO_19_POS_MAX, &g_target_position_19, &g_need_update_pos19},
};

static const button_command_binding_t s_button_command_bindings[] = {
    {"Button_Lockon", CMD_LOCK_ON},
    {"Button_Lockoff", CMD_LOCK_OFF},
    {"Button_RestorePose", CMD_RESTORE_POSE},
    {"Button_SyncRead", CMD_SYNC_READ},
    {"Button_ReadAngleMode", CMD_READ_ANGLE_MODE},
    {"Button_RecordLeg1", CMD_RECORD_LEG1},
    {"Button_ReplayLeg1", CMD_REPLAY_LEG1},
    {"Button_RecordLeg2", CMD_RECORD_LEG2},
    {"Button_ReplayLeg2", CMD_REPLAY_LEG2},
    {"Button_RecordLeg3", CMD_RECORD_LEG3},
    {"Button_ReplayLeg3", CMD_REPLAY_LEG3},
    {"Button_RecordLeg4", CMD_RECORD_LEG4},
    {"Button_ReplayLeg4", CMD_REPLAY_LEG4},
    {"Button_RecordFullMotion", CMD_RECORD_FULL},
    {"Button_ReplayFullMotion", CMD_REPLAY_FULL},
    {"Button_LockLeg1", CMD_LOCK_LEG1},
    {"Button_LockLeg2", CMD_LOCK_LEG2},
    {"Button_LockLeg3", CMD_LOCK_LEG3},
    {"Button_LockLeg4", CMD_LOCK_LEG4},
    {"Button_ReplayMotion1", CMD_REPLAY_MOTION1},
    {"Button_WriteShow", CMD_WRITE_SHOW},
    {"Button_PingId1", CMD_PING_ID1},
    {"Button_WriteShow2", CMD_WRITE_SHOW_2},
    {"Button_DualServoRotate", CMD_DUAL_SERVO_ROTATE},
    {"Button_FixedGait", CMD_FIXED_GAIT},
};

// 按表驱动方式解析滑块字符串并更新对应舵机目标值。
// 尝试把 /set 请求里的字符串解析成某个滑块更新，并把结果写入共享目标值。
static bool try_handle_slider_value(const char *value)
{
    for (size_t i = 0; i < sizeof(s_slider_bindings) / sizeof(s_slider_bindings[0]); ++i) {
        const slider_binding_t *binding = &s_slider_bindings[i];
        if (strncmp(value, binding->prefix, binding->prefix_len) != 0) {
            continue;
        }

        int pos = atoi(value + binding->prefix_len);
        pos = (int)limit_servo_position(binding->servo_id, (int16_t)pos);

        if (pos >= binding->min_pos && pos <= binding->max_pos) {
            *binding->target_position = (int16_t)pos;
            *binding->need_update = true;
        } else {
            ESP_LOGW(TAG, "%d号舵机滑块位置值超出限位范围: %d (限位: %d-%d)",
                     binding->servo_id, pos, binding->min_pos, binding->max_pos);
        }

        return true;
    }

    return false;
}

static bool try_handle_button_command(const char *value)
{
    for (size_t i = 0; i < sizeof(s_button_command_bindings) / sizeof(s_button_command_bindings[0]); ++i) {
        const button_command_binding_t *binding = &s_button_command_bindings[i];
        if (strcmp(value, binding->value) == 0) {
            g_cmd = binding->cmd;
            return true;
        }
    }

    return false;
}

static bool try_handle_loop_count_value(const char *value)
{
    const char *loop_value = NULL;

    if (strncmp(value, "FullLoop_", 9) == 0) {
        loop_value = value + 9;
    } else if (strncmp(value, "TeachLoop_", 10) == 0) {
        loop_value = value + 10;
    } else {
        return false;
    }

    long loop_count = strtol(loop_value, NULL, 10);
    if (loop_count < 0) {
        loop_count = 0;
    } else if (loop_count > 9999) {
        loop_count = 9999;
    }

    g_teach_replay_loop_count = (uint16_t)loop_count;
    return true;
}

static bool motion_library_command_allowed(void)
{
    return motion_storage_is_ready() &&
           !motion_storage_is_busy() &&
           g_cmd == CMD_NONE &&
           !g_read_angle_mode &&
           !g_record_leg1_mode &&
           !g_record_leg2_mode &&
           !g_record_leg3_mode &&
           !g_record_leg4_mode &&
           !g_replay_leg1_mode &&
           !g_replay_leg2_mode &&
           !g_replay_leg3_mode &&
           !g_replay_leg4_mode &&
           !g_record_full_mode &&
           !g_replay_full_mode &&
           !g_replay_full_transition_mode &&
           !g_replay_motion1_mode;
}

static bool is_valid_motion_name(const char *name)
{
    if (name == NULL || name[0] == '\0') {
        return false;
    }

    size_t length = strlen(name);
    if (length >= FULL_MOTION_NAME_MAX_LEN) {
        return false;
    }

    for (size_t i = 0; i < length; ++i) {
        const unsigned char ch = (unsigned char)name[i];
        if (!(isalnum(ch) || ch == '_' || ch == '-')) {
            return false;
        }
    }

    return true;
}

static esp_err_t send_json_text(httpd_req_t *req, const char *status, const char *json_text)
{
    httpd_resp_set_status(req, status);
    httpd_resp_set_type(req, "application/json");
    return httpd_resp_send(req, json_text, HTTPD_RESP_USE_STRLEN);
}

// 首页 HTML，内含控制按钮、滑块和前端轮询脚本。
// 内嵌网页前端：按钮、滑块、状态面板和交互脚本都直接放在这段 HTML 里。
static const char index_html[] =
"<!DOCTYPE html><html><head><meta charset='UTF-8'>"
"<meta name='viewport' content='width=device-width,initial-scale=1.0'/>"
"<title>STS3032 示教控制系统</title>"
"<style>"
"*{box-sizing:border-box;margin:0;padding:0;}"
"body{font-family:'Segoe UI',Tahoma,Geneva,Verdana,sans-serif;background:linear-gradient(135deg,#667eea 0%,#764ba2 100%);min-height:100vh;padding:20px;color:#333;}"
".container{max-width:1400px;margin:0 auto;background:#fff;border-radius:20px;box-shadow:0 20px 60px rgba(0,0,0,0.3);overflow:hidden;}"
".header{background:linear-gradient(135deg,#667eea 0%,#764ba2 100%);color:#fff;padding:30px;text-align:center;}"
".header h1{font-size:2.5em;margin-bottom:10px;font-weight:300;letter-spacing:2px;}"
".header p{font-size:1.1em;opacity:0.9;}"
".content{padding:30px;}"
".section{background:#f8f9fa;border-radius:15px;padding:25px;margin-bottom:25px;box-shadow:0 4px 6px rgba(0,0,0,0.1);}"
".section-title{font-size:1.8em;color:#667eea;margin-bottom:20px;padding-bottom:10px;border-bottom:3px solid #667eea;display:flex;align-items:center;}"
".section-title:before{content:'⚙';margin-right:10px;font-size:1.2em;}"
".btn-group{display:flex;flex-wrap:wrap;gap:12px;margin-bottom:20px;}"
"button{border:none;padding:12px 24px;border-radius:8px;font-size:1em;font-weight:500;cursor:pointer;transition:all 0.3s;box-shadow:0 2px 4px rgba(0,0,0,0.2);}"
"button:hover{transform:translateY(-2px);box-shadow:0 4px 8px rgba(0,0,0,0.3);}"
"button:active{transform:translateY(0);}"
"button:disabled{opacity:0.6;cursor:not-allowed;transform:none;}"
".btn-primary{background:#2196F3;color:#fff;}"
".btn-success{background:#4CAF50;color:#fff;}"
".btn-warning{background:#FF9800;color:#fff;}"
".btn-danger{background:#f44336;color:#fff;}"
".btn-info{background:#00BCD4;color:#fff;}"
".slider-container{background:#fff;border-radius:12px;padding:20px;margin-bottom:15px;box-shadow:0 2px 8px rgba(0,0,0,0.1);border-left:4px solid #667eea;}"
".slider-container label{display:flex;justify-content:space-between;align-items:center;margin-bottom:15px;font-weight:600;font-size:1.1em;color:#555;}"
".slider-value{font-size:1.5em;color:#667eea;font-weight:bold;background:#f0f4ff;padding:5px 15px;border-radius:8px;min-width:80px;text-align:center;}"
"input[type='range']{width:100%;height:8px;border-radius:5px;background:#ddd;outline:none;margin:10px 0;}"
"input[type='range']::-webkit-slider-thumb{appearance:none;width:20px;height:20px;border-radius:50%;background:#667eea;cursor:pointer;box-shadow:0 2px 4px rgba(0,0,0,0.3);}"
"input[type='range']::-moz-range-thumb{width:20px;height:20px;border-radius:50%;background:#667eea;cursor:pointer;border:none;box-shadow:0 2px 4px rgba(0,0,0,0.3);}"
".slider-hint{font-size:0.85em;color:#888;margin-top:8px;padding:8px;background:#f9f9f9;border-radius:6px;}"
"#dht{background:#fff;border-radius:12px;padding:20px;margin-top:25px;box-shadow:0 2px 8px rgba(0,0,0,0.1);}"
"#dht h2{color:#667eea;margin-bottom:15px;padding-bottom:10px;border-bottom:2px solid #eee;}"
"#dht p,#dht div{margin:8px 0;padding:8px;background:#f9f9f9;border-radius:6px;}"
".status-info{display:grid;grid-template-columns:repeat(auto-fit,minmax(250px,1fr));gap:15px;margin-top:15px;}"
".info-card{background:#fff;padding:15px;border-radius:10px;box-shadow:0 2px 4px rgba(0,0,0,0.1);border-left:4px solid #4CAF50;}"
".info-card strong{color:#667eea;display:block;margin-bottom:5px;}"
".motion-library-panel{background:#fff;border-radius:12px;padding:18px;box-shadow:0 2px 8px rgba(0,0,0,0.08);border:1px solid #e5e9f2;}"
".motion-library-header{display:flex;flex-wrap:wrap;gap:12px;align-items:center;justify-content:space-between;margin-bottom:14px;}"
".motion-current{padding:12px 14px;background:#f0f4ff;border-radius:10px;color:#334155;min-width:260px;}"
".motion-current strong{display:block;color:#667eea;margin-bottom:4px;}"
".motion-library-status{color:#666;font-size:0.92em;margin-bottom:12px;}"
".motion-list{display:grid;grid-template-columns:repeat(auto-fit,minmax(260px,1fr));gap:12px;}"
".motion-item{border:1px solid #d9e2f1;border-radius:12px;padding:14px;background:#fbfcff;}"
".motion-item.current{border-color:#4CAF50;box-shadow:0 0 0 2px rgba(76,175,80,0.12) inset;}"
".motion-title{font-size:1.05em;font-weight:700;color:#334155;margin-bottom:8px;word-break:break-word;}"
".motion-meta{color:#5b6475;font-size:0.92em;line-height:1.5;margin-bottom:12px;}"
".motion-actions{display:flex;flex-wrap:wrap;gap:10px;}"
".motion-actions button{flex:1 1 110px;padding:10px 14px;}"
"@media (max-width:768px){.header h1{font-size:1.8em;}.content{padding:15px;}.btn-group{flex-direction:column;}button{width:100%;}}"
"</style>"
"</head><body>"
"<div class='container'>"
"<div class='header'>"
"<h1>🤖 STS3032 示教控制系统</h1>"
"<p>示教与编程控制系统</p>"
"</div>"
"<div class='content'>"
"<div class='section'>"
"<div class='section-title'>基础控制</div>"
"<div class='btn-group'>"
"<button class='btn-success' onclick=\"send('Button_Lockon',this)\">🔓 开启扭矩</button>"
"<button class='btn-danger' onclick=\"send('Button_Lockoff',this)\">🔒 关闭扭矩</button>"
"<button class='btn-info' onclick=\"send('Button_RestorePose',this)\">↺ 恢复姿态</button>"
"<button class='btn-primary' onclick=\"send('Button_SyncRead',this)\">📊 读取角度</button>"
"</div>"
"</div>"
"<div class='section'>"
"<div class='section-title'>示教功能</div>"
"<p style='margin-bottom:15px;color:#666;font-size:0.95em;'>✨ 示教模式：先关闭扭矩，手动调整机器人姿态，然后录入并复现动作序列</p>"
"<div class='btn-group'>"
"<button class='btn-success' onclick=\"send('Button_ReadAngleMode',this)\" id='btnReadAngleMode'>📡 开启读取角度模式</button>"
"<button class='btn-info' onclick=\"startTeachReplay(this)\" id='btnReplayMotion1'>🎯 示教复现</button>"
"</div>"
"<div class='btn-group'>"
"<button class='btn-primary' onclick=\"send('Button_RecordFullMotion',this)\" id='btnRecordFullMotion'>录入整套动作</button>"
"<button class='btn-warning' onclick=\"startFullReplay(this)\" id='btnReplayFullMotion'>复现整套动作</button>"
"</div>"
"<div style='display:flex;flex-wrap:wrap;gap:12px;align-items:center;margin-bottom:18px;'>"
"<label for='teachLoopCount' style='font-weight:600;color:#555;'>整套动作循环次数</label>"
"<input type='number' id='teachLoopCount' min='0' max='9999' value='0' "
"style='width:120px;padding:10px 12px;border:1px solid #ccd3e0;border-radius:8px;font-size:1em;'>"
"<span style='color:#666;font-size:0.9em;'>0 = 无限循环，仅对整套动作复现生效</span>"
"</div>"
"<div class='motion-library-panel'>"
"<div class='motion-library-header'>"
"<div class='motion-current'><strong>当前整套动作</strong><span id='currentFullMotionName'>No motion</span></div>"
"<div style='display:flex;flex-wrap:wrap;gap:10px;'>"
"<button class='btn-success' onclick=\"saveCurrentMotion(this)\" id='btnSaveFullMotion'>保存当前整套动作</button>"
"<button class='btn-danger' onclick=\"deleteAllStoredMotions(this)\" id='btnDeleteAllMotions'>全部删除</button>"
"</div>"
"</div>"
"<div class='motion-library-status' id='motionLibraryStatus'>正在读取动作列表...</div>"
"<div class='motion-list' id='motionLibrary'></div>"
"</div>"
"<div style='margin-top:20px;padding-top:20px;border-top:2px solid #eee;'>"
"<h3 style='color:#667eea;margin-bottom:15px;'>🦵 腿1动作控制 (ID:1-5)</h3>"
"<div class='btn-group'>"
"<button class='btn-success' onclick=\"send('Button_LockLeg1',this)\" id='btnLockLeg1'>🔓 开启腿1扭矩</button>"
"</div>"
"<div class='btn-group' style='margin-top:10px;'>"
"<button class='btn-primary' onclick=\"send('Button_RecordLeg1',this)\" id='btnRecordLeg1'>🎬 录入腿1动作</button>"
"<button class='btn-warning' onclick=\"send('Button_ReplayLeg1',this)\" id='btnReplayLeg1'>▶ 复现腿1动作</button>"
"</div>"
"<h3 style='color:#667eea;margin-top:20px;margin-bottom:15px;'>🦵 腿2动作控制 (ID:6-10)</h3>"
"<div class='btn-group'>"
"<button class='btn-success' onclick=\"send('Button_LockLeg2',this)\" id='btnLockLeg2'>🔓 开启腿2扭矩</button>"
"</div>"
"<div class='btn-group' style='margin-top:10px;'>"
"<button class='btn-primary' onclick=\"send('Button_RecordLeg2',this)\" id='btnRecordLeg2'>🎬 录入腿2动作</button>"
"<button class='btn-warning' onclick=\"send('Button_ReplayLeg2',this)\" id='btnReplayLeg2'>▶ 复现腿2动作</button>"
"</div>"
"<h3 style='color:#667eea;margin-top:20px;margin-bottom:15px;'>🦵 腿3动作控制 (ID:11-15)</h3>"
"<div class='btn-group'>"
"<button class='btn-success' onclick=\"send('Button_LockLeg3',this)\" id='btnLockLeg3'>🔓 开启腿3扭矩</button>"
"</div>"
"<div class='btn-group' style='margin-top:10px;'>"
"<button class='btn-primary' onclick=\"send('Button_RecordLeg3',this)\" id='btnRecordLeg3'>🎬 录入腿3动作</button>"
"<button class='btn-warning' onclick=\"send('Button_ReplayLeg3',this)\" id='btnReplayLeg3'>▶ 复现腿3动作</button>"
"</div>"
"<h3 style='color:#667eea;margin-top:20px;margin-bottom:15px;'>🦵 腿4动作控制 (ID:16-20)</h3>"
"<div class='btn-group'>"
"<button class='btn-success' onclick=\"send('Button_LockLeg4',this)\" id='btnLockLeg4'>🔓 开启腿4扭矩</button>"
"</div>"
"<div class='btn-group' style='margin-top:10px;'>"
"<button class='btn-primary' onclick=\"send('Button_RecordLeg4',this)\" id='btnRecordLeg4'>🎬 录入腿4动作</button>"
"<button class='btn-warning' onclick=\"send('Button_ReplayLeg4',this)\" id='btnReplayLeg4'>▶ 复现腿4动作</button>"
"</div>"
"</div>"
"</div>"
"<div class='section'>"
"<div class='section-title'>舵机角度控制</div>"
"<p style='margin-bottom:15px;color:#666;font-size:0.95em;'>🎯 实时调节各舵机角度，观察机器人运动效果</p>"
"<div class='slider-container'>"
"<label><strong>1号舵机 (LF1)</strong> <span style='font-size:0.9em;color:#999;'>(范围: 1700-2700)</span><span class='slider-value' id='posValue'>2050</span></label>"
"<input type='range' id='posSlider' min='1700' max='2700' value='2050' step='1' "
"oninput=\"updatePositionAndSend(this.value)\">"
"</div>"
"<div class='slider-container'>"
"<label><strong>2号舵机 (LF2)</strong> <span style='font-size:0.9em;color:#999;'>(范围: 700-3000)</span><span class='slider-value' id='posValue2'>2850</span></label>"
"<input type='range' id='posSlider2' min='700' max='3000' value='2850' step='1' "
"oninput=\"updatePositionAndSend2(this.value)\">"
"</div>"
"<div class='slider-container'>"
"<label><strong>3号舵机 (LF3)</strong> <span style='font-size:0.9em;color:#999;'>(范围: 800-3500)</span><span class='slider-value' id='posValue3'>3000</span></label>"
"<input type='range' id='posSlider3' min='800' max='3500' value='3000' step='1' "
"oninput=\"updatePositionAndSend3(this.value)\">"
"</div>"
"<div class='slider-container'>"
"<label><strong>4号舵机 (LF4)</strong> <span style='font-size:0.9em;color:#999;'>(范围: 900-3100)</span><span class='slider-value' id='posValue4'>1000</span></label>"
"<input type='range' id='posSlider4' min='900' max='3100' value='1000' step='1' "
"oninput=\"updatePositionAndSend4(this.value)\">"
"</div>"
"<div class='slider-container'>"
"<label><strong>6号舵机 (ID:6)</strong> <span style='font-size:0.9em;color:#999;'>(范围: 1600-2500)</span><span class='slider-value' id='posValue6'>2000</span></label>"
"<input type='range' id='posSlider6' min='1600' max='2500' value='2000' step='1' "
"oninput=\"updatePositionAndSend6(this.value)\">"
"</div>"
"<div class='slider-container'>"
"<label><strong>7号舵机 (ID:7)</strong> <span style='font-size:0.9em;color:#999;'>(范围: 700-3000)</span><span class='slider-value' id='posValue7'>2150</span></label>"
"<input type='range' id='posSlider7' min='700' max='3000' value='2150' step='1' "
"oninput=\"updatePositionAndSend7(this.value)\">"
"</div>"
"<div class='slider-container'>"
"<label><strong>8号舵机 (ID:8)</strong> <span style='font-size:0.9em;color:#999;'>(范围: 700-3300)</span><span class='slider-value' id='posValue8'>1850</span></label>"
"<input type='range' id='posSlider8' min='700' max='3300' value='1850' step='1' "
"oninput=\"updatePositionAndSend8(this.value)\">"
"</div>"
"<div class='slider-container'>"
"<label><strong>9号舵机 (ID:9)</strong> <span style='font-size:0.9em;color:#999;'>(范围: 900-3100)</span><span class='slider-value' id='posValue9'>1000</span></label>"
"<input type='range' id='posSlider9' min='900' max='3100' value='1000' step='1' "
"oninput=\"updatePositionAndSend9(this.value)\">"
"</div>"
"<div class='slider-container'>"
"<label><strong>11号舵机 (ID:11)</strong> <span style='font-size:0.9em;color:#999;'>(范围: 1500-2500)</span><span class='slider-value' id='posValue11'>1850</span></label>"
"<input type='range' id='posSlider11' min='1500' max='2500' value='1850' step='1' "
"oninput=\"updatePositionAndSend11(this.value)\">"
"</div>"
"<div class='slider-container'>"
"<label><strong>12号舵机 (ID:12)</strong> <span style='font-size:0.9em;color:#999;'>(范围: 600-3100)</span><span class='slider-value' id='posValue12'>2300</span></label>"
"<input type='range' id='posSlider12' min='600' max='3100' value='2300' step='1' "
"oninput=\"updatePositionAndSend12(this.value)\">"
"</div>"
"<div class='slider-container'>"
"<label><strong>13号舵机 (ID:13)</strong> <span style='font-size:0.9em;color:#999;'>(范围: 700-3300)</span><span class='slider-value' id='posValue13'>2100</span></label>"
"<input type='range' id='posSlider13' min='700' max='3300' value='2100' step='1' "
"oninput=\"updatePositionAndSend13(this.value)\">"
"</div>"
"<div class='slider-container'>"
"<label><strong>14号舵机 (ID:14)</strong> <span style='font-size:0.9em;color:#999;'>(范围: 900-3100)</span><span class='slider-value' id='posValue14'>1200</span></label>"
"<input type='range' id='posSlider14' min='900' max='3100' value='1200' step='1' "
"oninput=\"updatePositionAndSend14(this.value)\">"
"</div>"
"<div class='slider-container'>"
"<label><strong>16号舵机 (ID:16)</strong> <span style='font-size:0.9em;color:#999;'>(范围: 1600-2500)</span><span class='slider-value' id='posValue16'>2100</span></label>"
"<input type='range' id='posSlider16' min='1600' max='2500' value='2100' step='1' "
"oninput=\"updatePositionAndSend16(this.value)\">"
"</div>"
"<div class='slider-container'>"
"<label><strong>17号舵机 (ID:17)</strong> <span style='font-size:0.9em;color:#999;'>(范围: 1000-3400)</span><span class='slider-value' id='posValue17'>2850</span></label>"
"<input type='range' id='posSlider17' min='1000' max='3400' value='2850' step='1' "
"oninput=\"updatePositionAndSend17(this.value)\">"
"</div>"
"<div class='slider-container'>"
"<label><strong>18号舵机 (ID:18)</strong> <span style='font-size:0.9em;color:#999;'>(范围: 600-3100)</span><span class='slider-value' id='posValue18'>2400</span></label>"
"<input type='range' id='posSlider18' min='600' max='3100' value='2400' step='1' "
"oninput=\"updatePositionAndSend18(this.value)\">"
"</div>"
"<div class='slider-container'>"
"<label><strong>19号舵机 (ID:19)</strong> <span style='font-size:0.9em;color:#999;'>(范围: 900-3200)</span><span class='slider-value' id='posValue19'>1200</span></label>"
"<input type='range' id='posSlider19' min='900' max='3200' value='1200' step='1' "
"oninput=\"updatePositionAndSend19(this.value)\">"
"</div>"
"</div>"
"<div class='section'>"
"<div class='section-title'>高级功能</div>"
"<div class='btn-group'>"
"<button class='btn-info' onclick=\"send('Button_FixedGait',this)\">🚶 固定步态（左前腿前进）</button>"
"<button class='btn-primary' onclick=\"send('Button_DualServoRotate',this)\">🔄 双舵机旋转90度</button>"
"</div>"
"</div>"
"<div id='dht'></div>"
"<script>"
"var lastSendTime=0;var throttleDelay=50;var pollIntervalMs=1000;"
"var motionLibraryInFlight=false;var motionLibraryRefreshTick=0;"
"var sendQueue=Promise.resolve();var buttonStatusInFlight=false;var dhtInFlight=false;"
"var noColorChangeButtons=['Button_Lockon','Button_Lockoff','Button_RestorePose','Button_SyncRead','Button_FixedGait','Button_DualServoRotate'];"
"function shouldKeepButtonStyle(v){"
"for(var i=0;i<noColorChangeButtons.length;i++){"
"if(v===noColorChangeButtons[i]){return false;}"
"}"
"return true;"
"}"
"function enqueueSetRequest(v){"
"sendQueue=sendQueue.then(function(){"
"return new Promise(function(resolve){"
"var x=new XMLHttpRequest();"
"x.open('GET','/set?value='+encodeURIComponent(v),true);"
"x.timeout=1500;"
"x.onreadystatechange=function(){if(x.readyState===4){resolve();}};"
"x.ontimeout=function(){resolve();};"
"x.onerror=function(){resolve();};"
"try{x.send();}catch(e){console.error('send failed',e);resolve();}"
"});"
"});"
"return sendQueue;"
"}"
"function finishSend(btn,wasDisabled,shouldChangeColor){"
"if(btn&&btn.tagName=='BUTTON'&&shouldChangeColor){"
"btn.disabled=wasDisabled;"
"}"
"setTimeout(function(){updateButtons();updateButtonStatus();},150);"
"}"
"function send(v,btn){"
"var wasDisabled=false;"
"var shouldChangeColor=shouldKeepButtonStyle(v);"
"if(btn&&btn.tagName=='BUTTON'){"
"wasDisabled=btn.disabled;"
"if(shouldChangeColor){"
"btn.style.backgroundColor='#888';"
"btn.disabled=true;"
"}"
"}"
"enqueueSetRequest(v).then(function(){"
"finishSend(btn,wasDisabled,shouldChangeColor);"
"});"
"}"
"function startTeachReplay(btn){"
"send('Button_ReplayMotion1',btn);"
"}"
"function startFullReplay(btn){"
"var loopInput=document.getElementById('teachLoopCount');"
"var loopCount=0;"
"if(loopInput){"
"loopCount=parseInt(loopInput.value,10);"
"if(isNaN(loopCount)||loopCount<0){loopCount=0;}"
"if(loopCount>9999){loopCount=9999;}"
"loopInput.value=loopCount;"
"send('FullLoop_'+loopCount);"
"}"
"send('Button_ReplayFullMotion',btn);"
"}"
"function setMotionLibraryStatus(text){"
"var el=document.getElementById('motionLibraryStatus');"
"if(el){el.textContent=text;}"
"}"
"function updateCurrentMotionName(name){"
"var el=document.getElementById('currentFullMotionName');"
"if(el){el.textContent=name&&name.length?name:'No motion';}"
"}"
"function callMotionAction(action,name){"
"var url='/motion_action?action='+encodeURIComponent(action);"
"if(name){url+='&name='+encodeURIComponent(name);}"
"return fetch(url,{cache:'no-store'})"
".then(function(r){return r.json();})"
".then(function(data){"
"if(data.status!=='success'){throw new Error(data.message||'Action failed');}"
"return data;"
"});"
"}"
"function saveCurrentMotion(btn){"
"var wasDisabled=btn?btn.disabled:false;"
"if(btn){btn.disabled=true;}"
"setMotionLibraryStatus('正在保存当前动作...');"
"callMotionAction('save')"
".then(function(){"
"setTimeout(function(){updateButtonStatus();refreshMotionLibrary(true);},300);"
"})"
".catch(function(err){"
"setMotionLibraryStatus('保存失败: '+(err&&err.message?err.message:err));"
"})"
".then(function(){"
"if(btn){btn.disabled=wasDisabled;}"
"});"
"}"
"function replayStoredMotion(name,btn){"
"var wasDisabled=btn?btn.disabled:false;"
"if(btn){btn.disabled=true;}"
"setMotionLibraryStatus('正在复现动作: '+name);"
"callMotionAction('replay',name)"
".then(function(){"
"setTimeout(function(){updateButtonStatus();refreshMotionLibrary(true);},300);"
"})"
".catch(function(err){"
"setMotionLibraryStatus('复现失败: '+(err&&err.message?err.message:err));"
"})"
".then(function(){"
"if(btn){btn.disabled=wasDisabled;}"
"});"
"}"
"function deleteStoredMotion(name,btn){"
"if(!window.confirm('确定删除动作 \"'+name+'\"？删除后无法恢复。')){return;}"
"var wasDisabled=btn?btn.disabled:false;"
"if(btn){btn.disabled=true;}"
"setMotionLibraryStatus('正在删除动作: '+name);"
"callMotionAction('delete',name)"
".then(function(){"
"setTimeout(function(){updateButtonStatus();refreshMotionLibrary(true);},300);"
"})"
".catch(function(err){"
"setMotionLibraryStatus('删除失败: '+(err&&err.message?err.message:err));"
"})"
".then(function(){"
"if(btn){btn.disabled=wasDisabled;}"
"});"
"}"
"function deleteAllStoredMotions(btn){"
"if(!window.confirm('确定删除全部已保存动作？删除后无法恢复。')){return;}"
"var wasDisabled=btn?btn.disabled:false;"
"if(btn){btn.disabled=true;}"
"setMotionLibraryStatus('正在删除全部动作...');"
"callMotionAction('delete_all')"
".then(function(data){"
"var deletedCount=(data&&typeof data.deletedCount==='number')?data.deletedCount:0;"
"setMotionLibraryStatus(deletedCount>0?('已删除 '+deletedCount+' 套动作，正在刷新列表...'):'没有可删除的动作');"
"setTimeout(function(){updateButtonStatus();refreshMotionLibrary(true);},300);"
"})"
".catch(function(err){"
"setMotionLibraryStatus('全部删除失败: '+(err&&err.message?err.message:err));"
"})"
".then(function(){"
"if(btn){btn.disabled=wasDisabled;}"
"});"
"}"
"function renderMotionLibrary(data){"
"var listEl=document.getElementById('motionLibrary');"
"if(!listEl){return;}"
"var motions=(data&&data.motions)?data.motions:[];"
"if(!motions.length){"
"listEl.innerHTML='<div class=\"motion-item\"><div class=\"motion-title\">暂无已保存动作</div><div class=\"motion-meta\">先录入一套整套动作，再点击保存。</div></div>';"
"return;"
"}"
"var html='';"
"for(var i=0;i<motions.length;i++){"
"var motion=motions[i];"
"var duration=((motion.totalDurationMs||0)/1000).toFixed(2);"
"html+='<div class=\"motion-item'+(motion.isCurrent?' current':'')+'\">';"
"html+='<div class=\"motion-title\">'+motion.name+(motion.isCurrent?' (当前)':'')+'</div>';"
"html+='<div class=\"motion-meta\">帧数: '+(motion.frameCount||0)+'<br>时长: '+duration+' s</div>';"
"html+='<div class=\"motion-actions\">';"
"html+='<button class=\"btn-warning\" onclick=\"replayStoredMotion(\\''+motion.name+'\\',this)\">复现</button>';"
"html+='<button class=\"btn-danger\" onclick=\"deleteStoredMotion(\\''+motion.name+'\\',this)\">删除</button>';"
"html+='</div></div>';"
"}"
"listEl.innerHTML=html;"
"}"
"function refreshMotionLibrary(force){"
"if(motionLibraryInFlight&&!force){return;}"
"motionLibraryInFlight=true;"
"fetch('/motions',{cache:'no-store'})"
".then(function(r){return r.json();})"
".then(function(data){"
"if(data.status!=='success'){throw new Error(data.message||'Load library failed');}"
"updateCurrentMotionName(data.currentMotionName||'No motion');"
"renderMotionLibrary(data);"
"setMotionLibraryStatus((data.motions&&data.motions.length)?'已载入 '+data.motions.length+' 套动作':'还没有已保存动作');"
"})"
".catch(function(err){"
"setMotionLibraryStatus('动作列表读取失败: '+(err&&err.message?err.message:err));"
"})"
".then(function(){"
"motionLibraryInFlight=false;"
"});"
"}"
"var lastSendTime2=0;"
"function updatePositionAndSend(val){"
"document.getElementById('posValue').textContent=val;"
"var now=Date.now();"
"if(now-lastSendTime>=throttleDelay){"
"send('Slider_Pos_'+val);"
"lastSendTime=now;"
"}"
"}"
"function updatePositionAndSend2(val){"
"document.getElementById('posValue2').textContent=val;"
"var now=Date.now();"
"if(now-lastSendTime2>=throttleDelay){"
"send('Slider_Pos2_'+val);"
"lastSendTime2=now;"
"}"
"}"
"var lastSendTime3=0;"
"function updatePositionAndSend3(val){"
"document.getElementById('posValue3').textContent=val;"
"var now=Date.now();"
"if(now-lastSendTime3>=throttleDelay){"
"send('Slider_Pos3_'+val);"
"lastSendTime3=now;"
"}"
"}"
"var lastSendTime4=0;"
"function updatePositionAndSend4(val){"
"document.getElementById('posValue4').textContent=val;"
"var now=Date.now();"
"if(now-lastSendTime4>=throttleDelay){"
"send('Slider_Pos4_'+val);"
"lastSendTime4=now;"
"}"
"}"
"var lastSendTime6=0;"
"function updatePositionAndSend6(val){"
"document.getElementById('posValue6').textContent=val;"
"var now=Date.now();"
"if(now-lastSendTime6>=throttleDelay){"
"send('Slider_Pos6_'+val);"
"lastSendTime6=now;"
"}"
"}"
"var lastSendTime7=0;"
"function updatePositionAndSend7(val){"
"document.getElementById('posValue7').textContent=val;"
"var now=Date.now();"
"if(now-lastSendTime7>=throttleDelay){"
"send('Slider_Pos7_'+val);"
"lastSendTime7=now;"
"}"
"}"
"var lastSendTime8=0;"
"function updatePositionAndSend8(val){"
"document.getElementById('posValue8').textContent=val;"
"var now=Date.now();"
"if(now-lastSendTime8>=throttleDelay){"
"send('Slider_Pos8_'+val);"
"lastSendTime8=now;"
"}"
"}"
"var lastSendTime9=0;"
"function updatePositionAndSend9(val){"
"document.getElementById('posValue9').textContent=val;"
"var now=Date.now();"
"if(now-lastSendTime9>=throttleDelay){"
"send('Slider_Pos9_'+val);"
"lastSendTime9=now;"
"}"
"}"
"var lastSendTime11=0;"
"function updatePositionAndSend11(val){"
"document.getElementById('posValue11').textContent=val;"
"var now=Date.now();"
"if(now-lastSendTime11>=throttleDelay){"
"send('Slider_Pos11_'+val);"
"lastSendTime11=now;"
"}"
"}"
"var lastSendTime12=0;"
"function updatePositionAndSend12(val){"
"document.getElementById('posValue12').textContent=val;"
"var now=Date.now();"
"if(now-lastSendTime12>=throttleDelay){"
"send('Slider_Pos12_'+val);"
"lastSendTime12=now;"
"}"
"}"
"var lastSendTime13=0;"
"function updatePositionAndSend13(val){"
"document.getElementById('posValue13').textContent=val;"
"var now=Date.now();"
"if(now-lastSendTime13>=throttleDelay){"
"send('Slider_Pos13_'+val);"
"lastSendTime13=now;"
"}"
"}"
"var lastSendTime14=0;"
"function updatePositionAndSend14(val){"
"document.getElementById('posValue14').textContent=val;"
"var now=Date.now();"
"if(now-lastSendTime14>=throttleDelay){"
"send('Slider_Pos14_'+val);"
"lastSendTime14=now;"
"}"
"}"
"var lastSendTime16=0;"
"function updatePositionAndSend16(val){"
"document.getElementById('posValue16').textContent=val;"
"var now=Date.now();"
"if(now-lastSendTime16>=throttleDelay){"
"send('Slider_Pos16_'+val);"
"lastSendTime16=now;"
"}"
"}"
"var lastSendTime17=0;"
"function updatePositionAndSend17(val){"
"document.getElementById('posValue17').textContent=val;"
"var now=Date.now();"
"if(now-lastSendTime17>=throttleDelay){"
"send('Slider_Pos17_'+val);"
"lastSendTime17=now;"
"}"
"}"
"var lastSendTime18=0;"
"function updatePositionAndSend18(val){"
"document.getElementById('posValue18').textContent=val;"
"var now=Date.now();"
"if(now-lastSendTime18>=throttleDelay){"
"send('Slider_Pos18_'+val);"
"lastSendTime18=now;"
"}"
"}"
"var lastSendTime19=0;"
"function updatePositionAndSend19(val){"
"document.getElementById('posValue19').textContent=val;"
"var now=Date.now();"
"if(now-lastSendTime19>=throttleDelay){"
"send('Slider_Pos19_'+val);"
"lastSendTime19=now;"
"}"
"}"
"function updateButtonStatus(){"
"if(buttonStatusInFlight){return;}"
"buttonStatusInFlight=true;"
"setTimeout(function(){buttonStatusInFlight=false;},2000);"
"fetch('/button_status',{cache:'no-store'})"
"  .then(r=>r.json())"
"  .then(data=>{"
"    if(data.status==='success'){"
"      var readMode=data.readMode||0;"
"      var btn=document.getElementById('btnReadAngleMode');"
"      if(btn){"
"        btn.textContent=readMode?'📡 关闭读取角度模式':'📡 开启读取角度模式';"
"        btn.style.backgroundColor=readMode?'#f44336':'#4CAF50';"
"        btn.className=readMode?'btn-danger':'btn-success';"
"      }"
"      var teachReplay=data.teachReplay||0;"
"      var hasTeachMotion=data.hasTeachMotion||0;"
"      var fullReplayLoopCount=data.fullReplayLoopCount||0;"
"      var btnTeach=document.getElementById('btnReplayMotion1');"
"      if(btnTeach){"
"        btnTeach.disabled=!teachReplay&&!hasTeachMotion;"
"        btnTeach.textContent=teachReplay?'⏸ 停止示教复现':'🎯 示教复现';"
"        btnTeach.style.backgroundColor=teachReplay?'#f44336':'#00BCD4';"
"        btnTeach.className=teachReplay?'btn-danger':'btn-info';"
"        if(!teachReplay&&!hasTeachMotion){"
"          btnTeach.style.opacity='0.6';"
"          btnTeach.style.cursor='not-allowed';"
"        }else{"
"          btnTeach.style.opacity='1';"
"          btnTeach.style.cursor='pointer';"
"        }"
"      }"
"      var teachLoopInput=document.getElementById('teachLoopCount');"
"      if(teachLoopInput&&document.activeElement!==teachLoopInput){"
"        teachLoopInput.value=fullReplayLoopCount;"
"      }"
"      var recordFullMotion=data.recordFullMotion||0;"
"      var hasFullMotion=data.hasFullMotion||0;"
"      var replayFullMotion=data.replayFullMotion||0;"
"      var storageReady=data.storageReady||0;"
"      var storageBusy=data.storageBusy||0;"
"      var motionLibraryAvailable=data.motionLibraryAvailable||0;"
"      var currentFullMotionName=data.currentFullMotionName||'No motion';"
"      updateCurrentMotionName(currentFullMotionName);"
"      var btnRecordFull=document.getElementById('btnRecordFullMotion');"
"      if(btnRecordFull){"
"        btnRecordFull.textContent=recordFullMotion?'停止录入整套动作':'录入整套动作';"
"        btnRecordFull.style.backgroundColor=recordFullMotion?'#f44336':'#2196F3';"
"        btnRecordFull.className=recordFullMotion?'btn-danger':'btn-primary';"
"      }"
"      var btnReplayFull=document.getElementById('btnReplayFullMotion');"
"      if(btnReplayFull){"
"        btnReplayFull.disabled=!hasFullMotion&&!replayFullMotion;"
"        btnReplayFull.textContent=replayFullMotion?'停止复现整套动作':'复现整套动作';"
"        btnReplayFull.style.backgroundColor=replayFullMotion?'#f44336':'#FF9800';"
"        btnReplayFull.className=replayFullMotion?'btn-danger':'btn-warning';"
"        if(!hasFullMotion&&!replayFullMotion){"
"          btnReplayFull.style.opacity='0.6';"
"          btnReplayFull.style.cursor='not-allowed';"
"        }else{"
"          btnReplayFull.style.opacity='1';"
"          btnReplayFull.style.cursor='pointer';"
"        }"
"      }"
"      var btnSaveFull=document.getElementById('btnSaveFullMotion');"
"      var hasStoredMotions=!!document.querySelector('#motionLibrary .motion-actions');"
"      if(btnSaveFull){"
"        btnSaveFull.disabled=!storageReady||storageBusy||!motionLibraryAvailable||!hasFullMotion;"
"        if(!storageReady){"
"          setMotionLibraryStatus('存储分区未就绪');"
"        }else if(storageBusy){"
"          setMotionLibraryStatus('存储正在处理，请稍后...');"
"        }"
"      }"
"      var btnDeleteAll=document.getElementById('btnDeleteAllMotions');"
"      if(btnDeleteAll){"
"        btnDeleteAll.disabled=!storageReady||storageBusy||!motionLibraryAvailable||!hasStoredMotions;"
"        btnDeleteAll.style.opacity=btnDeleteAll.disabled?'0.6':'1';"
"        btnDeleteAll.style.cursor=btnDeleteAll.disabled?'not-allowed':'pointer';"
"      }"
"      function updateLegButton(legNum,recordMode,hasMotion,replayMode,torqueEnabled){"
"        var btnLock=document.getElementById('btnLockLeg'+legNum);"
"        if(btnLock){"
"          btnLock.textContent=torqueEnabled?'🔒 关闭腿'+legNum+'扭矩':'🔓 开启腿'+legNum+'扭矩';"
"          btnLock.style.backgroundColor=torqueEnabled?'#f44336':'#4CAF50';"
"          btnLock.className=torqueEnabled?'btn-danger':'btn-success';"
"        }"
"        var btnRecord=document.getElementById('btnRecordLeg'+legNum);"
"        if(btnRecord){"
"          btnRecord.textContent=recordMode?'🎬 停止录入腿'+legNum+'动作':'🎬 录入腿'+legNum+'动作';"
"          btnRecord.style.backgroundColor=recordMode?'#f44336':'#2196F3';"
"          btnRecord.className=recordMode?'btn-danger':'btn-primary';"
"        }"
"        var btnReplay=document.getElementById('btnReplayLeg'+legNum);"
"        if(btnReplay){"
"          btnReplay.disabled=!hasMotion;"
"          btnReplay.textContent=replayMode?'⏸ 停止复现腿'+legNum:'▶ 复现腿'+legNum+'动作';"
"          btnReplay.style.backgroundColor=replayMode?'#f44336':'#FF9800';"
"          btnReplay.className=replayMode?'btn-danger':'btn-warning';"
"          if(!hasMotion){"
"            btnReplay.style.opacity='0.6';"
"            btnReplay.style.cursor='not-allowed';"
"          }else{"
"            btnReplay.style.opacity='1';"
"            btnReplay.style.cursor='pointer';"
"          }"
"        }"
"      }"
"      updateLegButton(1,data.recordLeg1||0,data.hasMotionLeg1||0,data.replayLeg1||0,data.leg1TorqueEnabled||0);"
"      updateLegButton(2,data.recordLeg2||0,data.hasMotionLeg2||0,data.replayLeg2||0,data.leg2TorqueEnabled||0);"
"      updateLegButton(3,data.recordLeg3||0,data.hasMotionLeg3||0,data.replayLeg3||0,data.leg3TorqueEnabled||0);"
"      updateLegButton(4,data.recordLeg4||0,data.hasMotionLeg4||0,data.replayLeg4||0,data.leg4TorqueEnabled||0);"
"      motionLibraryRefreshTick=(motionLibraryRefreshTick+1)%3;"
"      if(motionLibraryRefreshTick===0||storageBusy){"
"        refreshMotionLibrary(false);"
"      }"
"      buttonStatusInFlight=false;"
"    }"
"  })"
"  .catch(e=>{buttonStatusInFlight=false;console.error('获取按钮状态失败:',e);});"
"}"
"function updateButtons(){"
"if(dhtInFlight){return;}"
"dhtInFlight=true;"
"var x=new XMLHttpRequest();"
"x.onreadystatechange=function(){"
"if(x.readyState==4){"
"if(x.status==200){"
"var dhtEl=document.getElementById('dht');"
"if(dhtEl){dhtEl.innerHTML=x.responseText;}"
"}"
"dhtInFlight=false;"
"}"
"};"
"x.open('GET','/dht',true);"
"x.timeout=1500;"
"x.ontimeout=function(){dhtInFlight=false;};"
"x.onerror=function(){dhtInFlight=false;};"
"x.send();"
"}"
"setInterval(updateButtons,pollIntervalMs);"
"setInterval(updateButtonStatus,pollIntervalMs);"
"setInterval(function(){refreshMotionLibrary(false);},pollIntervalMs*3);"
"updateButtons();"
"updateButtonStatus();"
"refreshMotionLibrary(true);"
"</script>"
"</div>"
"</div>"
"</body></html>";

// 生成网页右侧状态面板，包括工作状态、提示文本和舵机角度数据。
// 组装状态区域 HTML，把当前工作状态、提示文本和录制信息拼成网页片段。
static void build_status_html(char *buf, size_t buf_len)
{
    int n = 0;
    n += snprintf(buf + n, buf_len - n, "<h2>📊 系统状态监控</h2>");
    n += snprintf(buf + n, buf_len - n, "<div class='status-info'>");
    n += snprintf(buf + n, buf_len - n, "<div class='info-card'><strong>当前状态</strong>%s</div>", work);
    if (strlen(message0) > 0 && strcmp(message0, "null") != 0) {
        n += snprintf(buf + n, buf_len - n, "<div class='info-card'><strong>提示信息</strong>%s</div>", message0);
    }
    if (strlen(message1) > 0 && strcmp(message1, "null") != 0) {
        n += snprintf(buf + n, buf_len - n, "<div class='info-card'><strong>详细信息</strong>%s</div>", message1);
    }
    n += snprintf(buf + n, buf_len - n,
                  "<div class='info-card'><strong>当前整套动作</strong>%s</div>",
                  motion_storage_get_current_motion_name());
    n += snprintf(buf + n, buf_len - n, "<div class='info-card'><strong>系统循环</strong>%lu 次</div>", (unsigned long)blink);
    n += snprintf(buf + n, buf_len - n, "</div>");
    
    n += snprintf(buf + n, buf_len - n, "<h2 style='margin-top:25px;'>⚙ 舵机角度数据</h2>");
    n += snprintf(buf + n, buf_len - n, "<div style='display:grid;grid-template-columns:repeat(auto-fill,minmax(150px,1fr));gap:10px;'>");
    // 显示 ID 1-20 的舵机数据（使用 servoPos_1to20 数组）
    uint8_t display_ids[] = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20};
    int display_count = sizeof(display_ids) / sizeof(display_ids[0]);
    
    for (int i = 0; i < display_count; i++) {
        int servo_id = display_ids[i];
        int array_idx = servo_id - 1;
        
        if (buf_len - (size_t)n < 180) {
            break;
        }
        int written = snprintf(buf + n, buf_len - n,
                      "<div style='background:#f0f4ff;padding:12px;border-radius:8px;text-align:center;border-left:3px solid #667eea;'>"
                      "<strong>舵机 %d</strong><br/><span style='font-size:1.3em;color:#667eea;font-weight:bold;'>%d</span></div>", 
                      servo_id, servoPos_1to20[array_idx]);
        if (written > 0 && written < (int)(buf_len - n)) {
            n += written;
        } else {
            // 写入失败或超出缓冲区，停止添加
            break;
        }
    }
    n += snprintf(buf + n, buf_len - n, "</div>");
    
    // 添加读取角度模式状态和录入动作模式状态（使用隐藏的 data 属性）
    n += snprintf(buf + n, buf_len - n, 
                  "<div id='btnStatus' style='display:none;' "
                  "data-readmode='%d' "
                  "data-recordfull='%d' data-hasmotionfull='%d' data-replayfull='%d' "
                  "data-recordleg1='%d' data-hasmotionleg1='%d' data-replayleg1='%d' data-leg1torqueenabled='%d' "
                  "data-recordleg2='%d' data-hasmotionleg2='%d' data-replayleg2='%d' data-leg2torqueenabled='%d' "
                  "data-recordleg3='%d' data-hasmotionleg3='%d' data-replayleg3='%d' data-leg3torqueenabled='%d' "
                  "data-recordleg4='%d' data-hasmotionleg4='%d' data-replayleg4='%d' data-leg4torqueenabled='%d'></div>",
                  g_read_angle_mode ? 1 : 0,
                  g_record_full_mode ? 1 : 0, has_recorded_motion_full ? 1 : 0, g_replay_full_mode ? 1 : 0,
                  g_record_leg1_mode ? 1 : 0, has_recorded_motion_leg1 ? 1 : 0, g_replay_leg1_mode ? 1 : 0, g_leg1_torque_enabled ? 1 : 0,
                  g_record_leg2_mode ? 1 : 0, has_recorded_motion_leg2 ? 1 : 0, g_replay_leg2_mode ? 1 : 0, g_leg2_torque_enabled ? 1 : 0,
                  g_record_leg3_mode ? 1 : 0, has_recorded_motion_leg3 ? 1 : 0, g_replay_leg3_mode ? 1 : 0, g_leg3_torque_enabled ? 1 : 0,
                  g_record_leg4_mode ? 1 : 0, has_recorded_motion_leg4 ? 1 : 0, g_replay_leg4_mode ? 1 : 0, g_leg4_torque_enabled ? 1 : 0);
}

// 返回主控制页面。
// 返回主页 HTML。
static esp_err_t root_get_handler(httpd_req_t *req)
{
    httpd_resp_set_type(req, "text/html");
    return httpd_resp_send(req, index_html, HTTPD_RESP_USE_STRLEN);
}

// 返回实时状态面板 HTML，供前端定时刷新。
// 返回动态状态区域内容，供网页定时轮询刷新。
static esp_err_t dht_get_handler(httpd_req_t *req)
{
    // 使用全局缓冲区，避免在 httpd 任务栈上分配大数组导致栈溢出
    build_status_html(g_dht_html_buf, sizeof(g_dht_html_buf));
    httpd_resp_set_type(req, "text/html");
    return httpd_resp_send(req, g_dht_html_buf, HTTPD_RESP_USE_STRLEN);
}

// 返回前端按钮状态所需的 JSON 数据，便于页面同步录制/回放状态。
// 返回按钮状态 JSON，让前端知道哪些功能当前处于开启或关闭状态。
static esp_err_t button_status_get_handler(httpd_req_t *req)
{
    char json_buf[1536];
    const char *current_motion_name = motion_storage_get_current_motion_name();
    int n = snprintf(json_buf, sizeof(json_buf),
                    "{\"status\":\"success\","
                    "\"readMode\":%d,"
                    "\"teachReplay\":%d,\"hasTeachMotion\":%d,\"fullReplayLoopCount\":%u,"
                    "\"storageReady\":%d,\"storageBusy\":%d,\"motionLibraryAvailable\":%d,"
                    "\"currentFullMotionName\":\"%s\","
                    "\"recordFullMotion\":%d,\"hasFullMotion\":%d,\"replayFullMotion\":%d,"
                    "\"recordLeg1\":%d,\"hasMotionLeg1\":%d,\"replayLeg1\":%d,\"leg1TorqueEnabled\":%d,"
                    "\"recordLeg2\":%d,\"hasMotionLeg2\":%d,\"replayLeg2\":%d,\"leg2TorqueEnabled\":%d,"
                    "\"recordLeg3\":%d,\"hasMotionLeg3\":%d,\"replayLeg3\":%d,\"leg3TorqueEnabled\":%d,"
                    "\"recordLeg4\":%d,\"hasMotionLeg4\":%d,\"replayLeg4\":%d,\"leg4TorqueEnabled\":%d}",
                    g_read_angle_mode ? 1 : 0,
                    g_replay_motion1_mode ? 1 : 0,
                    (has_recorded_motion_leg1 || has_recorded_motion_leg2 ||
                     has_recorded_motion_leg3 || has_recorded_motion_leg4) ? 1 : 0,
                    (unsigned)g_teach_replay_loop_count,
                    motion_storage_is_ready() ? 1 : 0,
                    motion_storage_is_busy() ? 1 : 0,
                    motion_library_command_allowed() ? 1 : 0,
                    current_motion_name != NULL ? current_motion_name : "No motion",
                    g_record_full_mode ? 1 : 0, has_recorded_motion_full ? 1 : 0, g_replay_full_mode ? 1 : 0,
                    g_record_leg1_mode ? 1 : 0, has_recorded_motion_leg1 ? 1 : 0, g_replay_leg1_mode ? 1 : 0, g_leg1_torque_enabled ? 1 : 0,
                    g_record_leg2_mode ? 1 : 0, has_recorded_motion_leg2 ? 1 : 0, g_replay_leg2_mode ? 1 : 0, g_leg2_torque_enabled ? 1 : 0,
                    g_record_leg3_mode ? 1 : 0, has_recorded_motion_leg3 ? 1 : 0, g_replay_leg3_mode ? 1 : 0, g_leg3_torque_enabled ? 1 : 0,
                    g_record_leg4_mode ? 1 : 0, has_recorded_motion_leg4 ? 1 : 0, g_replay_leg4_mode ? 1 : 0, g_leg4_torque_enabled ? 1 : 0);
    
    if (n >= (int)sizeof(json_buf)) {
        // 缓冲区太小，返回错误
        const char *error_json = "{\"status\":\"error\",\"message\":\"Buffer overflow\"}";
        httpd_resp_set_status(req, "500 Internal Server Error");
        httpd_resp_set_type(req, "application/json");
        httpd_resp_send(req, error_json, strlen(error_json));
        return ESP_FAIL;
    }
    
    httpd_resp_set_type(req, "application/json");
    httpd_resp_send(req, json_buf, strlen(json_buf));
    return ESP_OK;
}

// 解析 `/set?value=...` 请求，并把网页操作转换成控制命令或目标位置。
// 统一处理网页发来的控制命令和滑块值，是 Web 层到控制层的主要入口。
static esp_err_t motions_get_handler(httpd_req_t *req)
{
    stored_motion_info_t entries[MOTION_STORAGE_LIST_MAX] = {0};
    const size_t motion_count = motion_storage_list(entries, MOTION_STORAGE_LIST_MAX);
    const char *current_motion_name = motion_storage_get_current_motion_name();

    int n = snprintf(s_motion_list_json_buf,
                     sizeof(s_motion_list_json_buf),
                     "{\"status\":\"success\",\"storageReady\":%d,\"storageBusy\":%d,"
                     "\"currentMotionName\":\"%s\",\"motions\":[",
                     motion_storage_is_ready() ? 1 : 0,
                     motion_storage_is_busy() ? 1 : 0,
                     current_motion_name != NULL ? current_motion_name : "No motion");

    if (n < 0 || n >= (int)sizeof(s_motion_list_json_buf)) {
        return send_json_text(req,
                              "500 Internal Server Error",
                              "{\"status\":\"error\",\"message\":\"Motion list buffer overflow\"}");
    }

    for (size_t i = 0; i < motion_count; ++i) {
        int written = snprintf(s_motion_list_json_buf + n,
                               sizeof(s_motion_list_json_buf) - (size_t)n,
                               "%s{\"name\":\"%s\",\"frameCount\":%u,\"totalDurationMs\":%u,\"isCurrent\":%d}",
                               (i == 0) ? "" : ",",
                               entries[i].name,
                               (unsigned)entries[i].frame_count,
                               (unsigned)entries[i].total_duration_ms,
                               entries[i].is_current ? 1 : 0);
        if (written < 0 || written >= (int)(sizeof(s_motion_list_json_buf) - (size_t)n)) {
            return send_json_text(req,
                                  "500 Internal Server Error",
                                  "{\"status\":\"error\",\"message\":\"Motion list buffer overflow\"}");
        }
        n += written;
    }

    int tail_written = snprintf(s_motion_list_json_buf + n,
                                sizeof(s_motion_list_json_buf) - (size_t)n,
                                "]}");
    if (tail_written < 0 || tail_written >= (int)(sizeof(s_motion_list_json_buf) - (size_t)n)) {
        return send_json_text(req,
                              "500 Internal Server Error",
                              "{\"status\":\"error\",\"message\":\"Motion list buffer overflow\"}");
    }

    return send_json_text(req, "200 OK", s_motion_list_json_buf);
}

static esp_err_t motion_action_get_handler(httpd_req_t *req)
{
    char query[96];
    char action[16] = {0};
    char motion_name[FULL_MOTION_NAME_MAX_LEN] = {0};
    char response_json[320];
    size_t deleted_count = 0;

    if (httpd_req_get_url_query_str(req, query, sizeof(query)) != ESP_OK ||
        httpd_query_key_value(query, "action", action, sizeof(action)) != ESP_OK) {
        return send_json_text(req,
                              "400 Bad Request",
                              "{\"status\":\"error\",\"message\":\"Missing action\"}");
    }

    if (!motion_storage_is_ready()) {
        return send_json_text(req,
                              "503 Service Unavailable",
                              "{\"status\":\"error\",\"message\":\"Storage not ready\"}");
    }

    if (!motion_library_command_allowed()) {
        return send_json_text(req,
                              "409 Conflict",
                              "{\"status\":\"error\",\"message\":\"System busy, try again later\"}");
    }

    if (strcmp(action, "save") == 0) {
        g_cmd = CMD_SAVE_FULL_TO_STORAGE;
    } else if (strcmp(action, "delete_all") == 0) {
        esp_err_t err = motion_storage_delete_all_full_motion(&deleted_count);
        if (err != ESP_OK) {
            const char *status = (err == ESP_ERR_TIMEOUT) ? "409 Conflict" : "500 Internal Server Error";
            const char *message = (err == ESP_ERR_TIMEOUT) ?
                "Storage busy, try again later" :
                "Delete all failed";
            snprintf(response_json,
                     sizeof(response_json),
                     "{\"status\":\"error\",\"message\":\"%s\",\"deletedCount\":%u}",
                     message,
                     (unsigned)deleted_count);
            return send_json_text(req, status, response_json);
        }
    } else if (strcmp(action, "replay") == 0 ||
               strcmp(action, "delete") == 0) {
        if (httpd_query_key_value(query, "name", motion_name, sizeof(motion_name)) != ESP_OK ||
            !is_valid_motion_name(motion_name)) {
            return send_json_text(req,
                                  "400 Bad Request",
                                  "{\"status\":\"error\",\"message\":\"Invalid motion name\"}");
        }

        if (strcmp(action, "delete") == 0) {
            esp_err_t err = motion_storage_delete_full_motion(motion_name);
            if (err != ESP_OK) {
                const char *status = "500 Internal Server Error";
                const char *message = "Delete failed";

                if (err == ESP_ERR_NOT_FOUND) {
                    status = "404 Not Found";
                    message = "Motion not found";
                } else if (err == ESP_ERR_TIMEOUT) {
                    status = "409 Conflict";
                    message = "Storage busy, try again later";
                }

                snprintf(response_json,
                         sizeof(response_json),
                         "{\"status\":\"error\",\"message\":\"%s\",\"targetName\":\"%s\"}",
                         message,
                         motion_name);
                return send_json_text(req, status, response_json);
            }
        } else {
            snprintf(g_motion_storage_target_name,
                     sizeof(g_motion_storage_target_name),
                     "%s",
                     motion_name);
            g_cmd = CMD_LOAD_AND_REPLAY_FULL_FROM_STORAGE;
        }
    } else {
        return send_json_text(req,
                              "400 Bad Request",
                              "{\"status\":\"error\",\"message\":\"Unsupported action\"}");
    }

    snprintf(response_json,
             sizeof(response_json),
             "{\"status\":\"success\",\"queuedAction\":\"%s\",\"targetName\":\"%s\",\"currentMotionName\":\"%s\",\"deletedCount\":%u}",
             action,
             motion_name[0] != '\0' ? motion_name : "",
             motion_storage_get_current_motion_name(),
             (unsigned)deleted_count);
    return send_json_text(req, "200 OK", response_json);
}

static esp_err_t set_get_handler(httpd_req_t *req)
{
    char query[64];
    if (httpd_req_get_url_query_str(req, query, sizeof(query)) == ESP_OK) {
        char value[32];
        if (httpd_query_key_value(query, "value", value, sizeof(value)) == ESP_OK) {
            if (try_handle_button_command(value) ||
                try_handle_loop_count_value(value) ||
                try_handle_slider_value(value)) {
                httpd_resp_set_type(req, "text/plain");
                return httpd_resp_send(req, "OK", 2);
            }
            if (strcmp(value, "Button_Lockon") == 0) {
                g_cmd = CMD_LOCK_ON;
            } else if (strcmp(value, "Button_Lockoff") == 0) {
                g_cmd = CMD_LOCK_OFF;
            } else if (strcmp(value, "Button_RestorePose") == 0) {
                g_cmd = CMD_RESTORE_POSE;
            } else if (strcmp(value, "Button_SyncRead") == 0) {
                g_cmd = CMD_SYNC_READ;
            } else if (strcmp(value, "Button_ReadAngleMode") == 0) {
                g_cmd = CMD_READ_ANGLE_MODE;
            } else if (strcmp(value, "Button_RecordLeg1") == 0) {
                g_cmd = CMD_RECORD_LEG1;
            } else if (strcmp(value, "Button_ReplayLeg1") == 0) {
                g_cmd = CMD_REPLAY_LEG1;
            } else if (strcmp(value, "Button_RecordLeg2") == 0) {
                g_cmd = CMD_RECORD_LEG2;
            } else if (strcmp(value, "Button_ReplayLeg2") == 0) {
                g_cmd = CMD_REPLAY_LEG2;
            } else if (strcmp(value, "Button_RecordLeg3") == 0) {
                g_cmd = CMD_RECORD_LEG3;
            } else if (strcmp(value, "Button_ReplayLeg3") == 0) {
                g_cmd = CMD_REPLAY_LEG3;
            } else if (strcmp(value, "Button_RecordLeg4") == 0) {
                g_cmd = CMD_RECORD_LEG4;
            } else if (strcmp(value, "Button_ReplayLeg4") == 0) {
                g_cmd = CMD_REPLAY_LEG4;
            } else if (strcmp(value, "Button_RecordFullMotion") == 0) {
                g_cmd = CMD_RECORD_FULL;
            } else if (strcmp(value, "Button_ReplayFullMotion") == 0) {
                g_cmd = CMD_REPLAY_FULL;
            } else if (strcmp(value, "Button_LockLeg1") == 0) {
                g_cmd = CMD_LOCK_LEG1;
            } else if (strcmp(value, "Button_LockLeg2") == 0) {
                g_cmd = CMD_LOCK_LEG2;
            } else if (strcmp(value, "Button_LockLeg3") == 0) {
                g_cmd = CMD_LOCK_LEG3;
            } else if (strcmp(value, "Button_LockLeg4") == 0) {
                g_cmd = CMD_LOCK_LEG4;
            } else if (strncmp(value, "FullLoop_", 9) == 0 ||
                       strncmp(value, "TeachLoop_", 10) == 0) {
                const char *loop_value = value + ((value[0] == 'F') ? 9 : 10);
                int loop_count = atoi(loop_value);
                if (loop_count < 0) {
                    loop_count = 0;
                } else if (loop_count > 9999) {
                    loop_count = 9999;
                }
                g_teach_replay_loop_count = (uint16_t)loop_count;
            } else if (strcmp(value, "Button_ReplayMotion1") == 0) {
                g_cmd = CMD_REPLAY_MOTION1;
            } else if (strcmp(value, "Button_WriteShow") == 0) {
                g_cmd = CMD_WRITE_SHOW;
            } else if (strcmp(value, "Button_PingId1") == 0) {
                g_cmd = CMD_PING_ID1;
            } else if (strcmp(value, "Button_WriteShow2") == 0) {
                g_cmd = CMD_WRITE_SHOW_2;
            } else if (strcmp(value, "Button_DualServoRotate") == 0) {
                g_cmd = CMD_DUAL_SERVO_ROTATE;
            } else if (strcmp(value, "Button_FixedGait") == 0) {
                g_cmd = CMD_FIXED_GAIT;
            } else if (try_handle_slider_value(value)) {
                // 滑块目标值已更新，控制任务会统一下发。
            }
        }
    }
    httpd_resp_set_type(req, "text/plain");
    return httpd_resp_send(req, "OK", 2);
}

// Favicon处理器 - 返回204 No Content，避免浏览器重复请求和404警告
// 对浏览器自动请求的 favicon 返回空响应，避免无意义的 404 日志。
static esp_err_t favicon_get_handler(httpd_req_t *req)
{
    httpd_resp_set_status(req, "204 No Content");
    httpd_resp_send(req, NULL, 0);
    return ESP_OK;
}

// 启动 HTTP 服务器并注册首页、状态、控制等路由。
// 创建并注册整个 HTTP 服务，把主页、状态接口和控制接口全部挂载起来。
httpd_handle_t start_webserver(void)
{
    httpd_config_t config = HTTPD_DEFAULT_CONFIG();
    config.uri_match_fn = httpd_uri_match_wildcard;
    config.lru_purge_enable = true;
    config.recv_wait_timeout = 5;
    config.send_wait_timeout = 5;
    config.stack_size = 6144;

    httpd_handle_t server = NULL;
    if (httpd_start(&server, &config) == ESP_OK) {
        httpd_uri_t root_uri = {
            .uri      = "/",
            .method   = HTTP_GET,
            .handler  = root_get_handler,
            .user_ctx = NULL
        };
        httpd_register_uri_handler(server, &root_uri);

        httpd_uri_t dht_uri = {
            .uri      = "/dht",
            .method   = HTTP_GET,
            .handler  = dht_get_handler,
            .user_ctx = NULL
        };
        httpd_register_uri_handler(server, &dht_uri);

        // 注册按钮状态 JSON API 端点（参考 web_control.c 的方式）
        httpd_uri_t button_status_uri = {
            .uri      = "/button_status",
            .method   = HTTP_GET,
            .handler  = button_status_get_handler,
            .user_ctx = NULL
        };
        httpd_register_uri_handler(server, &button_status_uri);

        httpd_uri_t motions_uri = {
            .uri      = "/motions",
            .method   = HTTP_GET,
            .handler  = motions_get_handler,
            .user_ctx = NULL
        };
        httpd_register_uri_handler(server, &motions_uri);

        httpd_uri_t motion_action_uri = {
            .uri      = "/motion_action",
            .method   = HTTP_GET,
            .handler  = motion_action_get_handler,
            .user_ctx = NULL
        };
        httpd_register_uri_handler(server, &motion_action_uri);

        httpd_uri_t set_uri = {
            .uri      = "/set",
            .method   = HTTP_GET,
            .handler  = set_get_handler,
            .user_ctx = NULL
        };
        httpd_register_uri_handler(server, &set_uri);

        // 注册favicon处理器，避免404警告
        httpd_uri_t favicon_uri = {
            .uri      = "/favicon.ico",
            .method   = HTTP_GET,
            .handler  = favicon_get_handler,
            .user_ctx = NULL
        };
        httpd_register_uri_handler(server, &favicon_uri);
    }
    return server;
}

