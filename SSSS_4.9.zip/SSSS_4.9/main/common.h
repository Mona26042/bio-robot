/*
 * common.h
 *
 * 全局共享数据与跨模块接口声明。
 * 这个头文件相当于整个项目的“公共状态中心”，网页、主循环、动作录制回放、
 * 舵机控制等模块都会依赖这里定义的全局变量和函数。
 */

#ifndef COMMON_H
#define COMMON_H

#include <stdbool.h>
#include <stdint.h>
#include <string.h>

// 每条腿包含 5 个舵机。
#define LEG_SERVO_COUNT_PER_LEG 5
#define LEG_SERVO_COUNT LEG_SERVO_COUNT_PER_LEG

// 左前腿主要关节 ID，供步态和局部动作模块使用。
#define SERVO_LF1_ID 1
#define SERVO_LF2_ID 2
#define SERVO_LF3_ID 3
#define SERVO_LF4_ID 4

// 舵机软件限位表。
// 所有位置值都基于 STS/SMS 协议的 0~4095 位置刻度。
#define SERVO_LF1_POS_MIN 1700
#define SERVO_LF1_POS_MAX 2700
#define SERVO_LF2_POS_MIN 700
#define SERVO_LF2_POS_MAX 3000
#define SERVO_LF3_POS_MIN 800
#define SERVO_LF3_POS_MAX 3500
#define SERVO_LF3_POS_PHYSICAL_MAX 3500
#define SERVO_LF4_POS_MIN 900
#define SERVO_LF4_POS_MAX 3100

#define SERVO_5_POS_MIN 1100
#define SERVO_5_POS_MAX 3000
#define SERVO_6_POS_MIN 1600
#define SERVO_6_POS_MAX 2500
#define SERVO_7_POS_MIN 700
#define SERVO_7_POS_MAX 3000
#define SERVO_8_POS_MIN 700
#define SERVO_8_POS_MAX 3300
#define SERVO_9_POS_MIN 900
#define SERVO_9_POS_MAX 3100
#define SERVO_10_POS_MIN 1200
#define SERVO_10_POS_MAX 3000

#define SERVO_11_POS_MIN 1500
#define SERVO_11_POS_MAX 2500
#define SERVO_12_POS_MIN 600
#define SERVO_12_POS_MAX 3100
#define SERVO_13_POS_MIN 700
#define SERVO_13_POS_MAX 3300
#define SERVO_14_POS_MIN 900
#define SERVO_14_POS_MAX 3100
#define SERVO_15_POS_MIN 1200
#define SERVO_15_POS_MAX 2900

#define SERVO_16_POS_MIN 1600
#define SERVO_16_POS_MAX 2500
#define SERVO_17_POS_MIN 1000
#define SERVO_17_POS_MAX 3400
#define SERVO_18_POS_MIN 600
#define SERVO_18_POS_MAX 3100
#define SERVO_19_POS_MIN 900
#define SERVO_19_POS_MAX 3200
#define SERVO_20_POS_MIN 1200
#define SERVO_20_POS_MAX 2900

// 动作录制/回放相关参数。
#define LEG_MOTION_FRAMES 400
#define FULL_MOTION_FRAMES 1200
#define FULL_MOTION_SERVO_COUNT 20
#define MOTION_REPLAY_SPEED_DEFAULT 1200
#define MOTION_REPLAY_ACC_DEFAULT 50
#define FULL_MOTION_FRAME_DT_DEFAULT_MS 100
#define FULL_MOTION_NAME_MAX_LEN 24

// 每条腿对应的舵机 ID 映射。
#define LEG1_SERVO_IDS {1, 2, 3, 4, 5}
#define LEG2_SERVO_IDS {6, 7, 8, 9, 10}
#define LEG3_SERVO_IDS {11, 12, 13, 14, 15}
#define LEG4_SERVO_IDS {16, 17, 18, 19, 20}

// 舵机 ID 顺序表，以及最近一次同步读取到的 1~20 号舵机位置缓存。
extern const uint8_t servoID[20];
extern int16_t servoPos_1to20[20];

// 网页状态区显示文本与心跳计数。
extern char work[32];
extern char message0[64];
extern char message1[64];
extern volatile uint32_t blink;

// 主循环和网页之间通过该命令枚举传递“接下来要做什么”。
typedef enum {
    CMD_NONE = 0,
    CMD_LOCK_ON,
    CMD_LOCK_OFF,
    CMD_LOCK_LEG1,
    CMD_LOCK_LEG2,
    CMD_LOCK_LEG3,
    CMD_LOCK_LEG4,
    CMD_SYNC_READ,
    CMD_WRITE_SHOW,
    CMD_PING_ID1,
    CMD_SET_POSITION,
    CMD_WRITE_SHOW_2,
    CMD_SET_POSITION_2,
    CMD_SET_POSITION_SYNC,
    CMD_DUAL_SERVO_ROTATE,
    CMD_RESTORE_POSE,
    CMD_FIXED_GAIT,
    CMD_READ_ANGLE_MODE,
    CMD_RECORD_LEG1,
    CMD_REPLAY_LEG1,
    CMD_RECORD_LEG2,
    CMD_REPLAY_LEG2,
    CMD_RECORD_LEG3,
    CMD_REPLAY_LEG3,
    CMD_RECORD_LEG4,
    CMD_REPLAY_LEG4,
    CMD_RECORD_FULL,
    CMD_REPLAY_FULL,
    CMD_REPLAY_MOTION1,
    CMD_SAVE_FULL_TO_STORAGE,
    CMD_LOAD_AND_REPLAY_FULL_FROM_STORAGE,
} servo_cmd_t;

extern volatile servo_cmd_t g_cmd;

// 网页滑块对应的目标位置缓存。
// 网页线程只改这些变量，真正写舵机由主循环统一处理。
extern volatile int16_t g_target_position;
extern volatile int16_t g_target_position_2;
extern volatile int16_t g_target_position_3;
extern volatile int16_t g_target_position_4;
extern volatile int16_t g_target_position_6;
extern volatile int16_t g_target_position_7;
extern volatile int16_t g_target_position_8;
extern volatile int16_t g_target_position_9;
extern volatile int16_t g_target_position_11;
extern volatile int16_t g_target_position_12;
extern volatile int16_t g_target_position_13;
extern volatile int16_t g_target_position_14;
extern volatile int16_t g_target_position_16;
extern volatile int16_t g_target_position_17;
extern volatile int16_t g_target_position_18;
extern volatile int16_t g_target_position_19;

// 与目标位置一一对应的“待更新”标志。
extern volatile bool g_need_update_pos1;
extern volatile bool g_need_update_pos2;
extern volatile bool g_need_update_pos3;
extern volatile bool g_need_update_pos4;
extern volatile bool g_need_update_pos6;
extern volatile bool g_need_update_pos7;
extern volatile bool g_need_update_pos8;
extern volatile bool g_need_update_pos9;
extern volatile bool g_need_update_pos11;
extern volatile bool g_need_update_pos12;
extern volatile bool g_need_update_pos13;
extern volatile bool g_need_update_pos14;
extern volatile bool g_need_update_pos16;
extern volatile bool g_need_update_pos17;
extern volatile bool g_need_update_pos18;
extern volatile bool g_need_update_pos19;

// Web 状态页使用的 HTML 输出缓冲区。
extern char g_dht_html_buf[8192];

// 模式开关。
// 主循环会根据这些布尔量决定当前进入“读角度 / 录制 / 回放”哪种工作模式。
extern volatile bool g_read_angle_mode;
extern volatile bool g_record_leg1_mode;
extern volatile bool g_record_leg2_mode;
extern volatile bool g_record_leg3_mode;
extern volatile bool g_record_leg4_mode;
extern volatile bool g_replay_leg1_mode;
extern volatile bool g_replay_leg2_mode;
extern volatile bool g_replay_leg3_mode;
extern volatile bool g_replay_leg4_mode;
extern volatile bool g_record_full_mode;
extern volatile bool g_replay_full_mode;
extern volatile bool g_replay_full_transition_mode;
extern volatile bool g_replay_motion1_mode;
extern volatile uint16_t g_teach_replay_loop_count;

// 四条腿的扭矩当前状态缓存。
extern volatile bool g_leg1_torque_enabled;
extern volatile bool g_leg2_torque_enabled;
extern volatile bool g_leg3_torque_enabled;
extern volatile bool g_leg4_torque_enabled;

// 录制缓冲区、帧数和回放索引。
extern int16_t recorded_motion_leg1[LEG_MOTION_FRAMES][LEG_SERVO_COUNT_PER_LEG];
extern int16_t recorded_motion_leg2[LEG_MOTION_FRAMES][LEG_SERVO_COUNT_PER_LEG];
extern int16_t recorded_motion_leg3[LEG_MOTION_FRAMES][LEG_SERVO_COUNT_PER_LEG];
extern int16_t recorded_motion_leg4[LEG_MOTION_FRAMES][LEG_SERVO_COUNT_PER_LEG];
extern uint16_t recorded_frame_count_leg1;
extern uint16_t recorded_frame_count_leg2;
extern uint16_t recorded_frame_count_leg3;
extern uint16_t recorded_frame_count_leg4;
extern bool has_recorded_motion_leg1;
extern bool has_recorded_motion_leg2;
extern bool has_recorded_motion_leg3;
extern bool has_recorded_motion_leg4;
extern uint16_t replay_frame_index_leg1;
extern uint16_t replay_frame_index_leg2;
extern uint16_t replay_frame_index_leg3;
extern uint16_t replay_frame_index_leg4;
extern int16_t recorded_motion_full[FULL_MOTION_FRAMES][FULL_MOTION_SERVO_COUNT];
extern uint16_t recorded_motion_full_dt_ms[FULL_MOTION_FRAMES];
extern uint16_t recorded_frame_count_full;
extern bool has_recorded_motion_full;
extern uint16_t replay_frame_index_full;
extern uint16_t dropped_frame_count_full;
extern uint16_t replay_motion1_frame_index;
extern char g_motion_storage_target_name[FULL_MOTION_NAME_MAX_LEN];

// 保存当前一条腿的姿态作为新的一帧。
void save_current_leg_frame(uint8_t leg_num);

// 清空指定腿的录制结果。
void clear_recorded_leg_motion(uint8_t leg_num);

// 启动指定腿的回放。
void start_replay_leg_motion(uint8_t leg_num);

// 推进指定腿的回放到下一帧。
void replay_leg_motion_next_frame(uint8_t leg_num);

// 开始录制 1~20 号舵机的全身动作。
void start_record_full_motion(void);

// 停止全身动作录制。
void stop_record_full_motion(void);

// 保存当前全身姿态为一帧，并记录这一帧的时间间隔。
void save_current_full_frame(uint16_t dt_ms);

// 清空全身动作录制结果。
void clear_recorded_full_motion(void);

// 启动全身动作回放。
void start_replay_full_motion(void);

// 停止全身动作回放。
void stop_replay_full_motion(void);

// 推进全身动作回放到下一帧。
void replay_full_motion_next_frame(void);

// 当全身回放需要循环时，启动“尾帧到首帧”的平滑过渡。
void start_full_motion_loop_transition(void);

// 推进全身动作循环过渡到下一帧。
void replay_full_motion_transition_next_frame(void);

// 读取当前全身回放下一帧应该等待的毫秒数。
uint16_t get_full_motion_replay_wait_ms(void);

// 启动“教学回放 1”模式。
void start_teach_replay(void);

// 推进“教学回放 1”到下一帧/下一条腿。
void replay_teach_next_frame(void);

// 把“教学回放 1”的全部内部状态重置为初始值。
void reset_teach_replay_state(void);

#endif // COMMON_H
