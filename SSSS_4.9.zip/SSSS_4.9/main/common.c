/*
 * common.c
 * 全局共享状态与动作录制/复现逻辑实现。
 * 这里保存网页状态文本、舵机角度缓存、动作帧缓存，并提供单腿/整套动作的录制、
 * 回放以及示教复现状态机。
 */

#include "common.h"
#include "motion_storage.h"
#include "servo_control.h"
#include "servo_protocol.h"
#include "esp_log.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include <stdio.h>
#include <string.h>

static const char *TAG __attribute__((unused)) = "COMMON";

#define FULL_MOTION_LOOP_TRANSITION_FRAMES 6
#define FULL_MOTION_LOOP_TRANSITION_DT_MS 80

// 全局舵机 ID 表与角度缓存，供读取、录制和网页显示共用。
// 统一保存 1 到 20 号舵机的 ID 顺序。
// 同步读写和位置缓存都默认使用这套顺序，避免不同模块各自维护一份编号表。
const uint8_t servoID[20] = {
    1, 2, 3, 4, 5, 6, 7, 8, 9, 10,
    11, 12, 13, 14, 15, 16, 17, 18, 19, 20
};
int16_t servoPos_1to20[20] = {0};

// 网页状态栏显示内容与系统心跳计数。
// 这几组全局文本会直接被网页状态接口读取。
// work 表示当前动作名，message0/message1 用来展示最近一次关键结果或提示信息。
char work[32] = "System idle";
char message0[64] = "null";
char message1[64] = "null";
volatile uint32_t blink = 0;

// 网页控制命令和滑块目标值。
// 网页按钮最终都会汇聚成一个命令枚举写到这里。
// 主控制任务每轮读取一次并清空，形成一个简单的“单消费者命令邮箱”。
volatile servo_cmd_t g_cmd = CMD_NONE;

// 这些目标位置变量对应网页上的各个滑块。
// HTTP 回调只负责写入目标值和置位 need_update，真正的串口写命令由主循环统一发送。
volatile int16_t g_target_position = 0;
volatile int16_t g_target_position_2 = 0;
volatile int16_t g_target_position_3 = 0;
volatile int16_t g_target_position_4 = 0;
volatile int16_t g_target_position_6 = 0;
volatile int16_t g_target_position_7 = 0;
volatile int16_t g_target_position_8 = 0;
volatile int16_t g_target_position_9 = 0;
volatile int16_t g_target_position_11 = 0;
volatile int16_t g_target_position_12 = 0;
volatile int16_t g_target_position_13 = 0;
volatile int16_t g_target_position_14 = 0;
volatile int16_t g_target_position_16 = 0;
volatile int16_t g_target_position_17 = 0;
volatile int16_t g_target_position_18 = 0;
volatile int16_t g_target_position_19 = 0;

volatile bool g_need_update_pos1 = false;
volatile bool g_need_update_pos2 = false;
volatile bool g_need_update_pos3 = false;
volatile bool g_need_update_pos4 = false;
volatile bool g_need_update_pos6 = false;
volatile bool g_need_update_pos7 = false;
volatile bool g_need_update_pos8 = false;
volatile bool g_need_update_pos9 = false;
volatile bool g_need_update_pos11 = false;
volatile bool g_need_update_pos12 = false;
volatile bool g_need_update_pos13 = false;
volatile bool g_need_update_pos14 = false;
volatile bool g_need_update_pos16 = false;
volatile bool g_need_update_pos17 = false;
volatile bool g_need_update_pos18 = false;
volatile bool g_need_update_pos19 = false;

char g_dht_html_buf[8192];

// 各种录制/回放模式开关。
// 这一组模式标志共同决定主循环当前属于哪种工作状态。
// 它们被网页回调置位后，会在 servo_control_task 中按优先级解释执行。
volatile bool g_read_angle_mode = false;
volatile bool g_record_leg1_mode = false;
volatile bool g_record_leg2_mode = false;
volatile bool g_record_leg3_mode = false;
volatile bool g_record_leg4_mode = false;
volatile bool g_replay_leg1_mode = false;
volatile bool g_replay_leg2_mode = false;
volatile bool g_replay_leg3_mode = false;
volatile bool g_replay_leg4_mode = false;
volatile bool g_record_full_mode = false;
volatile bool g_replay_full_mode = false;
volatile bool g_replay_full_transition_mode = false;
volatile bool g_replay_motion1_mode = false;
volatile uint16_t g_teach_replay_loop_count = 0;

volatile bool g_leg1_torque_enabled = true;
volatile bool g_leg2_torque_enabled = true;
volatile bool g_leg3_torque_enabled = true;
volatile bool g_leg4_torque_enabled = true;

// 单腿动作与整套动作的录制缓存。
// 单腿录制和整套动作录制的数据都保存在这里。
// 录制时按帧递增写入，回放时再按相同顺序取出，形成最直接的“示教数组”。
int16_t recorded_motion_leg1[LEG_MOTION_FRAMES][LEG_SERVO_COUNT_PER_LEG] = {0};
int16_t recorded_motion_leg2[LEG_MOTION_FRAMES][LEG_SERVO_COUNT_PER_LEG] = {0};
int16_t recorded_motion_leg3[LEG_MOTION_FRAMES][LEG_SERVO_COUNT_PER_LEG] = {0};
int16_t recorded_motion_leg4[LEG_MOTION_FRAMES][LEG_SERVO_COUNT_PER_LEG] = {0};
uint16_t recorded_frame_count_leg1 = 0;
uint16_t recorded_frame_count_leg2 = 0;
uint16_t recorded_frame_count_leg3 = 0;
uint16_t recorded_frame_count_leg4 = 0;
bool has_recorded_motion_leg1 = false;
bool has_recorded_motion_leg2 = false;
bool has_recorded_motion_leg3 = false;
bool has_recorded_motion_leg4 = false;
uint16_t replay_frame_index_leg1 = 0;
uint16_t replay_frame_index_leg2 = 0;
uint16_t replay_frame_index_leg3 = 0;
uint16_t replay_frame_index_leg4 = 0;
int16_t recorded_motion_full[FULL_MOTION_FRAMES][FULL_MOTION_SERVO_COUNT] = {0};
uint16_t recorded_motion_full_dt_ms[FULL_MOTION_FRAMES] = {0};
uint16_t recorded_frame_count_full = 0;
bool has_recorded_motion_full = false;
uint16_t replay_frame_index_full = 0;
uint16_t dropped_frame_count_full = 0;
uint16_t replay_motion1_frame_index = 0;
char g_motion_storage_target_name[FULL_MOTION_NAME_MAX_LEN] = {0};

// 示教复现与整套动作循环过渡的内部状态。
// 教学回放会按照这个腿序列依次播放。
// 额外的静态变量负责记录当前播放到哪条腿、已完成多少轮以及整套回放的过渡参数。
static const uint8_t s_teach_replay_order[] = {1, 3, 2, 4};
static uint8_t s_teach_replay_current_leg = 0;
static uint16_t s_teach_replay_completed_loops = 0;
static uint16_t s_full_replay_completed_loops = 0;
static int16_t s_full_transition_from[FULL_MOTION_SERVO_COUNT] = {0};
static int16_t s_full_transition_to[FULL_MOTION_SERVO_COUNT] = {0};
static uint16_t s_full_transition_frame_index = 0;
static uint16_t s_full_transition_frame_count = 0;
static uint16_t s_full_transition_max_delta = 0;
static uint16_t s_full_transition_avg_delta = 0;
static uint16_t s_full_motion_replay_wait_ms = FULL_MOTION_FRAME_DT_DEFAULT_MS;

// 根据腿编号返回对应的 5 个舵机 ID。
// 根据腿号返回这一条腿对应的 5 个舵机 ID。
// 后面的录制、回放、上锁/解锁逻辑都会通过这层映射，把“腿”转换成具体舵机编号。
static void get_leg_servo_ids(uint8_t leg_num, uint8_t *id_list, int *count)
{
    static const uint8_t leg1_ids[] = LEG1_SERVO_IDS;
    static const uint8_t leg2_ids[] = LEG2_SERVO_IDS;
    static const uint8_t leg3_ids[] = LEG3_SERVO_IDS;
    static const uint8_t leg4_ids[] = LEG4_SERVO_IDS;

    const uint8_t *ids = NULL;
    *count = LEG_SERVO_COUNT_PER_LEG;

    switch (leg_num) {
        case 1:
            ids = leg1_ids;
            break;
        case 2:
            ids = leg2_ids;
            break;
        case 3:
            ids = leg3_ids;
            break;
        case 4:
            ids = leg4_ids;
            break;
        default:
            *count = 0;
            return;
    }

    for (int i = 0; i < LEG_SERVO_COUNT_PER_LEG; ++i) {
        id_list[i] = ids[i];
    }
}

// 根据腿编号返回对应动作缓存的二维数组首地址。
// 根据腿号返回对应的录制二维数组首地址。
// 这样保存帧和回放帧时就能复用同一套代码，而不用为 4 条腿分别写重复分支。
static int16_t (*get_leg_motion_array(uint8_t leg_num))[LEG_SERVO_COUNT_PER_LEG]
{
    switch (leg_num) {
        case 1:
            return recorded_motion_leg1;
        case 2:
            return recorded_motion_leg2;
        case 3:
            return recorded_motion_leg3;
        case 4:
            return recorded_motion_leg4;
        default:
            return NULL;
    }
}

// 根据腿编号返回已录制帧数的指针，便于统一读写。
// 返回指定腿的“已录制帧数”变量地址，便于外部统一读写。
static uint16_t *get_leg_frame_count_ptr(uint8_t leg_num)
{
    switch (leg_num) {
        case 1:
            return &recorded_frame_count_leg1;
        case 2:
            return &recorded_frame_count_leg2;
        case 3:
            return &recorded_frame_count_leg3;
        case 4:
            return &recorded_frame_count_leg4;
        default:
            return NULL;
    }
}

// 根据腿编号返回“是否已有录制动作”的标志位指针。
// 返回指定腿是否已经拥有有效录制数据的标志位地址。
static bool *get_leg_has_motion_ptr(uint8_t leg_num)
{
    switch (leg_num) {
        case 1:
            return &has_recorded_motion_leg1;
        case 2:
            return &has_recorded_motion_leg2;
        case 3:
            return &has_recorded_motion_leg3;
        case 4:
            return &has_recorded_motion_leg4;
        default:
            return NULL;
    }
}

// 根据腿编号返回回放模式开关的指针。
// 返回指定腿回放模式开关的地址，供通用回放控制逻辑复用。
static volatile bool *get_leg_replay_mode_ptr(uint8_t leg_num)
{
    switch (leg_num) {
        case 1:
            return &g_replay_leg1_mode;
        case 2:
            return &g_replay_leg2_mode;
        case 3:
            return &g_replay_leg3_mode;
        case 4:
            return &g_replay_leg4_mode;
        default:
            return NULL;
    }
}

// 根据腿编号返回当前回放帧索引的指针。
// 返回指定腿当前回放帧索引的地址，便于通用函数推进播放进度。
static uint16_t *get_leg_replay_index_ptr(uint8_t leg_num)
{
    switch (leg_num) {
        case 1:
            return &replay_frame_index_leg1;
        case 2:
            return &replay_frame_index_leg2;
        case 3:
            return &replay_frame_index_leg3;
        case 4:
            return &replay_frame_index_leg4;
        default:
            return NULL;
    }
}

// 从最近一次同步读取结果里查询指定 ID 的当前位置。
// 从最近一次同步读取结果中查找某个舵机当前位置。
// 录制动作时，保存到数组里的就是这里查到的位置值。
static int16_t find_servo_position(uint8_t target_id)
{
    if (target_id >= 1 && target_id <= 20) {
        return servoPos_1to20[target_id - 1];
    }
    return 0;
}

// 规范化整套动作帧间隔，避免出现 0ms 导致调度异常。
// 把整套动作录制得到的帧间隔限制到合理范围内。
// 这样既能过滤偶发的超长采样间隔，也能避免回放节奏快到舵机来不及执行。
static uint16_t normalize_full_motion_dt_ms(uint16_t dt_ms)
{
    return dt_ms == 0 ? FULL_MOTION_FRAME_DT_DEFAULT_MS : dt_ms;
}

// 按 ID 列表把当前舵机角度复制到目标数组中，供录制缓存使用。
// 按指定 ID 列表，把当前姿态拷贝到目标帧缓存中。
// 这个函数是录制流程的核心桥梁：它把“实时读数”转成“可回放帧数据”。
static void copy_recorded_servo_positions(const uint8_t *id_list, int16_t *dest_positions, int count)
{
    if (id_list == NULL || dest_positions == NULL || count <= 0) {
        return;
    }

    for (int i = 0; i < count; ++i) {
        dest_positions[i] = find_servo_position(id_list[i]);
    }
}

// 对一组舵机执行同步位置写入，内部统一补上限位、速度和加速度参数。
static void sync_write_motion_positions(const uint8_t *id_list,
                                        const int16_t *source_positions,
                                        int count)
{
    if (id_list == NULL || source_positions == NULL || count <= 0) {
        return;
    }

    uint8_t sync_ids[FULL_MOTION_SERVO_COUNT];
    int16_t sync_positions[FULL_MOTION_SERVO_COUNT];
    uint16_t speeds[FULL_MOTION_SERVO_COUNT];
    uint8_t accs[FULL_MOTION_SERVO_COUNT];

    for (int i = 0; i < count; ++i) {
        sync_ids[i] = id_list[i];
        sync_positions[i] = limit_servo_position(sync_ids[i], source_positions[i]);
        speeds[i] = MOTION_REPLAY_SPEED_DEFAULT;
        accs[i] = MOTION_REPLAY_ACC_DEFAULT;
    }

    SyncWritePosEx(sync_ids, count, sync_positions, speeds, accs);
}

// 计算整套动作循环过渡时某个舵机在当前插值步的目标位置。
static int16_t interpolate_transition_position(int16_t from_pos,
                                               int16_t to_pos,
                                               uint16_t step_index,
                                               uint16_t step_count)
{
    if (step_count == 0) {
        return to_pos;
    }

    const int32_t delta = (int32_t)to_pos - (int32_t)from_pos;
    const int32_t interpolated =
        (int32_t)from_pos + ((delta * (int32_t)step_index) / (int32_t)step_count);

    return (int16_t)interpolated;
}

// 返回指定腿当前已经录制了多少帧。
// 读取指定腿当前已经录下来的帧数。
static uint16_t get_leg_recorded_frame_count(uint8_t leg_num)
{
    uint16_t *frame_count = get_leg_frame_count_ptr(leg_num);
    return frame_count != NULL ? *frame_count : 0;
}

// 判断指定腿是否存在可用于回放的录制动作。
// 判断指定腿是否有可用于回放的有效录制数据。
// 仅有模式标志还不够，至少还要有一帧以上的数据才允许进入回放。
static bool leg_has_recorded_motion(uint8_t leg_num)
{
    bool *has_motion = get_leg_has_motion_ptr(leg_num);
    uint16_t *frame_count = get_leg_frame_count_ptr(leg_num);

    return has_motion != NULL && frame_count != NULL && *has_motion && *frame_count > 0;
}

// 判断整套动作缓存里是否已经有可回放的数据。
// 判断整套动作是否已经录制完成并且存在有效帧。
static bool full_has_recorded_motion(void)
{
    return has_recorded_motion_full && recorded_frame_count_full > 0;
}

// 判断指定腿当前是否处于回放过程中。
// 查询某条腿当前是否处于单独回放状态。
static bool is_leg_replaying(uint8_t leg_num)
{
    volatile bool *replay_mode = get_leg_replay_mode_ptr(leg_num);
    return replay_mode != NULL && *replay_mode;
}

// 清空所有单腿回放标志和帧索引，避免不同模式互相干扰。
// 一次性清空四条腿的回放标志和帧索引。
// 教学回放在切腿或结束时会调用它，保证不会残留上一条腿的播放状态。
static void clear_all_leg_replay_state(void)
{
    g_replay_leg1_mode = false;
    g_replay_leg2_mode = false;
    g_replay_leg3_mode = false;
    g_replay_leg4_mode = false;

    replay_frame_index_leg1 = 0;
    replay_frame_index_leg2 = 0;
    replay_frame_index_leg3 = 0;
    replay_frame_index_leg4 = 0;
}

// 重置“示教复现”状态机，同时清理其依赖的单腿回放状态。
// 把教学回放相关的所有状态复位到初始值。
// 包括当前腿号、循环次数、总开关以及各腿自己的播放索引。
void reset_teach_replay_state(void)
{
    g_replay_motion1_mode = false;
    replay_motion1_frame_index = 0;
    s_teach_replay_current_leg = 0;
    s_teach_replay_completed_loops = 0;
    clear_all_leg_replay_state();
}

// 按既定顺序切换到下一条可回放的腿，用于示教复现流程。
// 教学回放按预设顺序寻找下一条有录制数据的腿并激活它。
// 如果已经全部播完，就在这里统一收尾并更新页面提示。
static bool activate_next_teach_replay_leg(void)
{
    const size_t replay_leg_count = sizeof(s_teach_replay_order) / sizeof(s_teach_replay_order[0]);

    while (true) {
        if (replay_motion1_frame_index >= replay_leg_count) {
            s_teach_replay_completed_loops++;
            reset_teach_replay_state();
            snprintf(work, sizeof(work), "Teach replay done");
            snprintf(message0, sizeof(message0),
                     "Teach replay finished: %u pass",
                     (unsigned)s_teach_replay_completed_loops);
            return false;
        }

        const uint8_t leg_num = s_teach_replay_order[replay_motion1_frame_index++];
        volatile bool *replay_mode = get_leg_replay_mode_ptr(leg_num);
        uint16_t *replay_index = get_leg_replay_index_ptr(leg_num);

        if (replay_mode == NULL || replay_index == NULL || !leg_has_recorded_motion(leg_num)) {
            continue;
        }

        clear_all_leg_replay_state();
        *replay_mode = true;
        *replay_index = 0;
        s_teach_replay_current_leg = leg_num;

        snprintf(work, sizeof(work), "Teach replay");
        snprintf(message0, sizeof(message0),
                 "Leg %u replay: %u frames",
                 (unsigned)leg_num,
                 (unsigned)get_leg_recorded_frame_count(leg_num));
        return true;
    }

    return false;
}

// 保存指定腿当前的一帧角度到录制缓存中。
// 把当前指定腿的 5 个舵机位置采样成一帧，追加到对应录制数组末尾。
// 录制满了之后不会再继续写，而是只保留提示信息，避免数组越界。
void save_current_leg_frame(uint8_t leg_num)
{
    int16_t (*motion_array)[LEG_SERVO_COUNT_PER_LEG] = get_leg_motion_array(leg_num);
    uint16_t *frame_count = get_leg_frame_count_ptr(leg_num);
    bool *has_motion = get_leg_has_motion_ptr(leg_num);

    if (motion_array == NULL || frame_count == NULL || has_motion == NULL) {
        return;
    }

    if (*frame_count >= LEG_MOTION_FRAMES) {
        static TickType_t last_warn_time = 0;
        const TickType_t current_time = xTaskGetTickCount();

        if (last_warn_time == 0 || (current_time - last_warn_time >= pdMS_TO_TICKS(1000))) {
            snprintf(message0, sizeof(message0),
                     "Leg%u record full: max %d",
                     (unsigned)leg_num,
                     LEG_MOTION_FRAMES);
            last_warn_time = current_time;
        }
        return;
    }

    uint8_t leg_ids[LEG_SERVO_COUNT_PER_LEG];
    int leg_count = 0;
    get_leg_servo_ids(leg_num, leg_ids, &leg_count);

    copy_recorded_servo_positions(leg_ids, motion_array[*frame_count], leg_count);

    (*frame_count)++;
    *has_motion = true;

    printf("Leg%u frame%u: {", (unsigned)leg_num, (unsigned)(*frame_count));
    for (int i = 0; i < leg_count; ++i) {
        printf("%d", motion_array[*frame_count - 1][i]);
        if (i + 1 < leg_count) {
            printf(", ");
        }
    }
    printf("}\n");
}

// 清空指定腿的录制缓存，并重置对应的回放索引。
// 清空指定腿的录制内容、帧数和回放索引，为下一次重新示教做准备。
void clear_recorded_leg_motion(uint8_t leg_num)
{
    uint16_t *frame_count = get_leg_frame_count_ptr(leg_num);
    bool *has_motion = get_leg_has_motion_ptr(leg_num);
    uint16_t *replay_index = get_leg_replay_index_ptr(leg_num);

    if (frame_count != NULL) {
        *frame_count = 0;
    }
    if (has_motion != NULL) {
        *has_motion = false;
    }
    if (replay_index != NULL) {
        *replay_index = 0;
    }
}

// 清空整套动作录制缓存和循环过渡相关状态。
// 清空整套动作录制缓存以及相关计数器。
void clear_recorded_full_motion(void)
{
    recorded_frame_count_full = 0;
    has_recorded_motion_full = false;
    replay_frame_index_full = 0;
    dropped_frame_count_full = 0;
    g_replay_full_transition_mode = false;
    s_full_replay_completed_loops = 0;
    s_full_transition_frame_index = 0;
    s_full_transition_frame_count = 0;
    s_full_transition_max_delta = 0;
    s_full_transition_avg_delta = 0;
    s_full_motion_replay_wait_ms = FULL_MOTION_FRAME_DT_DEFAULT_MS;
    memset(recorded_motion_full, 0, sizeof(recorded_motion_full));
    memset(recorded_motion_full_dt_ms, 0, sizeof(recorded_motion_full_dt_ms));
    memset(s_full_transition_from, 0, sizeof(s_full_transition_from));
    memset(s_full_transition_to, 0, sizeof(s_full_transition_to));
    motion_storage_set_current_motion_name("No motion");
}

// 开始整套动作录制：先清缓存、关闭扭矩，再进入记录状态。
// 开始整套动作录制：先清空旧数据，再打开模式标志，并更新网页提示。
void start_record_full_motion(void)
{
    reset_teach_replay_state();
    g_replay_full_mode = false;
    g_replay_full_transition_mode = false;
    clear_recorded_full_motion();
    lock_off_all();
    g_record_full_mode = true;
    sync_read_once();
    motion_storage_set_current_motion_name("Recording...");
    snprintf(work, sizeof(work), "整套录入中");
    snprintf(message0, sizeof(message0), "已开启整套动作录入");
    snprintf(message1, sizeof(message1), "记录 1-20 号舵机");
    printf("[record full] start - IDs 1-20\n");
}

// 停止整套动作录制，并根据实际录制结果恢复扭矩和状态文本。
// 停止整套动作录制，同时保留已经写入的帧，以便后续直接回放。
void stop_record_full_motion(void)
{
    const uint16_t frame_count = recorded_frame_count_full;
    const uint16_t dropped_count = dropped_frame_count_full;

    g_record_full_mode = false;
    has_recorded_motion_full = frame_count > 0;
    lock_on_all();
    motion_storage_set_current_motion_name(frame_count > 0 ? "RAM_unsaved" : "No motion");
    snprintf(work, sizeof(work), "整套录入结束");
    snprintf(message0, sizeof(message0), "整套动作录入停止: %u 帧", (unsigned)frame_count);
    snprintf(message1, sizeof(message1), "丢帧: %u", (unsigned)dropped_count);
    printf("[record full] stop - %u frames, dropped %u\n",
           (unsigned)frame_count,
           (unsigned)dropped_count);
}

// 将 1-20 号舵机当前角度保存为整套动作的一帧。
// 把当前所有参与整套动作回放的舵机位置记录成一帧，并额外保存这一帧距上一帧的时间间隔。
// 回放时正是依靠这个 dt_ms 数组来复原录制时的节奏。
void save_current_full_frame(uint16_t dt_ms)
{
    if (!g_record_full_mode) {
        return;
    }

    if (recorded_frame_count_full >= FULL_MOTION_FRAMES) {
        static TickType_t last_warn_time = 0;
        const TickType_t current_time = xTaskGetTickCount();

        dropped_frame_count_full++;

        if (last_warn_time == 0 || (current_time - last_warn_time >= pdMS_TO_TICKS(1000))) {
            snprintf(message0, sizeof(message0),
                     "整套动作已满: 最多 %d 帧",
                     FULL_MOTION_FRAMES);
            snprintf(message1, sizeof(message1),
                     "丢帧: %u",
                     (unsigned)dropped_frame_count_full);
            last_warn_time = current_time;
        }
        return;
    }

    dt_ms = normalize_full_motion_dt_ms(dt_ms);
    copy_recorded_servo_positions(servoID,
                                  recorded_motion_full[recorded_frame_count_full],
                                  FULL_MOTION_SERVO_COUNT);
    recorded_motion_full_dt_ms[recorded_frame_count_full] = dt_ms;
    recorded_frame_count_full++;
    has_recorded_motion_full = true;

    snprintf(message0, sizeof(message0),
             "已保存整套第 %u 帧",
             (unsigned)recorded_frame_count_full);
    snprintf(message1, sizeof(message1),
             "间隔=%u ms, 丢帧=%u",
             (unsigned)dt_ms,
             (unsigned)dropped_frame_count_full);
    printf("Full frame%u saved, dt=%u ms\n",
           (unsigned)recorded_frame_count_full,
           (unsigned)dt_ms);
}

// 为整套动作循环播放创建“末帧回到起始姿态”的平滑过渡段。
// 开始整套动作回放前的平滑过渡。
// 这里会记录“当前姿态”和“首帧目标姿态”，后续由 replay_full_motion_transition_next_frame 逐步插值。
void start_full_motion_loop_transition(void)
{
    if (recorded_frame_count_full == 0) {
        return;
    }

    memcpy(s_full_transition_from,
           recorded_motion_full[recorded_frame_count_full - 1],
           sizeof(s_full_transition_from));
    // The restore-pose table currently defines 17 IDs; keep unspecified IDs aligned to frame 0.
    build_restore_default_pose_positions(s_full_transition_to,
                                         FULL_MOTION_SERVO_COUNT,
                                         recorded_motion_full[0]);

    s_full_transition_frame_index = 0;
    s_full_transition_frame_count = FULL_MOTION_LOOP_TRANSITION_FRAMES;
    s_full_transition_max_delta = 0;
    s_full_transition_avg_delta = 0;

    uint32_t delta_sum = 0;
    for (int i = 0; i < FULL_MOTION_SERVO_COUNT; ++i) {
        int32_t delta = (int32_t)s_full_transition_to[i] - (int32_t)s_full_transition_from[i];
        uint32_t abs_delta = (uint32_t)(delta >= 0 ? delta : -delta);

        delta_sum += abs_delta;
        if (abs_delta > s_full_transition_max_delta) {
            s_full_transition_max_delta = (uint16_t)abs_delta;
        }
    }

    s_full_transition_avg_delta = (uint16_t)(delta_sum / FULL_MOTION_SERVO_COUNT);
    g_replay_full_mode = false;
    g_replay_full_transition_mode = true;
    s_full_motion_replay_wait_ms = FULL_MOTION_LOOP_TRANSITION_DT_MS;

    ESP_LOGI(TAG,
             "[full replay round complete] loops=%u target=%u",
             (unsigned)s_full_replay_completed_loops,
             (unsigned)g_teach_replay_loop_count);
    ESP_LOGI(TAG,
             "[full transition start] frames=%u dt=%u max_delta=%u avg_delta=%u",
             (unsigned)s_full_transition_frame_count,
             (unsigned)FULL_MOTION_LOOP_TRANSITION_DT_MS,
             (unsigned)s_full_transition_max_delta,
             (unsigned)s_full_transition_avg_delta);

    snprintf(work, sizeof(work), "Full transition");
    snprintf(message0, sizeof(message0),
             "To start pose: %u frames",
             (unsigned)s_full_transition_frame_count);
    snprintf(message1, sizeof(message1),
             "max=%u avg=%u",
             (unsigned)s_full_transition_max_delta,
             (unsigned)s_full_transition_avg_delta);
}

// 推进整套动作循环过渡段到下一帧，并在结束后重新进入正式回放。
// 执行整套动作首帧过渡中的下一步插值。
// 当过渡帧全部发送完成后，会自动切换到正式的整套动作回放模式。
void replay_full_motion_transition_next_frame(void)
{
    if (!g_replay_full_transition_mode || s_full_transition_frame_count == 0) {
        return;
    }

    const uint16_t step_index = (uint16_t)(s_full_transition_frame_index + 1);
    int16_t transition_positions[FULL_MOTION_SERVO_COUNT];

    for (int i = 0; i < FULL_MOTION_SERVO_COUNT; ++i) {
        transition_positions[i] = interpolate_transition_position(s_full_transition_from[i],
                                                                  s_full_transition_to[i],
                                                                  step_index,
                                                                  s_full_transition_frame_count);
    }

    sync_write_motion_positions(servoID, transition_positions, FULL_MOTION_SERVO_COUNT);
    s_full_motion_replay_wait_ms = FULL_MOTION_LOOP_TRANSITION_DT_MS;

    ESP_LOGI(TAG,
             "[full transition] frame=%u/%u max_delta=%u avg_delta=%u",
             (unsigned)step_index,
             (unsigned)s_full_transition_frame_count,
             (unsigned)s_full_transition_max_delta,
             (unsigned)s_full_transition_avg_delta);

    snprintf(work, sizeof(work), "Full transition");
    snprintf(message0, sizeof(message0),
             "Transition %u/%u",
             (unsigned)step_index,
             (unsigned)s_full_transition_frame_count);
    snprintf(message1, sizeof(message1),
             "max=%u avg=%u",
             (unsigned)s_full_transition_max_delta,
             (unsigned)s_full_transition_avg_delta);

    s_full_transition_frame_index++;

    if (s_full_transition_frame_index >= s_full_transition_frame_count) {
        g_replay_full_transition_mode = false;
        s_full_transition_frame_index = 0;
        s_full_transition_frame_count = 0;
        replay_frame_index_full = 0;
        s_full_motion_replay_wait_ms = FULL_MOTION_FRAME_DT_DEFAULT_MS;
        g_replay_full_mode = true;

        ESP_LOGI(TAG, "[full transition done] restart full motion replay from frame 0");

        snprintf(work, sizeof(work), "Full replay");
        snprintf(message0, sizeof(message0), "Transition done");
        snprintf(message1, sizeof(message1), "Restart frame 0");
    }
}

// 返回当前整套动作回放应该使用的帧间隔。
// 返回整套动作当前下一帧的等待时间，供主循环决定回放节拍。
uint16_t get_full_motion_replay_wait_ms(void)
{
    return normalize_full_motion_dt_ms(s_full_motion_replay_wait_ms);
}

// 停止整套动作回放，并清空循环相关状态。
// 停止整套动作回放，并清理过渡相关状态，确保下一次回放从头开始。
void stop_replay_full_motion(void)
{
    g_replay_full_mode = false;
    g_replay_full_transition_mode = false;
    replay_frame_index_full = 0;
    s_full_replay_completed_loops = 0;
    s_full_transition_frame_index = 0;
    s_full_transition_frame_count = 0;
    s_full_motion_replay_wait_ms = FULL_MOTION_FRAME_DT_DEFAULT_MS;
    snprintf(work, sizeof(work), "整套复现停止");
    snprintf(message0, sizeof(message0), "整套动作复现已停止");
    snprintf(message1, sizeof(message1), "总帧数: %u", (unsigned)recorded_frame_count_full);
}

// 检查缓存后启动整套动作回放，并立即发送第一帧。
// 如果存在有效整套录制数据，就从这里启动完整动作回放。
// 启动后通常先进入平滑过渡，再进入正式逐帧播放。
void start_replay_full_motion(void)
{
    if (!full_has_recorded_motion()) {
        g_replay_full_mode = false;
        g_replay_full_transition_mode = false;
        replay_frame_index_full = 0;
        snprintf(work, sizeof(work), "整套复现未启动");
        snprintf(message0, sizeof(message0), "没有可复现的整套动作");
        snprintf(message1, sizeof(message1), "请先录入整套动作");
        return;
    }

    reset_teach_replay_state();
    lock_on_all();
    g_replay_full_transition_mode = false;
    g_replay_full_mode = true;
    replay_frame_index_full = 0;
    s_full_replay_completed_loops = 0;
    s_full_transition_frame_index = 0;
    s_full_transition_frame_count = 0;
    s_full_motion_replay_wait_ms = FULL_MOTION_FRAME_DT_DEFAULT_MS;
    ESP_LOGI(TAG,
             "[full replay start] frames=%u loop_count=%u",
             (unsigned)recorded_frame_count_full,
             (unsigned)g_teach_replay_loop_count);

    if (recorded_frame_count_full >= 2) {
        const bool frames_differ =
            memcmp(recorded_motion_full[0],
                   recorded_motion_full[1],
                   sizeof(recorded_motion_full[0])) != 0;
        ESP_LOGI(TAG,
                 "[full replay compare] frame1/frame2 differ=%s "
                 "f1 ids=%u,%u,%u,%u pos=%d,%d,%d,%d "
                 "f2 pos=%d,%d,%d,%d dt=%u/%u ms",
                 frames_differ ? "yes" : "no",
                 (unsigned)servoID[0], (unsigned)servoID[1],
                 (unsigned)servoID[2], (unsigned)servoID[3],
                 recorded_motion_full[0][0], recorded_motion_full[0][1],
                 recorded_motion_full[0][2], recorded_motion_full[0][3],
                 recorded_motion_full[1][0], recorded_motion_full[1][1],
                 recorded_motion_full[1][2], recorded_motion_full[1][3],
                 (unsigned)recorded_motion_full_dt_ms[0],
                 (unsigned)recorded_motion_full_dt_ms[1]);
    }

    snprintf(work, sizeof(work), "整套复现中");
    snprintf(message0, sizeof(message0),
             "开始整套动作复现: %u 帧",
             (unsigned)recorded_frame_count_full);
    snprintf(message1, sizeof(message1), "同步下发 1-20 号舵机");

    replay_full_motion_next_frame();
}

// 向前推进整套动作回放一帧，并在需要时处理循环过渡。
// 按当前整套动作回放索引发送下一帧，并更新下一次应等待的时间。
void replay_full_motion_next_frame(void)
{
    if (!g_replay_full_mode || recorded_frame_count_full == 0) {
        return;
    }

    if (replay_frame_index_full >= recorded_frame_count_full) {
        ESP_LOGI(TAG,
                 "[full replay done] completed=%u target=%u",
                 (unsigned)s_full_replay_completed_loops,
                 (unsigned)g_teach_replay_loop_count);
        g_replay_full_mode = false;
        replay_frame_index_full = 0;
        s_full_replay_completed_loops = 0;
        s_full_motion_replay_wait_ms = FULL_MOTION_FRAME_DT_DEFAULT_MS;
        snprintf(work, sizeof(work), "整套复现完成");
        snprintf(message0, sizeof(message0),
                 "整套动作复现完成: %u 帧",
                 (unsigned)recorded_frame_count_full);
        return;
    }

    const uint16_t current_frame_index = replay_frame_index_full;
    const uint16_t frame_dt_ms =
        normalize_full_motion_dt_ms(recorded_motion_full_dt_ms[current_frame_index]);

    ESP_LOGI(TAG,
             "[full replay send] replay_index=%u/%u count=%u "
             "ids=%u,%u,%u,%u pos=%d,%d,%d,%d speed=%u,%u,%u,%u acc=%u,%u,%u,%u "
             "packet=%u",
             (unsigned)current_frame_index,
             (unsigned)recorded_frame_count_full,
             (unsigned)FULL_MOTION_SERVO_COUNT,
             (unsigned)servoID[0], (unsigned)servoID[1],
             (unsigned)servoID[2], (unsigned)servoID[3],
             recorded_motion_full[current_frame_index][0],
             recorded_motion_full[current_frame_index][1],
             recorded_motion_full[current_frame_index][2],
             recorded_motion_full[current_frame_index][3],
             (unsigned)MOTION_REPLAY_SPEED_DEFAULT, (unsigned)MOTION_REPLAY_SPEED_DEFAULT,
             (unsigned)MOTION_REPLAY_SPEED_DEFAULT, (unsigned)MOTION_REPLAY_SPEED_DEFAULT,
             (unsigned)MOTION_REPLAY_ACC_DEFAULT, (unsigned)MOTION_REPLAY_ACC_DEFAULT,
             (unsigned)MOTION_REPLAY_ACC_DEFAULT, (unsigned)MOTION_REPLAY_ACC_DEFAULT,
             (unsigned)(7 + (FULL_MOTION_SERVO_COUNT * (1 + 7)) + 1));

    sync_write_motion_positions(servoID,
                                recorded_motion_full[current_frame_index],
                                FULL_MOTION_SERVO_COUNT);
    ESP_LOGI(TAG,
             "[full replay send] SyncWritePosEx done (void), next_wait=%u ms",
             (unsigned)frame_dt_ms);
    s_full_motion_replay_wait_ms = frame_dt_ms;
    replay_frame_index_full++;

    snprintf(work, sizeof(work), "整套复现中");
    snprintf(message0, sizeof(message0),
             "整套复现第 %u/%u 帧",
             (unsigned)(current_frame_index + 1),
             (unsigned)recorded_frame_count_full);
    snprintf(message1, sizeof(message1), "帧间隔=%u ms", (unsigned)frame_dt_ms);
    printf("Full replay frame%u/%u, dt=%u ms\n",
           (unsigned)(current_frame_index + 1),
           (unsigned)recorded_frame_count_full,
           (unsigned)frame_dt_ms);

    if (replay_frame_index_full >= recorded_frame_count_full) {
        s_full_replay_completed_loops++;

        if (g_teach_replay_loop_count == 0 ||
            s_full_replay_completed_loops < g_teach_replay_loop_count) {
            start_full_motion_loop_transition();
            return;
        }
    }

    if (replay_frame_index_full >= recorded_frame_count_full) {
        g_replay_full_mode = false;
        replay_frame_index_full = 0;
        s_full_replay_completed_loops = 0;
        s_full_motion_replay_wait_ms = FULL_MOTION_FRAME_DT_DEFAULT_MS;
        snprintf(work, sizeof(work), "整套复现完成");
        snprintf(message0, sizeof(message0),
                 "整套动作复现完成: %u 帧",
                 (unsigned)recorded_frame_count_full);
        snprintf(message1, sizeof(message1), "最后帧间隔=%u ms", (unsigned)frame_dt_ms);
    }
}

// 启动指定腿的录制动作回放。
// 启动某一条腿的单独回放。
// 会先检查该腿是否真的有录制数据，再把对应帧索引清零。
void start_replay_leg_motion(uint8_t leg_num)
{
    volatile bool *replay_mode = get_leg_replay_mode_ptr(leg_num);
    uint16_t *replay_index = get_leg_replay_index_ptr(leg_num);

    if (replay_mode == NULL || replay_index == NULL) {
        return;
    }

    if (!leg_has_recorded_motion(leg_num)) {
        snprintf(message0, sizeof(message0), "Leg%u has no recorded motion", (unsigned)leg_num);
        return;
    }

    lock_on_all();

    *replay_mode = true;
    *replay_index = 0;
    snprintf(work, sizeof(work), "Replay leg %u", (unsigned)leg_num);
    snprintf(message0, sizeof(message0),
             "Leg%u replay start: %u frames",
             (unsigned)leg_num,
             (unsigned)get_leg_recorded_frame_count(leg_num));

    replay_leg_motion_next_frame(leg_num);
}

// 将指定腿的动作回放推进到下一帧。
// 播放指定腿的下一帧录制动作，并在播完最后一帧后自动停止该腿回放。
void replay_leg_motion_next_frame(uint8_t leg_num)
{
    int16_t (*motion_array)[LEG_SERVO_COUNT_PER_LEG] = get_leg_motion_array(leg_num);
    uint16_t *frame_count = get_leg_frame_count_ptr(leg_num);
    volatile bool *replay_mode = get_leg_replay_mode_ptr(leg_num);
    uint16_t *replay_index = get_leg_replay_index_ptr(leg_num);

    if (motion_array == NULL || frame_count == NULL || replay_mode == NULL || replay_index == NULL) {
        return;
    }

    if (!(*replay_mode) || *frame_count == 0) {
        return;
    }

    if (*replay_index >= *frame_count) {
        *replay_mode = false;
        *replay_index = 0;
        snprintf(work, sizeof(work), "Leg %u done", (unsigned)leg_num);
        snprintf(message0, sizeof(message0),
                 "Leg%u replay done: %u frames",
                 (unsigned)leg_num,
                 (unsigned)(*frame_count));
        return;
    }

    uint8_t leg_ids[LEG_SERVO_COUNT_PER_LEG];
    int leg_count = 0;
    get_leg_servo_ids(leg_num, leg_ids, &leg_count);

    sync_write_motion_positions(leg_ids, motion_array[*replay_index], leg_count);

    (*replay_index)++;

    if (*replay_index >= *frame_count) {
        *replay_mode = false;
        *replay_index = 0;
        snprintf(work, sizeof(work), "Leg %u done", (unsigned)leg_num);
        snprintf(message0, sizeof(message0),
                 "Leg%u replay done: %u frames",
                 (unsigned)leg_num,
                 (unsigned)(*frame_count));
    }
}

// 启动“示教复现”模式，按预设顺序轮流回放已录制的腿部动作。
// 启动教学回放总流程。
// 它不是直接发送舵机命令，而是先把回放状态切到第一条可播放的腿。
void start_teach_replay(void)
{
    if (!leg_has_recorded_motion(1) &&
        !leg_has_recorded_motion(2) &&
        !leg_has_recorded_motion(3) &&
        !leg_has_recorded_motion(4)) {
        reset_teach_replay_state();
        snprintf(work, sizeof(work), "Teach replay off");
        snprintf(message0, sizeof(message0), "No recorded motions");
        return;
    }

    lock_on_all();

    g_replay_motion1_mode = true;
    replay_motion1_frame_index = 0;
    s_teach_replay_current_leg = 0;
    s_teach_replay_completed_loops = 0;
    clear_all_leg_replay_state();

    if (!activate_next_teach_replay_leg()) {
        return;
    }

    replay_leg_motion_next_frame(s_teach_replay_current_leg);
    if (!is_leg_replaying(s_teach_replay_current_leg)) {
        s_teach_replay_current_leg = 0;
    }
}

// 推进“示教复现”状态机，必要时切换到下一条腿继续回放。
// 推进教学回放中的当前步骤。
// 当前腿播放结束后，会自动切到下一条腿，直到整轮教学动作全部完成。
void replay_teach_next_frame(void)
{
    if (!g_replay_motion1_mode) {
        s_teach_replay_current_leg = 0;
        return;
    }

    if (s_teach_replay_current_leg == 0) {
        if (!activate_next_teach_replay_leg()) {
            return;
        }
    } else if (!is_leg_replaying(s_teach_replay_current_leg)) {
        s_teach_replay_current_leg = 0;
        if (!activate_next_teach_replay_leg()) {
            return;
        }
    }

    replay_leg_motion_next_frame(s_teach_replay_current_leg);

    if (!g_replay_motion1_mode || !is_leg_replaying(s_teach_replay_current_leg)) {
        s_teach_replay_current_leg = 0;
    }
}
