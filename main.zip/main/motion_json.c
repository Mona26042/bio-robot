/*
 * motion_json.c
 *
 * 动作 JSON 编解码实现。
 * 模块职责：负责动作文档的校验、解析、元数据提取以及序列化输出。
 */

#include "motion_json.h"

#include <ctype.h>
#include <errno.h>
#include <limits.h>
#include <stdarg.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MOTION_JSON_INITIAL_CHECKSUM 2166136261u

typedef struct {
    char *data;
    size_t len;
    size_t cap;
} json_builder_t;

// 增量更新动作载荷校验值，用于检测动作帧内容是否被修改。
static uint32_t checksum_update(uint32_t checksum, const void *data, size_t len)
{
    const uint8_t *bytes = (const uint8_t *)data;

    for (size_t i = 0; i < len; ++i) {
        checksum ^= bytes[i];
        checksum *= 16777619u;
    }

    return checksum;
}

// 把非法的 0ms 帧间隔纠正为默认值，避免后续调度异常。
static uint16_t normalize_dt_ms(uint16_t dt_ms)
{
    return dt_ms == 0 ? FULL_MOTION_FRAME_DT_DEFAULT_MS : dt_ms;
}

static void compute_doc_derived_fields(const motion_json_doc_t *doc,
                                       uint32_t *total_duration_ms,
                                       uint32_t *payload_checksum)
{
    uint32_t total_duration = 0;
    uint32_t checksum = MOTION_JSON_INITIAL_CHECKSUM;

    if (doc != NULL && doc->positions != NULL && doc->dts != NULL) {
        for (uint16_t frame_index = 0; frame_index < doc->frame_count; ++frame_index) {
            const uint16_t dt_ms = normalize_dt_ms(doc->dts[frame_index]);
            total_duration += dt_ms;
            checksum = checksum_update(checksum, &dt_ms, sizeof(dt_ms));
            checksum = checksum_update(checksum,
                                       doc->positions[frame_index],
                                       sizeof(doc->positions[frame_index]));
        }
    }

    if (total_duration_ms != NULL) {
        *total_duration_ms = total_duration;
    }
    if (payload_checksum != NULL) {
        *payload_checksum = checksum;
    }
}

// 用动作名称和外部帧缓存初始化一份待编码/待解析文档。
esp_err_t motion_json_doc_init(motion_json_doc_t *doc,
                               const char *motion_name,
                               int16_t (*positions)[FULL_MOTION_SERVO_COUNT],
                               uint16_t *dts)
{
    if (doc == NULL || positions == NULL || dts == NULL) {
        return ESP_ERR_INVALID_ARG;
    }

    memset(doc, 0, sizeof(*doc));
    doc->positions = positions;
    doc->dts = dts;
    snprintf(doc->name,
             sizeof(doc->name),
             "%s",
             (motion_name != NULL && motion_name[0] != '\0') ? motion_name : "No motion");
    return ESP_OK;
}

// 清空文档对象，供外部在失败回滚或重复复用时重置状态。
void motion_json_doc_reset(motion_json_doc_t *doc)
{
    if (doc != NULL) {
        memset(doc, 0, sizeof(*doc));
    }
}

// 重新计算文档衍生字段，确保总时长和校验值与帧内容一致。
void motion_json_refresh_doc_derived_fields(motion_json_doc_t *doc)
{
    if (doc == NULL) {
        return;
    }

    compute_doc_derived_fields(doc, &doc->total_duration_ms, &doc->payload_checksum);
}

static void skip_json_ws(const char **cursor)
{
    while (cursor != NULL && *cursor != NULL && **cursor != '\0' &&
           isspace((unsigned char)**cursor)) {
        ++(*cursor);
    }
}

static void skip_utf8_bom(const char **cursor)
{
    if (cursor == NULL || *cursor == NULL) {
        return;
    }

    const unsigned char *bytes = (const unsigned char *)(*cursor);
    if (bytes[0] == 0xEF && bytes[1] == 0xBB && bytes[2] == 0xBF) {
        *cursor += 3;
    }
}

static int hex_char_to_int(char ch)
{
    if (ch >= '0' && ch <= '9') {
        return ch - '0';
    }
    if (ch >= 'a' && ch <= 'f') {
        return 10 + (ch - 'a');
    }
    if (ch >= 'A' && ch <= 'F') {
        return 10 + (ch - 'A');
    }
    return -1;
}

static bool parse_json_string_copy(const char **cursor, char *out_buf, size_t out_buf_len)
{
    if (cursor == NULL || *cursor == NULL || **cursor != '"' ||
        out_buf == NULL || out_buf_len == 0) {
        return false;
    }

    size_t out_index = 0;
    out_buf[0] = '\0';
    ++(*cursor);

    while (**cursor != '\0') {
        char ch = **cursor;
        if (ch == '\\') {
            ++(*cursor);
            ch = **cursor;
            if (ch == '\0') {
                return false;
            }

            switch (ch) {
                case '"':
                case '\\':
                case '/':
                    break;
                case 'b':
                    ch = '\b';
                    break;
                case 'f':
                    ch = '\f';
                    break;
                case 'n':
                    ch = '\n';
                    break;
                case 'r':
                    ch = '\r';
                    break;
                case 't':
                    ch = '\t';
                    break;
                case 'u': {
                    int value = 0;
                    for (int i = 0; i < 4; ++i) {
                        ++(*cursor);
                        const int nibble = hex_char_to_int(**cursor);
                        if (nibble < 0) {
                            return false;
                        }
                        value = (value << 4) | nibble;
                    }
                    ch = (value >= 0 && value <= 0x7f) ? (char)value : '?';
                    break;
                }
                default:
                    return false;
            }
        } else if (ch == '"') {
            ++(*cursor);
            break;
        }

        if (out_index + 1 >= out_buf_len) {
            return false;
        }

        out_buf[out_index++] = ch;
        ++(*cursor);
    }

    if (**cursor == '\0' && (*cursor)[-1] != '"') {
        return false;
    }

    out_buf[out_index] = '\0';
    return true;
}

static bool parse_json_int32(const char **cursor, int32_t *out_value)
{
    if (cursor == NULL || *cursor == NULL || out_value == NULL) {
        return false;
    }

    errno = 0;
    char *end_ptr = NULL;
    long value = strtol(*cursor, &end_ptr, 10);
    if (end_ptr == *cursor || end_ptr == NULL) {
        return false;
    }

    if (errno == ERANGE || value < INT32_MIN || value > INT32_MAX) {
        return false;
    }

    if (*end_ptr == '.' || *end_ptr == 'e' || *end_ptr == 'E') {
        return false;
    }

    *out_value = (int32_t)value;
    *cursor = end_ptr;
    return true;
}

static bool parse_json_uint32(const char **cursor, uint32_t *out_value)
{
    if (cursor == NULL || *cursor == NULL || out_value == NULL) {
        return false;
    }

    if (**cursor == '-') {
        return false;
    }

    errno = 0;
    char *end_ptr = NULL;
    unsigned long value = strtoul(*cursor, &end_ptr, 10);
    if (end_ptr == *cursor || end_ptr == NULL) {
        return false;
    }

    if (errno == ERANGE || value > UINT32_MAX) {
        return false;
    }

    if (*end_ptr == '.' || *end_ptr == 'e' || *end_ptr == 'E') {
        return false;
    }

    *out_value = (uint32_t)value;
    *cursor = end_ptr;
    return true;
}

static bool parse_frame_positions(const char **cursor, int16_t *positions)
{
    if (cursor == NULL || *cursor == NULL || positions == NULL) {
        return false;
    }

    skip_json_ws(cursor);
    if (**cursor != '[') {
        return false;
    }

    ++(*cursor);
    for (int i = 0; i < FULL_MOTION_SERVO_COUNT; ++i) {
        int32_t value = 0;
        skip_json_ws(cursor);
        if (!parse_json_int32(cursor, &value) ||
            value < INT16_MIN || value > INT16_MAX) {
            return false;
        }

        positions[i] = (int16_t)value;
        skip_json_ws(cursor);

        if (i + 1 < FULL_MOTION_SERVO_COUNT) {
            if (**cursor != ',') {
                return false;
            }
            ++(*cursor);
        }
    }

    skip_json_ws(cursor);
    if (**cursor != ']') {
        return false;
    }

    ++(*cursor);
    return true;
}

static bool parse_frame_object(const char **cursor,
                               uint16_t *dt_ms,
                               int16_t *positions)
{
    if (cursor == NULL || *cursor == NULL || dt_ms == NULL || positions == NULL) {
        return false;
    }

    bool has_dt = false;
    bool has_positions = false;
    uint16_t parsed_dt = FULL_MOTION_FRAME_DT_DEFAULT_MS;

    skip_json_ws(cursor);
    if (**cursor != '{') {
        return false;
    }

    ++(*cursor);
    skip_json_ws(cursor);
    if (**cursor == '}') {
        return false;
    }

    while (**cursor != '\0') {
        char key[32];
        uint32_t uvalue = 0;

        skip_json_ws(cursor);
        if (!parse_json_string_copy(cursor, key, sizeof(key))) {
            return false;
        }

        skip_json_ws(cursor);
        if (**cursor != ':') {
            return false;
        }
        ++(*cursor);
        skip_json_ws(cursor);

        if (strcmp(key, "dtMs") == 0) {
            if (has_dt ||
                !parse_json_uint32(cursor, &uvalue) ||
                uvalue > UINT16_MAX) {
                return false;
            }
            parsed_dt = normalize_dt_ms((uint16_t)uvalue);
            has_dt = true;
        } else if (strcmp(key, "positions") == 0) {
            if (has_positions || !parse_frame_positions(cursor, positions)) {
                return false;
            }
            has_positions = true;
        } else {
            return false;
        }

        skip_json_ws(cursor);
        if (**cursor == ',') {
            ++(*cursor);
            continue;
        }
        if (**cursor == '}') {
            ++(*cursor);
            break;
        }
        return false;
    }

    if (!has_dt || !has_positions) {
        return false;
    }

    *dt_ms = parsed_dt;
    return true;
}

static bool parse_motion_frames(const char **cursor, motion_json_doc_t *doc)
{
    if (cursor == NULL || *cursor == NULL || doc == NULL ||
        doc->positions == NULL || doc->dts == NULL) {
        return false;
    }

    skip_json_ws(cursor);
    if (**cursor != '[') {
        return false;
    }

    ++(*cursor);
    skip_json_ws(cursor);
    if (**cursor == ']') {
        return false;
    }

    doc->frame_count = 0;
    doc->total_duration_ms = 0;
    doc->payload_checksum = MOTION_JSON_INITIAL_CHECKSUM;

    while (**cursor != '\0') {
        if (doc->frame_count >= FULL_MOTION_FRAMES) {
            return false;
        }

        if (!parse_frame_object(cursor,
                                &doc->dts[doc->frame_count],
                                doc->positions[doc->frame_count])) {
            return false;
        }

        doc->total_duration_ms += doc->dts[doc->frame_count];
        doc->payload_checksum = checksum_update(doc->payload_checksum,
                                                &doc->dts[doc->frame_count],
                                                sizeof(doc->dts[doc->frame_count]));
        doc->payload_checksum = checksum_update(doc->payload_checksum,
                                                doc->positions[doc->frame_count],
                                                sizeof(doc->positions[doc->frame_count]));
        ++doc->frame_count;

        skip_json_ws(cursor);
        if (**cursor == ',') {
            ++(*cursor);
            continue;
        }
        if (**cursor == ']') {
            ++(*cursor);
            return doc->frame_count > 0;
        }
        return false;
    }

    return false;
}

// 解析完整动作 JSON，并校验格式版本、动作名和帧摘要信息。
esp_err_t motion_json_parse_document(const char *json_text,
                                     const char *expected_motion_name,
                                     motion_json_doc_t *doc)
{
    if (json_text == NULL || doc == NULL ||
        doc->positions == NULL || doc->dts == NULL) {
        return ESP_ERR_INVALID_ARG;
    }

    const char *cursor = json_text;
    char format[24] = {0};
    char name[MOTION_STORAGE_NAME_MAX_LEN] = {0};
    uint32_t servo_count = 0;
    uint32_t frame_count = 0;
    uint32_t total_duration_ms = 0;
    uint32_t payload_checksum = 0;
    bool has_format = false;
    bool has_name = false;
    bool has_servo_count = false;
    bool has_frame_count = false;
    bool has_total_duration = false;
    bool has_payload_checksum = false;
    bool has_frames = false;

    doc->frame_count = 0;
    doc->total_duration_ms = 0;
    doc->payload_checksum = 0;

    skip_utf8_bom(&cursor);
    skip_json_ws(&cursor);
    if (*cursor != '{') {
        return ESP_ERR_INVALID_RESPONSE;
    }

    ++cursor;
    skip_json_ws(&cursor);
    if (*cursor == '}') {
        return ESP_ERR_INVALID_RESPONSE;
    }

    while (*cursor != '\0') {
        char key[32];

        skip_json_ws(&cursor);
        if (!parse_json_string_copy(&cursor, key, sizeof(key))) {
            return ESP_ERR_INVALID_RESPONSE;
        }

        skip_json_ws(&cursor);
        if (*cursor != ':') {
            return ESP_ERR_INVALID_RESPONSE;
        }
        ++cursor;
        skip_json_ws(&cursor);

        if (strcmp(key, "format") == 0) {
            if (has_format || !parse_json_string_copy(&cursor, format, sizeof(format))) {
                return ESP_ERR_INVALID_RESPONSE;
            }
            has_format = true;
        } else if (strcmp(key, "name") == 0) {
            if (has_name || !parse_json_string_copy(&cursor, name, sizeof(name))) {
                return ESP_ERR_INVALID_RESPONSE;
            }
            has_name = true;
        } else if (strcmp(key, "servoCount") == 0) {
            if (has_servo_count || !parse_json_uint32(&cursor, &servo_count)) {
                return ESP_ERR_INVALID_RESPONSE;
            }
            has_servo_count = true;
        } else if (strcmp(key, "frameCount") == 0) {
            if (has_frame_count || !parse_json_uint32(&cursor, &frame_count)) {
                return ESP_ERR_INVALID_RESPONSE;
            }
            has_frame_count = true;
        } else if (strcmp(key, "totalDurationMs") == 0) {
            if (has_total_duration || !parse_json_uint32(&cursor, &total_duration_ms)) {
                return ESP_ERR_INVALID_RESPONSE;
            }
            has_total_duration = true;
        } else if (strcmp(key, "payloadChecksum") == 0) {
            if (has_payload_checksum || !parse_json_uint32(&cursor, &payload_checksum)) {
                return ESP_ERR_INVALID_RESPONSE;
            }
            has_payload_checksum = true;
        } else if (strcmp(key, "frames") == 0) {
            if (has_frames || !parse_motion_frames(&cursor, doc)) {
                return ESP_ERR_INVALID_RESPONSE;
            }
            has_frames = true;
        } else {
            return ESP_ERR_INVALID_RESPONSE;
        }

        skip_json_ws(&cursor);
        if (*cursor == ',') {
            ++cursor;
            continue;
        }
        if (*cursor == '}') {
            ++cursor;
            break;
        }

        return ESP_ERR_INVALID_RESPONSE;
    }

    skip_json_ws(&cursor);
    if (!has_format || !has_name || !has_servo_count || !has_frame_count ||
        !has_total_duration || !has_payload_checksum || !has_frames ||
        *cursor != '\0') {
        return ESP_ERR_INVALID_RESPONSE;
    }

    if (strcmp(format, MOTION_JSON_FORMAT) != 0) {
        return ESP_ERR_INVALID_RESPONSE;
    }

    if (servo_count != FULL_MOTION_SERVO_COUNT ||
        frame_count == 0 || frame_count > FULL_MOTION_FRAMES ||
        frame_count != doc->frame_count ||
        total_duration_ms != doc->total_duration_ms ||
        payload_checksum != doc->payload_checksum) {
        return ESP_ERR_INVALID_RESPONSE;
    }

    if (expected_motion_name != NULL && expected_motion_name[0] != '\0' &&
        strcmp(name, expected_motion_name) != 0) {
        return ESP_ERR_INVALID_RESPONSE;
    }

    snprintf(doc->name, sizeof(doc->name), "%s", name);
    return ESP_OK;
}

// 从动作 JSON 中提取摘要信息，避免目录场景加载整套帧数据。
esp_err_t motion_json_extract_metadata(const char *json_text,
                                       motion_json_metadata_t *metadata)
{
    if (json_text == NULL || metadata == NULL) {
        return ESP_ERR_INVALID_ARG;
    }

    const char *cursor = json_text;
    char format[24] = {0};
    uint32_t servo_count = 0;
    uint32_t frame_count = 0;
    uint32_t total_duration_ms = 0;
    uint32_t payload_checksum = 0;
    bool has_format = false;
    bool has_name = false;
    bool has_servo_count = false;
    bool has_frame_count = false;
    bool has_total_duration = false;
    bool has_payload_checksum = false;

    memset(metadata, 0, sizeof(*metadata));

    skip_utf8_bom(&cursor);
    skip_json_ws(&cursor);
    if (*cursor != '{') {
        return ESP_ERR_INVALID_RESPONSE;
    }

    ++cursor;
    skip_json_ws(&cursor);
    if (*cursor == '}') {
        return ESP_ERR_INVALID_RESPONSE;
    }

    while (*cursor != '\0') {
        char key[32];

        skip_json_ws(&cursor);
        if (!parse_json_string_copy(&cursor, key, sizeof(key))) {
            return ESP_ERR_INVALID_RESPONSE;
        }

        skip_json_ws(&cursor);
        if (*cursor != ':') {
            return ESP_ERR_INVALID_RESPONSE;
        }
        ++cursor;
        skip_json_ws(&cursor);

        if (strcmp(key, "format") == 0) {
            if (has_format || !parse_json_string_copy(&cursor, format, sizeof(format))) {
                return ESP_ERR_INVALID_RESPONSE;
            }
            has_format = true;
        } else if (strcmp(key, "name") == 0) {
            if (has_name ||
                !parse_json_string_copy(&cursor, metadata->name, sizeof(metadata->name))) {
                return ESP_ERR_INVALID_RESPONSE;
            }
            has_name = true;
        } else if (strcmp(key, "servoCount") == 0) {
            if (has_servo_count || !parse_json_uint32(&cursor, &servo_count)) {
                return ESP_ERR_INVALID_RESPONSE;
            }
            has_servo_count = true;
        } else if (strcmp(key, "frameCount") == 0) {
            if (has_frame_count || !parse_json_uint32(&cursor, &frame_count)) {
                return ESP_ERR_INVALID_RESPONSE;
            }
            has_frame_count = true;
        } else if (strcmp(key, "totalDurationMs") == 0) {
            if (has_total_duration || !parse_json_uint32(&cursor, &total_duration_ms)) {
                return ESP_ERR_INVALID_RESPONSE;
            }
            has_total_duration = true;
        } else if (strcmp(key, "payloadChecksum") == 0) {
            if (has_payload_checksum || !parse_json_uint32(&cursor, &payload_checksum)) {
                return ESP_ERR_INVALID_RESPONSE;
            }
            has_payload_checksum = true;
        } else {
            return ESP_ERR_INVALID_RESPONSE;
        }

        skip_json_ws(&cursor);
        if (*cursor == ',') {
            ++cursor;
            skip_json_ws(&cursor);
            if (*cursor == '\0') {
                break;
            }
            continue;
        }
        if (*cursor == '}') {
            ++cursor;
            break;
        }
        if (*cursor == '\0') {
            break;
        }

        return ESP_ERR_INVALID_RESPONSE;
    }

    skip_json_ws(&cursor);
    if (!has_format || !has_name || !has_servo_count || !has_frame_count ||
        !has_total_duration || !has_payload_checksum || *cursor != '\0') {
        return ESP_ERR_INVALID_RESPONSE;
    }

    if (strcmp(format, MOTION_JSON_FORMAT) != 0 ||
        servo_count != FULL_MOTION_SERVO_COUNT ||
        frame_count == 0 || frame_count > FULL_MOTION_FRAMES) {
        return ESP_ERR_INVALID_RESPONSE;
    }

    metadata->frame_count = (uint16_t)frame_count;
    metadata->total_duration_ms = total_duration_ms;
    metadata->payload_checksum = payload_checksum;
    return ESP_OK;
}

static bool json_builder_reserve(json_builder_t *builder, size_t extra_len)
{
    if (builder == NULL) {
        return false;
    }

    const size_t required_len = builder->len + extra_len + 1U;
    if (required_len <= builder->cap) {
        return true;
    }

    size_t new_cap = builder->cap == 0 ? 1024U : builder->cap;
    while (new_cap < required_len) {
        new_cap *= 2U;
    }

    char *new_data = realloc(builder->data, new_cap);
    if (new_data == NULL) {
        return false;
    }

    builder->data = new_data;
    builder->cap = new_cap;
    return true;
}

static bool json_builder_appendf(json_builder_t *builder, const char *fmt, ...)
{
    if (builder == NULL || fmt == NULL) {
        return false;
    }

    va_list args;
    va_start(args, fmt);
    va_list args_copy;
    va_copy(args_copy, args);
    const int written = vsnprintf(NULL, 0, fmt, args_copy);
    va_end(args_copy);

    if (written < 0 || !json_builder_reserve(builder, (size_t)written)) {
        va_end(args);
        return false;
    }

    vsnprintf(builder->data + builder->len,
              builder->cap - builder->len,
              fmt,
              args);
    va_end(args);

    builder->len += (size_t)written;
    return true;
}

// 把动作文档按统一格式输出成 JSON 字符串，供网页下载或写回存储。
esp_err_t motion_json_serialize_doc(const motion_json_doc_t *doc,
                                    char **json_text_out)
{
    if (doc == NULL || json_text_out == NULL ||
        doc->positions == NULL || doc->dts == NULL ||
        doc->frame_count == 0 || doc->frame_count > FULL_MOTION_FRAMES) {
        return ESP_ERR_INVALID_ARG;
    }

    uint32_t total_duration_ms = 0;
    uint32_t payload_checksum = 0;
    compute_doc_derived_fields(doc, &total_duration_ms, &payload_checksum);

    json_builder_t builder = {0};
    bool write_ok = json_builder_appendf(&builder, "{\n") &&
                    json_builder_appendf(&builder, "  \"format\": \"%s\",\n", MOTION_JSON_FORMAT) &&
                    json_builder_appendf(&builder, "  \"name\": \"%s\",\n", doc->name) &&
                    json_builder_appendf(&builder, "  \"servoCount\": %u,\n", (unsigned)FULL_MOTION_SERVO_COUNT) &&
                    json_builder_appendf(&builder, "  \"frameCount\": %u,\n", (unsigned)doc->frame_count) &&
                    json_builder_appendf(&builder, "  \"totalDurationMs\": %u,\n", (unsigned)total_duration_ms) &&
                    json_builder_appendf(&builder, "  \"payloadChecksum\": %u,\n", (unsigned)payload_checksum) &&
                    json_builder_appendf(&builder, "  \"frames\": [\n");

    for (uint16_t frame_index = 0; write_ok && frame_index < doc->frame_count; ++frame_index) {
        const uint16_t dt_ms = normalize_dt_ms(doc->dts[frame_index]);
        write_ok = json_builder_appendf(&builder,
                                        "    {\"dtMs\": %u, \"positions\": [",
                                        (unsigned)dt_ms);

        for (int servo_index = 0; write_ok && servo_index < FULL_MOTION_SERVO_COUNT; ++servo_index) {
            write_ok = json_builder_appendf(&builder,
                                            "%s%d",
                                            servo_index == 0 ? "" : ", ",
                                            doc->positions[frame_index][servo_index]);
        }

        write_ok = write_ok &&
                   json_builder_appendf(&builder,
                                        "]}%s\n",
                                        (frame_index + 1 < doc->frame_count) ? "," : "");
    }

    write_ok = write_ok &&
               json_builder_appendf(&builder, "  ]\n") &&
               json_builder_appendf(&builder, "}\n");

    if (!write_ok) {
        free(builder.data);
        return ESP_ERR_NO_MEM;
    }

    *json_text_out = builder.data;
    return ESP_OK;
}
