/*
 * motion_storage.c
 *
 * 动作库存储实现。
 * 模块职责：管理动作文件的落盘、读取、列表扫描以及当前动作名称状态。
 */

#include "motion_storage.h"

#include <ctype.h>
#include <dirent.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "esp_log.h"
#include "esp_spiffs.h"
#include "freertos/FreeRTOS.h"
#include "freertos/semphr.h"

#include "common.h"
#include "motion_json.h"

#define MOTION_STORAGE_BASE_PATH "/spiffs"
#define MOTION_STORAGE_FILE_EXT ".json"
#define MOTION_STORAGE_LEGACY_FILE_EXT ".mot"
#define MOTION_STORAGE_MAX_JSON_BYTES (512U * 1024U)
#define MOTION_STORAGE_METADATA_SCAN_BYTES 4096U

typedef motion_json_doc_t parsed_motion_doc_t;

static const char *TAG = "MOTION_STORAGE";
static SemaphoreHandle_t s_motion_storage_mutex = NULL;
static bool s_motion_storage_ready = false;
static volatile bool s_motion_storage_busy = false;
static char s_current_motion_name[MOTION_STORAGE_NAME_MAX_LEN] = "No motion";
static int16_t s_parsed_positions[FULL_MOTION_FRAMES][FULL_MOTION_SERVO_COUNT];
static uint16_t s_parsed_dts[FULL_MOTION_FRAMES];

static esp_err_t write_motion_json_file_locked(const char *motion_name,
                                               const parsed_motion_doc_t *doc);

// 在指定超时内获取动作库存储锁，避免并发读写破坏文件内容。
static bool lock_motion_storage(TickType_t timeout_ticks)
{
    return s_motion_storage_mutex != NULL &&
           xSemaphoreTake(s_motion_storage_mutex, timeout_ticks) == pdTRUE;
}

// 释放动作库存储锁，与加锁函数成对使用。
static void unlock_motion_storage(void)
{
    if (s_motion_storage_mutex != NULL) {
        xSemaphoreGive(s_motion_storage_mutex);
    }
}

static bool has_file_extension(const char *filename, const char *extension)
{
    if (filename == NULL || extension == NULL) {
        return false;
    }

    const size_t filename_len = strlen(filename);
    const size_t ext_len = strlen(extension);

    return filename_len > ext_len &&
           strcmp(filename + filename_len - ext_len, extension) == 0;
}

static bool has_motion_file_extension(const char *filename)
{
    return has_file_extension(filename, MOTION_STORAGE_FILE_EXT);
}

static bool has_legacy_motion_file_extension(const char *filename)
{
    return has_file_extension(filename, MOTION_STORAGE_LEGACY_FILE_EXT);
}

static void extract_motion_name(const char *filename, char *name_buf, size_t name_buf_len)
{
    if (name_buf == NULL || name_buf_len == 0) {
        return;
    }

    name_buf[0] = '\0';
    if (filename == NULL) {
        return;
    }

    const char *dot = strrchr(filename, '.');
    const size_t copy_len = (dot != NULL) ? (size_t)(dot - filename) : strlen(filename);
    snprintf(name_buf, name_buf_len, "%.*s", (int)copy_len, filename);
}

static void build_motion_path(const char *motion_name, char *path_buf, size_t path_buf_len)
{
    snprintf(path_buf, path_buf_len, "%s/%s%s",
             MOTION_STORAGE_BASE_PATH,
             motion_name,
             MOTION_STORAGE_FILE_EXT);
}

static void build_motion_path_with_ext(const char *motion_name,
                                       const char *extension,
                                       char *path_buf,
                                       size_t path_buf_len)
{
    snprintf(path_buf, path_buf_len, "%s/%s%s",
             MOTION_STORAGE_BASE_PATH,
             motion_name,
             extension);
}

static void build_motion_aux_path(const char *motion_name,
                                  const char *suffix,
                                  char *path_buf,
                                  size_t path_buf_len)
{
    snprintf(path_buf, path_buf_len, "%s/%s%s%s",
             MOTION_STORAGE_BASE_PATH,
             motion_name,
             MOTION_STORAGE_FILE_EXT,
             suffix != NULL ? suffix : "");
}

static bool is_valid_motion_name_internal(const char *motion_name)
{
    if (motion_name == NULL || motion_name[0] == '\0') {
        return false;
    }

    const size_t length = strlen(motion_name);
    if (length >= MOTION_STORAGE_NAME_MAX_LEN) {
        return false;
    }

    for (size_t i = 0; i < length; ++i) {
        const unsigned char ch = (unsigned char)motion_name[i];
        if (!(isalnum(ch) || ch == '_' || ch == '-')) {
            return false;
        }
    }

    return true;
}

static bool motion_file_exists_locked(const char *motion_name)
{
    if (!is_valid_motion_name_internal(motion_name)) {
        return false;
    }

    char path[64];
    build_motion_path(motion_name, path, sizeof(path));

    FILE *file = fopen(path, "rb");
    if (file == NULL) {
        return false;
    }

    fclose(file);
    return true;
}

static int compare_motion_info(const void *lhs, const void *rhs)
{
    const stored_motion_info_t *left = (const stored_motion_info_t *)lhs;
    const stored_motion_info_t *right = (const stored_motion_info_t *)rhs;
    return strcmp(left->name, right->name);
}

static void parsed_motion_doc_reset(parsed_motion_doc_t *doc)
{
    motion_json_doc_reset(doc);
}

static bool parsed_motion_doc_alloc(parsed_motion_doc_t *doc, const char *motion_name)
{
    if (doc == NULL) {
        return false;
    }

    memset(s_parsed_positions, 0, sizeof(s_parsed_positions));
    memset(s_parsed_dts, 0, sizeof(s_parsed_dts));
    return motion_json_doc_init(doc,
                                motion_name,
                                s_parsed_positions,
                                s_parsed_dts) == ESP_OK;
}

static esp_err_t write_recorded_full_motion_json_file_locked(const char *motion_name,
                                                             uint32_t *saved_checksum)
{
    if (motion_name == NULL || motion_name[0] == '\0' ||
        !has_recorded_motion_full || recorded_frame_count_full == 0) {
        return ESP_ERR_INVALID_ARG;
    }

    parsed_motion_doc_t doc = {0};
    const esp_err_t init_err = motion_json_doc_init(&doc,
                                                    motion_name,
                                                    recorded_motion_full,
                                                    recorded_motion_full_dt_ms);
    if (init_err != ESP_OK) {
        return init_err;
    }

    doc.frame_count = recorded_frame_count_full;
    motion_json_refresh_doc_derived_fields(&doc);

    const esp_err_t err = write_motion_json_file_locked(motion_name, &doc);
    if (err == ESP_OK && saved_checksum != NULL) {
        *saved_checksum = doc.payload_checksum;
    }

    return err;
}

static void apply_doc_to_recorded_motion(const parsed_motion_doc_t *doc)
{
    if (doc == NULL || doc->frame_count == 0) {
        return;
    }

    clear_recorded_full_motion();
    memcpy(recorded_motion_full,
           doc->positions,
           (size_t)doc->frame_count * sizeof(recorded_motion_full[0]));
    memcpy(recorded_motion_full_dt_ms,
           doc->dts,
           (size_t)doc->frame_count * sizeof(recorded_motion_full_dt_ms[0]));
    recorded_frame_count_full = doc->frame_count;
    has_recorded_motion_full = true;
    replay_frame_index_full = 0;
    dropped_frame_count_full = 0;
    motion_storage_set_current_motion_name(doc->name);
}

static esp_err_t write_motion_json_file_locked(const char *motion_name,
                                               const parsed_motion_doc_t *doc)
{
    if (motion_name == NULL || motion_name[0] == '\0' ||
        doc == NULL || doc->frame_count == 0) {
        return ESP_ERR_INVALID_ARG;
    }

    parsed_motion_doc_t doc_copy = *doc;
    snprintf(doc_copy.name, sizeof(doc_copy.name), "%s", motion_name);
    motion_json_refresh_doc_derived_fields(&doc_copy);

    char *json_text = NULL;
    esp_err_t err = motion_json_serialize_doc(&doc_copy, &json_text);
    if (err != ESP_OK) {
        return err;
    }

    char path[64];
    char temp_path[72];
    char backup_path[72];
    const bool had_existing_file = motion_file_exists_locked(motion_name);

    build_motion_path(motion_name, path, sizeof(path));
    build_motion_aux_path(motion_name, "~t", temp_path, sizeof(temp_path));
    build_motion_aux_path(motion_name, "~b", backup_path, sizeof(backup_path));

    remove(temp_path);

    FILE *file = fopen(temp_path, "wb");
    if (file == NULL) {
        free(json_text);
        return ESP_FAIL;
    }

    const size_t json_len = strlen(json_text);
    bool write_ok = fwrite(json_text, 1, json_len, file) == json_len;
    if (write_ok && fflush(file) != 0) {
        write_ok = false;
    }
    if (fclose(file) != 0) {
        write_ok = false;
    }
    free(json_text);

    if (!write_ok) {
        remove(temp_path);
        return ESP_FAIL;
    }

    if (had_existing_file) {
        remove(backup_path);
        if (rename(path, backup_path) != 0) {
            remove(temp_path);
            return ESP_FAIL;
        }
    }

    if (rename(temp_path, path) != 0) {
        remove(temp_path);
        if (had_existing_file) {
            rename(backup_path, path);
        }
        return ESP_FAIL;
    }

    if (had_existing_file) {
        remove(backup_path);
    }

    return ESP_OK;
}

static esp_err_t read_file_into_buffer_locked(const char *path,
                                              char **text_out,
                                              size_t *text_len_out)
{
    if (path == NULL || text_out == NULL) {
        return ESP_ERR_INVALID_ARG;
    }

    *text_out = NULL;
    if (text_len_out != NULL) {
        *text_len_out = 0;
    }

    FILE *file = fopen(path, "rb");
    if (file == NULL) {
        return ESP_ERR_NOT_FOUND;
    }

    if (fseek(file, 0, SEEK_END) != 0) {
        fclose(file);
        return ESP_FAIL;
    }

    const long file_size = ftell(file);
    if (file_size < 0 || (unsigned long)file_size > MOTION_STORAGE_MAX_JSON_BYTES) {
        fclose(file);
        return ESP_ERR_INVALID_SIZE;
    }

    if (fseek(file, 0, SEEK_SET) != 0) {
        fclose(file);
        return ESP_FAIL;
    }

    char *buffer = malloc((size_t)file_size + 1U);
    if (buffer == NULL) {
        fclose(file);
        return ESP_ERR_NO_MEM;
    }

    const size_t bytes_to_read = (size_t)file_size;
    const size_t bytes_read = fread(buffer, 1, bytes_to_read, file);
    fclose(file);

    if (bytes_read != bytes_to_read) {
        free(buffer);
        return ESP_FAIL;
    }

    buffer[bytes_read] = '\0';
    *text_out = buffer;
    if (text_len_out != NULL) {
        *text_len_out = bytes_read;
    }

    return ESP_OK;
}

static esp_err_t load_motion_json_file_into_doc_locked(const char *path,
                                                       const char *motion_name,
                                                       parsed_motion_doc_t *doc)
{
    if (path == NULL || motion_name == NULL || doc == NULL) {
        return ESP_ERR_INVALID_ARG;
    }

    if (!parsed_motion_doc_alloc(doc, motion_name)) {
        return ESP_ERR_NO_MEM;
    }

    char *json_text = NULL;
    esp_err_t err = read_file_into_buffer_locked(path, &json_text, NULL);
    if (err != ESP_OK) {
        parsed_motion_doc_reset(doc);
        return err;
    }

    err = motion_json_parse_document(json_text, motion_name, doc);
    free(json_text);
    if (err != ESP_OK) {
        parsed_motion_doc_reset(doc);
    }

    return err;
}

static esp_err_t read_motion_metadata_locked(const char *path, stored_motion_info_t *entry)
{
    if (path == NULL || entry == NULL) {
        return ESP_ERR_INVALID_ARG;
    }

    FILE *file = fopen(path, "rb");
    if (file == NULL) {
        return ESP_ERR_NOT_FOUND;
    }

    char *prefix = malloc(MOTION_STORAGE_METADATA_SCAN_BYTES + 1U);
    if (prefix == NULL) {
        fclose(file);
        return ESP_ERR_NO_MEM;
    }

    size_t total_read = 0;
    bool found_frames = false;

    while (total_read < MOTION_STORAGE_METADATA_SCAN_BYTES) {
        const size_t remaining = MOTION_STORAGE_METADATA_SCAN_BYTES - total_read;
        const size_t bytes_read = fread(prefix + total_read, 1, remaining, file);
        total_read += bytes_read;
        prefix[total_read] = '\0';

        char *frames_field = strstr(prefix, "\"frames\"");
        if (frames_field != NULL) {
            *frames_field = '\0';
            found_frames = true;
            break;
        }

        if (bytes_read == 0) {
            break;
        }
    }

    fclose(file);

    if (!found_frames) {
        free(prefix);
        return ESP_ERR_INVALID_RESPONSE;
    }

    motion_json_metadata_t metadata = {0};
    const esp_err_t err = motion_json_extract_metadata(prefix, &metadata);
    free(prefix);
    if (err != ESP_OK) {
        memset(entry, 0, sizeof(*entry));
        return err;
    }

    memset(entry, 0, sizeof(*entry));
    snprintf(entry->name, sizeof(entry->name), "%s", metadata.name);
    entry->frame_count = metadata.frame_count;
    entry->total_duration_ms = metadata.total_duration_ms;
    entry->is_current = strcmp(entry->name, s_current_motion_name) == 0;
    return ESP_OK;
}

static void cleanup_legacy_motion_files_locked(void)
{
    DIR *dir = opendir(MOTION_STORAGE_BASE_PATH);
    if (dir == NULL) {
        return;
    }

    struct dirent *entry = NULL;
    while ((entry = readdir(dir)) != NULL) {
        if (!has_legacy_motion_file_extension(entry->d_name)) {
            continue;
        }

        char legacy_name[MOTION_STORAGE_NAME_MAX_LEN];
        char legacy_path[64];

        extract_motion_name(entry->d_name, legacy_name, sizeof(legacy_name));
        build_motion_path_with_ext(legacy_name,
                                   MOTION_STORAGE_LEGACY_FILE_EXT,
                                   legacy_path,
                                   sizeof(legacy_path));
        if (remove(legacy_path) == 0) {
            ESP_LOGI(TAG, "Removed legacy motion file: %s", entry->d_name);
        } else {
            ESP_LOGW(TAG, "Failed to remove legacy motion file: %s", entry->d_name);
        }
    }

    closedir(dir);
}

static uint16_t find_next_motion_index_locked(void)
{
    uint16_t max_index = 0;
    DIR *dir = opendir(MOTION_STORAGE_BASE_PATH);

    if (dir == NULL) {
        return 1;
    }

    struct dirent *entry = NULL;
    while ((entry = readdir(dir)) != NULL) {
        if (!has_motion_file_extension(entry->d_name)) {
            continue;
        }

        unsigned int index = 0;
        if (sscanf(entry->d_name, "motion_%u.json", &index) == 1 && index > max_index) {
            max_index = (uint16_t)index;
        }
    }

    closedir(dir);
    return (uint16_t)(max_index + 1);
}

// 初始化 SPIFFS、互斥锁以及动作库当前状态。
esp_err_t motion_storage_init(void)
{
    if (s_motion_storage_mutex == NULL) {
        s_motion_storage_mutex = xSemaphoreCreateMutex();
        if (s_motion_storage_mutex == NULL) {
            return ESP_ERR_NO_MEM;
        }
    }

    esp_vfs_spiffs_conf_t conf = {
        .base_path = MOTION_STORAGE_BASE_PATH,
        .partition_label = "storage",
        .max_files = 8,
        .format_if_mount_failed = true,
    };

    esp_err_t err = esp_vfs_spiffs_register(&conf);
    if (err != ESP_OK) {
        ESP_LOGE(TAG, "Failed to mount storage partition: %s", esp_err_to_name(err));
        s_motion_storage_ready = false;
        return err;
    }

    size_t total = 0;
    size_t used = 0;
    err = esp_spiffs_info(conf.partition_label, &total, &used);
    if (err == ESP_OK) {
        ESP_LOGI(TAG, "Storage ready: total=%u bytes used=%u bytes",
                 (unsigned)total,
                 (unsigned)used);
    }

    if (lock_motion_storage(pdMS_TO_TICKS(1000))) {
        cleanup_legacy_motion_files_locked();
        unlock_motion_storage();
    }

    s_motion_storage_ready = true;
    return ESP_OK;
}

// 返回动作库存储是否已初始化成功。
bool motion_storage_is_ready(void)
{
    return s_motion_storage_ready;
}

// 返回动作库当前是否处于耗时读写流程中。
bool motion_storage_is_busy(void)
{
    return s_motion_storage_busy;
}

// 获取当前被网页或业务逻辑选中的动作名称。
const char *motion_storage_get_current_motion_name(void)
{
    return s_current_motion_name;
}

// 设置当前动作名称；空值会被标准化成默认占位名称。
void motion_storage_set_current_motion_name(const char *motion_name)
{
    const char *source_name = motion_name;

    if (source_name == NULL || source_name[0] == '\0') {
        source_name = "No motion";
    }

    snprintf(s_current_motion_name, sizeof(s_current_motion_name), "%s", source_name);
}

// 扫描存储目录并返回动作摘要列表。
size_t motion_storage_list(stored_motion_info_t *entries, size_t max_entries)
{
    if (!s_motion_storage_ready || entries == NULL || max_entries == 0) {
        return 0;
    }

    if (!lock_motion_storage(pdMS_TO_TICKS(1000))) {
        return 0;
    }

    size_t count = 0;
    DIR *dir = opendir(MOTION_STORAGE_BASE_PATH);
    if (dir == NULL) {
        unlock_motion_storage();
        return 0;
    }

    struct dirent *entry = NULL;
    while ((entry = readdir(dir)) != NULL && count < max_entries) {
        if (!has_motion_file_extension(entry->d_name)) {
            continue;
        }

        char motion_name[MOTION_STORAGE_NAME_MAX_LEN];
        char path[64];
        extract_motion_name(entry->d_name, motion_name, sizeof(motion_name));
        build_motion_path(motion_name, path, sizeof(path));

        if (read_motion_metadata_locked(path, &entries[count]) == ESP_OK) {
            ++count;
        }
    }

    closedir(dir);
    qsort(entries, count, sizeof(entries[0]), compare_motion_info);
    unlock_motion_storage();
    return count;
}

// 将当前整套动作缓存保存成新的动作文件。
esp_err_t motion_storage_save_current_full_motion(char *saved_name,
                                                  size_t saved_name_len,
                                                  uint32_t *saved_checksum)
{
    if (!s_motion_storage_ready) {
        return ESP_ERR_INVALID_STATE;
    }

    if (!has_recorded_motion_full || recorded_frame_count_full == 0) {
        return ESP_ERR_NOT_FOUND;
    }

    if (!lock_motion_storage(pdMS_TO_TICKS(2000))) {
        return ESP_ERR_TIMEOUT;
    }

    s_motion_storage_busy = true;

    const uint16_t next_index = find_next_motion_index_locked();
    char motion_name[MOTION_STORAGE_NAME_MAX_LEN];
    uint32_t payload_checksum = 0;
    esp_err_t err = ESP_OK;

    snprintf(motion_name, sizeof(motion_name), "motion_%03u", (unsigned)next_index);

    err = write_recorded_full_motion_json_file_locked(motion_name, &payload_checksum);
    if (err != ESP_OK) {
        goto cleanup;
    }

    motion_storage_set_current_motion_name(motion_name);
    if (saved_name != NULL && saved_name_len > 0) {
        snprintf(saved_name, saved_name_len, "%s", motion_name);
    }
    if (saved_checksum != NULL) {
        *saved_checksum = payload_checksum;
    }

cleanup:
    s_motion_storage_busy = false;
    unlock_motion_storage();
    return err;
}

// 读取指定动作文件并恢复到当前整套动作缓存。
esp_err_t motion_storage_load_full_motion(const char *motion_name, uint32_t *loaded_checksum)
{
    if (!s_motion_storage_ready || motion_name == NULL || motion_name[0] == '\0') {
        return ESP_ERR_INVALID_ARG;
    }

    if (!lock_motion_storage(pdMS_TO_TICKS(2000))) {
        return ESP_ERR_TIMEOUT;
    }

    s_motion_storage_busy = true;

    char path[64];
    parsed_motion_doc_t doc = {0};
    esp_err_t err = ESP_OK;

    build_motion_path(motion_name, path, sizeof(path));

    err = load_motion_json_file_into_doc_locked(path, motion_name, &doc);
    if (err != ESP_OK) {
        goto cleanup;
    }

    apply_doc_to_recorded_motion(&doc);
    if (loaded_checksum != NULL) {
        *loaded_checksum = doc.payload_checksum;
    }

cleanup:
    parsed_motion_doc_reset(&doc);
    s_motion_storage_busy = false;
    unlock_motion_storage();
    return err;
}

// 读取指定动作文件对应的原始 JSON 文本。
esp_err_t motion_storage_read_json_full_motion(const char *motion_name,
                                               char **json_text,
                                               size_t *json_len)
{
    if (!s_motion_storage_ready || motion_name == NULL || motion_name[0] == '\0' ||
        json_text == NULL) {
        return ESP_ERR_INVALID_ARG;
    }

    if (!lock_motion_storage(pdMS_TO_TICKS(2000))) {
        return ESP_ERR_TIMEOUT;
    }

    s_motion_storage_busy = true;

    char path[64];
    build_motion_path(motion_name, path, sizeof(path));
    const esp_err_t err = read_file_into_buffer_locked(path, json_text, json_len);

    s_motion_storage_busy = false;
    unlock_motion_storage();
    return err;
}

// 使用新的 JSON 文本覆盖指定动作文件，并同步更新当前动作名。
esp_err_t motion_storage_update_json_full_motion(const char *motion_name,
                                                 const char *json_text,
                                                 uint32_t *saved_checksum)
{
    if (!s_motion_storage_ready ||
        motion_name == NULL || motion_name[0] == '\0' ||
        json_text == NULL || json_text[0] == '\0') {
        return ESP_ERR_INVALID_ARG;
    }

    if (strlen(json_text) > MOTION_STORAGE_MAX_JSON_BYTES) {
        return ESP_ERR_INVALID_SIZE;
    }

    if (!lock_motion_storage(pdMS_TO_TICKS(2000))) {
        return ESP_ERR_TIMEOUT;
    }

    s_motion_storage_busy = true;

    parsed_motion_doc_t doc = {0};
    if (!parsed_motion_doc_alloc(&doc, motion_name)) {
        s_motion_storage_busy = false;
        unlock_motion_storage();
        return ESP_ERR_NO_MEM;
    }

    esp_err_t err = motion_json_parse_document(json_text, motion_name, &doc);
    if (err != ESP_OK) {
        goto cleanup;
    }

    err = write_motion_json_file_locked(motion_name, &doc);
    if (err == ESP_OK && saved_checksum != NULL) {
        *saved_checksum = doc.payload_checksum;
    }
    if (err == ESP_OK) {
        motion_storage_set_current_motion_name(motion_name);
    }

cleanup:
    parsed_motion_doc_reset(&doc);
    s_motion_storage_busy = false;
    unlock_motion_storage();
    return err;
}

// 修改指定动作文件名称，同时保留动作内容和校验信息。
esp_err_t motion_storage_rename_full_motion(const char *motion_name,
                                            const char *new_motion_name,
                                            uint32_t *saved_checksum)
{
    if (!s_motion_storage_ready) {
        return ESP_ERR_INVALID_STATE;
    }

    if (!is_valid_motion_name_internal(motion_name) ||
        !is_valid_motion_name_internal(new_motion_name)) {
        return ESP_ERR_INVALID_ARG;
    }

    if (strcmp(motion_name, new_motion_name) == 0) {
        if (saved_checksum != NULL) {
            *saved_checksum = 0;
        }
        return ESP_OK;
    }

    if (!lock_motion_storage(pdMS_TO_TICKS(2000))) {
        return ESP_ERR_TIMEOUT;
    }

    s_motion_storage_busy = true;

    char old_path[64];
    char new_path[64];
    parsed_motion_doc_t doc = {0};
    esp_err_t err = ESP_OK;

    build_motion_path(motion_name, old_path, sizeof(old_path));
    build_motion_path(new_motion_name, new_path, sizeof(new_path));

    if (!motion_file_exists_locked(motion_name)) {
        err = ESP_ERR_NOT_FOUND;
        goto cleanup;
    }

    if (motion_file_exists_locked(new_motion_name)) {
        err = ESP_ERR_INVALID_STATE;
        goto cleanup;
    }

    err = load_motion_json_file_into_doc_locked(old_path, motion_name, &doc);
    if (err != ESP_OK) {
        goto cleanup;
    }

    snprintf(doc.name, sizeof(doc.name), "%s", new_motion_name);
    err = write_motion_json_file_locked(new_motion_name, &doc);
    if (err != ESP_OK) {
        goto cleanup;
    }

    if (remove(old_path) != 0) {
        remove(new_path);
        err = ESP_FAIL;
        goto cleanup;
    }

    if (strcmp(motion_name, s_current_motion_name) == 0) {
        motion_storage_set_current_motion_name(new_motion_name);
    }

    if (saved_checksum != NULL) {
        *saved_checksum = doc.payload_checksum;
    }

cleanup:
    parsed_motion_doc_reset(&doc);
    s_motion_storage_busy = false;
    unlock_motion_storage();
    return err;
}

// 删除单个动作文件，并在必要时清空当前动作名称。
esp_err_t motion_storage_delete_full_motion(const char *motion_name)
{
    if (!s_motion_storage_ready) {
        return ESP_ERR_INVALID_STATE;
    }

    if (motion_name == NULL || motion_name[0] == '\0') {
        return ESP_ERR_INVALID_ARG;
    }

    if (!lock_motion_storage(pdMS_TO_TICKS(2000))) {
        return ESP_ERR_TIMEOUT;
    }

    s_motion_storage_busy = true;

    char path[64];
    build_motion_path(motion_name, path, sizeof(path));

    FILE *file = fopen(path, "rb");
    if (file == NULL) {
        s_motion_storage_busy = false;
        unlock_motion_storage();
        return ESP_ERR_NOT_FOUND;
    }
    fclose(file);

    if (remove(path) != 0) {
        s_motion_storage_busy = false;
        unlock_motion_storage();
        return ESP_FAIL;
    }

    if (strcmp(motion_name, s_current_motion_name) == 0) {
        motion_storage_set_current_motion_name(NULL);
    }

    s_motion_storage_busy = false;
    unlock_motion_storage();
    return ESP_OK;
}

// 删除全部动作文件，并统计实际删除成功的数量。
esp_err_t motion_storage_delete_all_full_motion(size_t *deleted_count)
{
    if (!s_motion_storage_ready) {
        return ESP_ERR_INVALID_STATE;
    }

    if (!lock_motion_storage(pdMS_TO_TICKS(2000))) {
        return ESP_ERR_TIMEOUT;
    }

    s_motion_storage_busy = true;

    size_t local_deleted_count = 0;
    bool had_any_motion = false;
    bool current_deleted = false;
    bool delete_failed = false;
    DIR *dir = opendir(MOTION_STORAGE_BASE_PATH);

    if (dir == NULL) {
        s_motion_storage_busy = false;
        unlock_motion_storage();
        return ESP_FAIL;
    }

    struct dirent *entry = NULL;
    while ((entry = readdir(dir)) != NULL) {
        if (!has_motion_file_extension(entry->d_name) &&
            !has_legacy_motion_file_extension(entry->d_name)) {
            continue;
        }

        had_any_motion = true;

        char motion_name[MOTION_STORAGE_NAME_MAX_LEN];
        char path[64];
        const char *extension = has_motion_file_extension(entry->d_name) ?
            MOTION_STORAGE_FILE_EXT :
            MOTION_STORAGE_LEGACY_FILE_EXT;

        extract_motion_name(entry->d_name, motion_name, sizeof(motion_name));
        build_motion_path_with_ext(motion_name, extension, path, sizeof(path));

        if (remove(path) != 0) {
            delete_failed = true;
            continue;
        }

        local_deleted_count++;
        if (strcmp(motion_name, s_current_motion_name) == 0) {
            current_deleted = true;
        }
    }

    closedir(dir);

    if (deleted_count != NULL) {
        *deleted_count = local_deleted_count;
    }

    if (current_deleted || (had_any_motion && !delete_failed)) {
        motion_storage_set_current_motion_name(NULL);
    }

    s_motion_storage_busy = false;
    unlock_motion_storage();
    return delete_failed ? ESP_FAIL : ESP_OK;
}
