/*
 * servo_motion.h
 *
 * 舵机演示动作模块。
 * 模块职责：声明单舵机往返和双舵机联动演示所需的状态与入口。
 * 这里定义两类动作：
 * 1. 单舵机往返演示，用于验证单个关节是否能在限位内正常动作。
 * 2. 双舵机同步旋转演示，用于验证多舵机同步控制和状态机切换逻辑。
 */

#ifndef SERVO_MOTION_H
#define SERVO_MOTION_H

#include <stdint.h>
#include <stdbool.h>

// 单舵机往返演示的阶段状态。
// TO_MAX 和 TO_MIN 表示当前正在朝对应方向运动。
typedef enum {
    SERVO_MOTION_IDLE = 0,
    SERVO_MOTION_TO_MAX,
    SERVO_MOTION_TO_MIN,
} servo_motion_state_t;

// 双舵机联动演示的阶段状态。
// 设计为“向左 -> 向右 -> 回中 -> 结束”的有限状态机。
typedef enum {
    DUAL_ROTATE_IDLE = 0,
    DUAL_ROTATE_TO_LEFT,
    DUAL_ROTATE_TO_RIGHT,
    DUAL_ROTATE_TO_CENTER,
} dual_rotate_state_t;

// 演示动作里使用的目标位置。
// 这些值仍然会经过 limit_servo_position() 二次裁剪，避免越界。
#define SERVO_CENTER_POS 2048
#define SERVO_LEFT_90_POS 1024
#define SERVO_RIGHT_90_POS 3072

// 下列状态由 servo_motion.c 定义，main.c 周期性调用更新函数时会读取/推进。
extern volatile servo_motion_state_t g_servo1_motion_state;
extern volatile servo_motion_state_t g_servo2_motion_state;
extern volatile uint32_t g_servo1_motion_start_time;
extern volatile uint32_t g_servo2_motion_start_time;
extern volatile uint8_t g_servo1_cycle_count;
extern volatile uint8_t g_servo2_cycle_count;
extern volatile dual_rotate_state_t g_dual_rotate_state;
extern volatile uint32_t g_dual_rotate_start_time;

// 演示动作时间参数。
// 单舵机动作每次走到目标位置后等待 2 秒，再切换方向。
// 双舵机联动动作每个阶段保持 1.5 秒。
#define SERVO_MOTION_DURATION_MS 2000
#define SERVO_MOTION_MAX_CYCLES 2
#define DUAL_ROTATE_DURATION_MS 1500

// 启动 1 号舵机的往返演示动作。
void start_servo1_demo(void);

// 启动 2 号舵机的往返演示动作。
void start_servo2_demo(void);

// 在主循环中推进单舵机演示状态机。
// 这个函数不主动创建任务，需要被周期性调用。
void update_servo_motion_state(void);

// 启动双舵机联动旋转演示。
// 启动时立即下发第一段“向左转”的同步写命令。
void start_dual_servo_rotate(void);

// 在主循环中推进双舵机联动状态机。
// 到达每个阶段的保持时间后，会自动切换到下一个目标姿态。
void update_dual_rotate_state(void);

#endif // SERVO_MOTION_H
