/*
 * command_bus.h
 *
 * 命令总线对外接口。
 * 模块职责：在网页线程和主控制任务之间传递串行化命令，避免直接跨线程修改控制流程。
 */

#ifndef COMMAND_BUS_H
#define COMMAND_BUS_H

#include <stdbool.h>
#include "esp_err.h"
#include "freertos/FreeRTOS.h"
#include "common.h"

// 初始化命令总线使用的 FreeRTOS 队列。
esp_err_t command_bus_init(void);
// 向命令总线投递一条待执行命令。
esp_err_t command_bus_send(servo_cmd_t cmd);
// 从命令总线取出一条命令，可指定阻塞等待超时。
bool command_bus_receive(servo_cmd_t *cmd, TickType_t timeout_ticks);
// 查询命令总线里是否仍有待处理命令。
bool command_bus_has_pending(void);

#endif // COMMAND_BUS_H
