/*
 * servo_control.c
 * 舵机基础控制实现。
 * 模块职责：集中处理舵机扭矩控制、位置限位和同步读写操作。
 * 包括限位保护、扭矩管理、姿态恢复、单舵机/多舵机位置下发以及批量角度读取。
 */

#include "servo_control.h"
#include "uart_servo.h"
#include "common.h"
#include "servo_protocol.h"
#include "esp_log.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include <string.h>
#include <stdio.h>

#define work g_sys.ui.work
#define message0 g_sys.ui.message0
#define message1 g_sys.ui.message1
#define g_read_angle_mode g_sys.ctrl.read_angle_mode
#define g_record_leg1_mode g_sys.ctrl.record_leg1_mode
#define g_record_leg2_mode g_sys.ctrl.record_leg2_mode
#define g_record_leg3_mode g_sys.ctrl.record_leg3_mode
#define g_record_leg4_mode g_sys.ctrl.record_leg4_mode
#define g_record_full_mode g_sys.ctrl.record_full_mode

static const char *TAG = "SERVO_CTRL";
// 需要统一控制扭矩时使用的完整舵机 ID 列表。
// 单腿录入不会使用这份全量列表，而是只操作当前腿自己的 5 个舵机。
static const uint8_t s_all_servo_ids[] = {
    1, 2, 3, 4, 5,
    6, 7, 8, 9, 10,
    11, 12, 13, 14, 15,
    16, 17, 18, 19, 20
};

// 默认姿态中实际会下发位置的舵机 ID 列表。
// 恢复默认站姿时需要参与联动下发的舵机 ID 列表。
static const uint8_t s_restore_pose_ids[] = {
    1, 2, 3, 4, 5,
    6, 7, 8, 9, 10,
    11, 12, 13, 14, 15,
    16, 17, 18, 19, 20
};

// 默认姿态目标位置表，与 `s_restore_pose_ids` 一一对应。
// 与恢复站姿 ID 列表一一对应的默认目标位置。
static const int16_t s_restore_pose_positions[] = {
    2032, 1012, 2378, 1840, 1535,
    2260, 1977, 2208, 1867, 2445,
    1851, 1712, 1960, 1968, 1542,
    2197, 2836, 1977, 1910, 2663
};

typedef struct {
    int16_t min_pos;
    int16_t max_pos;
} servo_position_range_t;

static const servo_position_range_t s_servo_position_ranges[] = {
    {SERVO_LF1_POS_MIN, SERVO_LF1_POS_MAX},
    {SERVO_LF2_POS_MIN, SERVO_LF2_POS_MAX},
    {SERVO_LF3_POS_MIN, SERVO_LF3_POS_MAX},
    {SERVO_LF4_POS_MIN, SERVO_LF4_POS_MAX},
    {SERVO_5_POS_MIN, SERVO_5_POS_MAX},
    {SERVO_6_POS_MIN, SERVO_6_POS_MAX},
    {SERVO_7_POS_MIN, SERVO_7_POS_MAX},
    {SERVO_8_POS_MIN, SERVO_8_POS_MAX},
    {SERVO_9_POS_MIN, SERVO_9_POS_MAX},
    {SERVO_10_POS_MIN, SERVO_10_POS_MAX},
    {SERVO_11_POS_MIN, SERVO_11_POS_MAX},
    {SERVO_12_POS_MIN, SERVO_12_POS_MAX},
    {SERVO_13_POS_MIN, SERVO_13_POS_MAX},
    {SERVO_14_POS_MIN, SERVO_14_POS_MAX},
    {SERVO_15_POS_MIN, SERVO_15_POS_MAX},
    {SERVO_16_POS_MIN, SERVO_16_POS_MAX},
    {SERVO_17_POS_MIN, SERVO_17_POS_MAX},
    {SERVO_18_POS_MIN, SERVO_18_POS_MAX},
    {SERVO_19_POS_MIN, SERVO_19_POS_MAX},
    {SERVO_20_POS_MIN, SERVO_20_POS_MAX},
};

enum {
    RESTORE_POSE_SERVO_COUNT = sizeof(s_restore_pose_ids) / sizeof(s_restore_pose_ids[0]),
    SERVO_RANGE_COUNT = sizeof(s_servo_position_ranges) / sizeof(s_servo_position_ranges[0]),
};

// 对一组指定舵机统一开关扭矩，供录入辅助逻辑复用。
// 逐个给指定 ID 列表写入扭矩开关，并统计成功数量，便于上层生成更具体的提示信息。
static uint8_t set_torque_state_for_ids(const uint8_t *id_list, uint8_t count, uint8_t enable, const char *log_context)
{
    uint8_t success_count = 0;

    for (uint8_t i = 0; i < count; ++i) {
        int ret = writeByte(id_list[i], SMS_STS_TORQUE_ENABLE, enable);
        if (ret) {
            success_count++;
        } else {
            ESP_LOGW(TAG, "%s: ID=%d failed, err=%d",
                     log_context, id_list[i], getLastError());
        }
    }

    return success_count;
}

// 根据腿编号返回对应的舵机 ID 列表与数量。
// 根据腿号返回该腿对应的 5 个舵机 ID，给单腿锁定、录制和回放共用。
// 返回指定腿对应的 5 个舵机 ID。
// 单腿录入和单腿回放都只使用当前腿本身的舵机，不再额外拼上其他腿的关节。
static bool get_leg_servo_ids(uint8_t leg_num, uint8_t *id_list, uint8_t *count)
{
    static const uint8_t leg1_ids[] = LEG1_SERVO_IDS;
    static const uint8_t leg2_ids[] = LEG2_SERVO_IDS;
    static const uint8_t leg3_ids[] = LEG3_SERVO_IDS;
    static const uint8_t leg4_ids[] = LEG4_SERVO_IDS;

    const uint8_t *ids = NULL;

    switch (leg_num) {
        case 1:
            ids = leg1_ids;
            break;
        case 2:
            ids = leg2_ids;
            break;
        case 3:
            ids = leg3_ids;
            break;
        case 4:
            ids = leg4_ids;
            break;
        default:
            *count = 0;
            return false;
    }

    *count = LEG_SERVO_COUNT_PER_LEG;
    memcpy(id_list, ids, LEG_SERVO_COUNT_PER_LEG);
    return true;
}

// 返回指定腿对应的扭矩状态标志地址，便于统一更新。
// 返回某条腿当前扭矩状态标志的地址，方便切换逻辑直接读写。
static volatile bool *get_leg_torque_flag(uint8_t leg_num)
{
    switch (leg_num) {
        case 1:
            return &g_leg1_torque_enabled;
        case 2:
            return &g_leg2_torque_enabled;
        case 3:
            return &g_leg3_torque_enabled;
        case 4:
            return &g_leg4_torque_enabled;
        default:
            return NULL;
    }
}

// 统一处理单个舵机的位置写入，避免重复的限位、发包和报错逻辑。
// 单舵机设置的公共实现：先限位，再下发位置命令，最后同步刷新网页提示和日志。
static void set_single_servo_position(uint8_t servo_id,
                                      const char *work_text,
                                      const char *label_text,
                                      int16_t position)
{
    strcpy(work, work_text);
    position = limit_servo_position(servo_id, position);

    int ret = WritePosEx(servo_id, position, 2400, 50);
    if (ret) {
        snprintf(message0, sizeof(message0), "设置%s成功: %d", label_text, position);
    } else {
        snprintf(message0, sizeof(message0), "设置%s失败: %d, err=%d",
                 label_text, position, getLastError());
        ESP_LOGW(TAG, "设置%s失败: %d, err=%d", label_text, position, getLastError());
    }
}

// 构造一组完整的“恢复姿态”目标值，未覆盖的舵机使用回退值填充。
// 组装恢复站姿所需的位置数组，并对每个位置再次做限位保护。
void build_restore_default_pose_positions(int16_t *positions,
                                          int count,
                                          const int16_t *fallback_positions)
{
    if (positions == NULL || count <= 0) {
        return;
    }

    for (int i = 0; i < count; ++i) {
        int16_t fallback = 0;

        if (fallback_positions != NULL) {
            fallback = fallback_positions[i];
        } else if (i < FULL_MOTION_SERVO_COUNT) {
            fallback = servoPos_1to20[i];
        }

        positions[i] = limit_servo_position((uint8_t)(i + 1), fallback);
    }

    for (size_t i = 0; i < sizeof(s_restore_pose_ids) / sizeof(s_restore_pose_ids[0]); ++i) {
        const uint8_t servo_id = s_restore_pose_ids[i];

        if (servo_id >= 1 && servo_id <= count) {
            positions[servo_id - 1] = limit_servo_position(servo_id, s_restore_pose_positions[i]);
        }
    }
}

// 限位检查函数：根据舵机ID限制位置值在允许范围内
// 按舵机编号把目标位置限制在安全范围内，防止网页滑块或录制数据把舵机推到机械极限。
int16_t limit_servo_position(uint8_t servo_id, int16_t position)
{
    int16_t min_pos = 0;
    int16_t max_pos = 4095;

    if (servo_id >= 1 && servo_id <= SERVO_RANGE_COUNT) {
        const servo_position_range_t *range = &s_servo_position_ranges[servo_id - 1];
        min_pos = range->min_pos;
        max_pos = range->max_pos;
    }

    if (position < min_pos) {
        ESP_LOGW(TAG, "[限位检查] 舵机ID=%d 位置%d 低于最小值%d，限制为%d",
                 servo_id, position, min_pos, min_pos);
        return min_pos;
    }

    if (position > max_pos) {
        ESP_LOGW(TAG, "[限位检查] 舵机ID=%d 位置%d 超过最大值%d，限制为%d",
                 servo_id, position, max_pos, max_pos);
        return max_pos;
    }

    return position;
}

// 开启所有舵机扭矩，通常用于回放或恢复姿态前。
// 给全体舵机上扭矩，让当前姿态被主动保持。
void lock_on_all(void)
{
    strcpy(work, "开启扭矩控制");
    
    // 开启全部 20 个舵机的扭矩
    uint8_t success_count = set_torque_state_for_ids(
        s_all_servo_ids,
        sizeof(s_all_servo_ids) / sizeof(s_all_servo_ids[0]),
        1,
        "lock_on_all");
    
    g_leg1_torque_enabled = true;
    g_leg2_torque_enabled = true;
    g_leg3_torque_enabled = true;
    g_leg4_torque_enabled = true;
    
    snprintf(message0, sizeof(message0), "开启舵机扭矩：成功%d/20", success_count);
}

// 关闭所有舵机扭矩，便于手动示教或搬动机构。
// 关闭全体舵机扭矩，方便手动掰动或进入示教状态。
void lock_off_all(void)
{
    strcpy(work, "关闭扭矩控制");
    
    // 关闭全部 20 个舵机的扭矩
    set_torque_state_for_ids(
        s_all_servo_ids,
        sizeof(s_all_servo_ids) / sizeof(s_all_servo_ids[0]),
        0,
        "lock_off_all");

    g_leg1_torque_enabled = false;
    g_leg2_torque_enabled = false;
    g_leg3_torque_enabled = false;
    g_leg4_torque_enabled = false;

    snprintf(message0, sizeof(message0), "关闭舵机扭矩：ID 1-20");
}

// 开启指定腿的扭矩
// 只给指定腿重新上扭矩，常用于单腿录制结束后的恢复。
// 只给当前腿的 5 个舵机恢复扭矩。
void lock_on_leg(uint8_t leg_num)
{
    uint8_t id_list[LEG_SERVO_COUNT_PER_LEG];
    uint8_t count = 0;
    volatile bool *torque_enabled = get_leg_torque_flag(leg_num);

    if (torque_enabled == NULL || !get_leg_servo_ids(leg_num, id_list, &count)) {
        return;
    }

    snprintf(work, sizeof(work), "开启腿%u扭矩", (unsigned)leg_num);
    uint8_t success_count = set_torque_state_for_ids(id_list, count, 1, "lock_on_leg");
    *torque_enabled = true;

    snprintf(message0, sizeof(message0), "开启腿%d扭矩：成功%d/%d", leg_num, success_count, count);
}

// 关闭指定腿的扭矩
// 只关闭指定腿扭矩，让用户能单独拖动这条腿录制动作。
// 只给当前腿的 5 个舵机关闭扭矩，便于做单腿示教录入。
void lock_off_leg(uint8_t leg_num)
{
    uint8_t id_list[LEG_SERVO_COUNT_PER_LEG];
    uint8_t count = 0;
    volatile bool *torque_enabled = get_leg_torque_flag(leg_num);

    if (torque_enabled == NULL || !get_leg_servo_ids(leg_num, id_list, &count)) {
        return;
    }

    snprintf(work, sizeof(work), "关闭腿%u扭矩", (unsigned)leg_num);
    set_torque_state_for_ids(id_list, count, 0, "lock_off_leg");
    *torque_enabled = false;

    if (count > 0) {
        snprintf(message0, sizeof(message0), "关闭腿%d扭矩：ID %d-%d",
                 leg_num, id_list[0], id_list[count - 1]);
    } else {
        snprintf(message0, sizeof(message0), "关闭腿%d扭矩", leg_num);
    }
}

// 切换指定腿的扭矩状态
// 按当前状态在“上扭矩”和“关扭矩”之间切换指定腿。
void lock_toggle_leg(uint8_t leg_num)
{
    volatile bool *torque_state = get_leg_torque_flag(leg_num);

    if (torque_state == NULL) {
        return;
    }

    if (*torque_state) {
        lock_off_leg(leg_num);
    } else {
        lock_on_leg(leg_num);
    }
}

// 把机器人恢复到一组预设的默认姿态，作为安全起始点。
// 把参与联动的舵机拉回默认站姿，是系统回到已知安全姿态的重要入口。
void restore_default_pose(void)
{
    strcpy(work, "恢复默认姿态");
    
    const uint8_t *restore_ids = s_restore_pose_ids;
    const int16_t *default_positions = s_restore_pose_positions;
    const size_t servo_count = RESTORE_POSE_SERVO_COUNT;
    int16_t positions[RESTORE_POSE_SERVO_COUNT];
    uint16_t speeds[RESTORE_POSE_SERVO_COUNT];
    uint8_t accs[RESTORE_POSE_SERVO_COUNT];
    
    // 先启用所有舵机的扭矩，确保可以设置角度
    uint8_t torque_success = 0;
    for (size_t i = 0; i < servo_count; i++) {
        int ret = writeByte(restore_ids[i], SMS_STS_TORQUE_ENABLE, 1);
        if (ret) {
            torque_success++;
        }
    }
    vTaskDelay(pdMS_TO_TICKS(50));  // 等待扭矩启用完成
    ESP_LOGI(TAG, "[恢复默认姿态] 扭矩启用：成功%d/%d", torque_success, servo_count);
    
    // 对每个舵机进行限位检查并设置速度和加速度
    for (size_t i = 0; i < servo_count; i++) {
        positions[i] = limit_servo_position(restore_ids[i], default_positions[i]);
        speeds[i] = 2400;  // 使用标准速度
        accs[i] = 50;       // 使用标准加速度
        ESP_LOGI(TAG, "[恢复默认姿态] 舵机%d: 原始=%d, 限位后=%d", restore_ids[i], default_positions[i], positions[i]);
    }
    
    // 使用单个写入方式设置所有舵机位置（更可靠）
    ESP_LOGI(TAG, "[恢复默认姿态] 开始设置角度，舵机数量=%d", servo_count);
    
    // 逐个写入每个舵机（比同步写入更可靠）
    for (size_t i = 0; i < servo_count; i++) {
        ESP_LOGI(TAG, "[恢复默认姿态] 发送: ID=%d, 位置=%d, 速度=%d, 加速度=%d", 
                 restore_ids[i], positions[i], speeds[i], accs[i]);
        int ret = WritePosEx(restore_ids[i], positions[i], speeds[i], accs[i]);
        if (ret) {
            ESP_LOGI(TAG, "[恢复默认姿态] 舵机%d写入成功", restore_ids[i]);
        } else {
            ESP_LOGW(TAG, "[恢复默认姿态] 舵机%d写入失败", restore_ids[i]);
        }
        vTaskDelay(pdMS_TO_TICKS(10));  // 每个舵机之间稍作延时
    }
    
    ESP_LOGI(TAG, "[恢复默认姿态] 所有舵机角度设置完成");
    
    // 更新状态消息
    snprintf(message0, sizeof(message0), "恢复默认姿态：已设置%d个舵机", servo_count);
    ESP_LOGI(TAG, "[恢复默认姿态] 角度设置完成：%s", message0);
}

// 读取全部 20 个舵机当前角度，并把结果同步到全局缓存与网页状态区。
// 同步读取当前所有舵机位置，并把结果回填到全局缓存和状态文本中。
void sync_read_once(void)
{
    // 禁用格式截断警告（snprintf会自动截断，不会溢出）
    #pragma GCC diagnostic push
    #pragma GCC diagnostic ignored "-Wformat-truncation"
    
    // 读取全部 20 个舵机的位置角度
    uint8_t id_list[] = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20};
    const size_t servo_count = sizeof(id_list) / sizeof(id_list[0]);
    uint8_t rxPacket[4];
    int16_t positions[20] = {0};
    bool read_success[20] = {false};
    int success_count = 0;

    strcpy(work, "读取全部舵机角度");

    // 清空接收缓冲区，避免残留数据干扰
    clear_uart_rx_buffer();
    vTaskDelay(pdMS_TO_TICKS(5));  // 简短等待

    // 开始同步读取
    syncReadBegin(servo_count, sizeof(rxPacket));
    
    // 发送同步读取指令
    syncReadPacketTx(id_list, servo_count,
                     SMS_STS_PRESENT_POSITION_L, sizeof(rxPacket));
    
    // 简洁的读取循环，没有复杂重试
    for (size_t i = 0; i < servo_count; i++) {
        uint8_t current_id = id_list[i];
        int16_t Position = 0;
        int16_t Speed = 0;
        bool read_ok = false;
        
        // 尝试从缓冲区解析响应
        if (syncReadPacketRx(current_id, rxPacket)) {
            // 读取成功，解析数据
            Position = syncReadRxPacketToWord(15);
            Speed    = syncReadRxPacketToWord(15);
            read_ok = true;
            
        } else {
            // 同步读取失败，尝试单独读取
            // 清空接收缓冲区，避免残留数据干扰
            clear_uart_rx_buffer();
            vTaskDelay(pdMS_TO_TICKS(5));
            
            // 单独读取位置和速度（每个2字节，共4字节）
            uint8_t rxData[4];
            int read_len = Read(current_id, SMS_STS_PRESENT_POSITION_L, rxData, 4);
            
            if (read_len == 4) {
                // 单独读取成功，解析数据
                Position = SCS2Host(rxData[0], rxData[1]);
                Speed    = SCS2Host(rxData[2], rxData[3]);
                read_ok = true;
            }
        }
        
        if (read_ok) {
            positions[i] = Position;
            read_success[i] = true;
            success_count++;
            (void)Speed;
            
            if (current_id >= 1 && current_id <= 20) {
                servoPos_1to20[current_id - 1] = Position;
            }
        } else {
            read_success[i] = false;
        }
        
        // 每个ID之间简短延迟（仅在失败时）
        if (i + 1 < servo_count) {
            vTaskDelay(pdMS_TO_TICKS(2));  // 短暂延迟
        }
    }

    // 格式化显示消息（注意：message0和message1都是64字节，需要控制长度）
    if (success_count == (int)servo_count) {
        int len0 = snprintf(message0, sizeof(message0), 
                           "角度:1-20 OK");
        if (len0 >= (int)sizeof(message0)) message0[sizeof(message0) - 1] = '\0';
        int len1 = snprintf(message1, sizeof(message1),
                           "成功%d/%d 已读取全部舵机", success_count, (int)servo_count);
        if (len1 >= (int)sizeof(message1)) message1[sizeof(message1) - 1] = '\0';
    } else {
        char detail[64] = {0};
        int n = 0;
        for (size_t i = 0; i < servo_count && n < (int)sizeof(detail) - 10; i++) {
            if (read_success[i]) {
                int ret = snprintf(detail + n, (size_t)(sizeof(detail) - n), 
                                  "%d:%d ", id_list[i], positions[i]);
                if (ret > 0) n += ret;
            } else {
                int ret = snprintf(detail + n, (size_t)(sizeof(detail) - n), 
                                  "%d:失败 ", id_list[i]);
                if (ret > 0) n += ret;
            }
        }
        snprintf(message0, sizeof(message0), 
                 "部分成功:%d/%d", success_count, (int)servo_count);
        memcpy(message1, detail, sizeof(message1) - 1);
        message1[sizeof(message1) - 1] = '\0';
        ESP_LOGW(TAG, "部分舵机读取失败：成功%d/%d", success_count, (int)servo_count);
    }
    
    #pragma GCC diagnostic pop
}

// 以下单舵机接口分别处理对应 ID 的位置写入，并更新网页提示文本。
// 网页 1 号滑块的最终落地入口。
void set_servo_position(int16_t position)
{
    set_single_servo_position(1, "设置舵机位置", "位置", position);
}

// 网页 2 号滑块的最终落地入口。
void set_servo_position_2(int16_t position)
{
    set_single_servo_position(2, "设置2号舵机位置", "2号舵机位置", position);
}

// 网页 3 号滑块的最终落地入口。
void set_servo_position_3(int16_t position)
{
    set_single_servo_position(3, "设置3号舵机位置", "3号舵机位置", position);
}

// 网页 4 号滑块的最终落地入口。
void set_servo_position_4(int16_t position)
{
    set_single_servo_position(4, "设置4号舵机位置", "4号舵机位置", position);
}

// 网页 6 号滑块的最终落地入口。
void set_servo_position_5(int16_t position)
{
    set_single_servo_position(5, "Servo 5 target", "Servo 5", position);
}

void set_servo_position_6(int16_t position)
{
    set_single_servo_position(6, "设置6号舵机位置", "6号舵机位置", position);
}

// 网页 7 号滑块的最终落地入口。
void set_servo_position_7(int16_t position)
{
    set_single_servo_position(7, "设置7号舵机位置", "7号舵机位置", position);
}

// 网页 8 号滑块的最终落地入口。
void set_servo_position_8(int16_t position)
{
    set_single_servo_position(8, "设置8号舵机位置", "8号舵机位置", position);
}

// 网页 9 号滑块的最终落地入口。
void set_servo_position_9(int16_t position)
{
    set_single_servo_position(9, "设置9号舵机位置", "9号舵机位置", position);
}

// 网页 11 号滑块的最终落地入口。
void set_servo_position_10(int16_t position)
{
    set_single_servo_position(10, "Servo 10 target", "Servo 10", position);
}

void set_servo_position_11(int16_t position)
{
    set_single_servo_position(11, "设置11号舵机位置", "11号舵机位置", position);
}

// 网页 12 号滑块的最终落地入口。
void set_servo_position_12(int16_t position)
{
    set_single_servo_position(12, "设置12号舵机位置", "12号舵机位置", position);
}

// 网页 13 号滑块的最终落地入口。
void set_servo_position_13(int16_t position)
{
    set_single_servo_position(13, "设置13号舵机位置", "13号舵机位置", position);
}

// 网页 14 号滑块的最终落地入口。
void set_servo_position_14(int16_t position)
{
    set_single_servo_position(14, "设置14号舵机位置", "14号舵机位置", position);
}

// 网页 16 号滑块的最终落地入口。
void set_servo_position_15(int16_t position)
{
    set_single_servo_position(15, "Servo 15 target", "Servo 15", position);
}

void set_servo_position_16(int16_t position)
{
    set_single_servo_position(16, "设置16号舵机位置", "16号舵机位置", position);
}

// 网页 17 号滑块的最终落地入口。
void set_servo_position_17(int16_t position)
{
    set_single_servo_position(17, "设置17号舵机位置", "17号舵机位置", position);
}

// 网页 18 号滑块的最终落地入口。
void set_servo_position_18(int16_t position)
{
    set_single_servo_position(18, "设置18号舵机位置", "18号舵机位置", position);
}

// 网页 19 号滑块的最终落地入口。
void set_servo_position_19(int16_t position)
{
    set_single_servo_position(19, "设置19号舵机位置", "19号舵机位置", position);
}

// 同步设置 1 号和 2 号舵机的位置，适合做联动调试。
// 一次性同步下发两个舵机位置，用于联动演示或需要同时起步的场景。
void set_servo_position_20(int16_t position)
{
    set_single_servo_position(20, "Servo 20 target", "Servo 20", position);
}

void set_servo_positions_sync(int16_t pos1, int16_t pos2)
{
    strcpy(work, "同步设置舵机位置");
    // 限位检查
    pos1 = limit_servo_position(1, pos1);
    pos2 = limit_servo_position(2, pos2);
    uint8_t id_list[] = {1, 2};
    int16_t positions[] = {pos1, pos2};
    uint16_t speeds[] = {2400, 2400};  
    uint8_t accs[] = {50, 50};        
    
    SyncWritePosEx(id_list, 2, positions, speeds, accs);
    snprintf(message0, sizeof(message0), "同步设置: 1号=%d, 2号=%d", pos1, pos2);
}

// 通过 Ping 检查 1 号舵机是否在线以及通信链路是否正常。
// 发送一次 1 号舵机探测命令，快速验证总线连通性和舵机在线状态。
void ping_servo_id_1(void)
{
    strcpy(work, "Ping ID1");
    
    // 清空接收缓冲区
    clear_uart_rx_buffer();
    vTaskDelay(pdMS_TO_TICKS(5));
    
    int id = Ping(1);
    if (id >= 0 && getLastError() == 0) {
        snprintf(message0, sizeof(message0), "Ping 成功，舵机ID=%d", id);
    } else {
        snprintf(message0, sizeof(message0), "Ping ID1 失败，错误码=%d", getLastError());
        ESP_LOGW(TAG, "Ping 失败，错误码=%d", getLastError());
    }
}
