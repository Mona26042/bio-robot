/*
 * wifi_ctrl.c
 *
 * Wi-Fi AP 初始化实现。
 * 模块职责：负责建立事件循环、配置热点参数并启动 ESP32-S3 的 AP 模式。
 */

#include "wifi_ctrl.h"

#include <string.h>
#include "esp_mac.h"
#include "esp_wifi.h"
#include "esp_event.h"
#include "esp_log.h"
#include "esp_netif.h"
#include "nvs_flash.h"

static const char *TAG = "WIFI_AP";

// AP参数
#define WIFI_SSID      "ESP32_AP"
#define WIFI_PASS      "12345678"
#define MAX_STA_CONN   4

// 处理 AP 模式下的站点连接/断开事件，并输出日志。
static void wifi_event_handler(void *arg, esp_event_base_t event_base,
                               int32_t event_id, void *event_data)
{
    if (event_base == WIFI_EVENT && event_id == WIFI_EVENT_AP_STACONNECTED) {
        wifi_event_ap_staconnected_t *event = (wifi_event_ap_staconnected_t *)event_data;
        ESP_LOGI(TAG, "Device connected, MAC="MACSTR, MAC2STR(event->mac));
    } else if (event_base == WIFI_EVENT && event_id == WIFI_EVENT_AP_STADISCONNECTED) {
        wifi_event_ap_stadisconnected_t *event = (wifi_event_ap_stadisconnected_t *)event_data;
        ESP_LOGI(TAG, "Device disconnected, MAC="MACSTR, MAC2STR(event->mac));
    }
}

// 初始化网络栈、配置 AP 参数，并启动热点服务。
void wifi_init_ap(void)
{
    // 初始化网络栈
    ESP_ERROR_CHECK(esp_netif_init());
    ESP_ERROR_CHECK(esp_event_loop_create_default());

    // 创建 AP
    esp_netif_create_default_wifi_ap();

    wifi_init_config_t cfg = WIFI_INIT_CONFIG_DEFAULT();
    ESP_ERROR_CHECK(esp_wifi_init(&cfg));

    // 注册事件（可选但建议）
    ESP_ERROR_CHECK(esp_event_handler_instance_register(
        WIFI_EVENT,
        ESP_EVENT_ANY_ID,
        &wifi_event_handler,
        NULL,
        NULL));

    // 配置 AP
    wifi_config_t wifi_config = {0};
    strcpy((char *)wifi_config.ap.ssid, WIFI_SSID);
    strcpy((char *)wifi_config.ap.password, WIFI_PASS);
    wifi_config.ap.ssid_len = strlen(WIFI_SSID);
    wifi_config.ap.channel = 1;
    wifi_config.ap.max_connection = MAX_STA_CONN;
    wifi_config.ap.authmode = WIFI_AUTH_WPA2_PSK;

    // 无密码情况
    if (strlen(WIFI_PASS) == 0) {
        wifi_config.ap.authmode = WIFI_AUTH_OPEN;
    }

    // 设置模式
    ESP_ERROR_CHECK(esp_wifi_set_mode(WIFI_MODE_AP));

    // 应用配置
    ESP_ERROR_CHECK(esp_wifi_set_config(WIFI_IF_AP, &wifi_config));

    // 启动
    ESP_ERROR_CHECK(esp_wifi_start());

    ESP_LOGI(TAG, "AP started");
    ESP_LOGI(TAG, "SSID:%s  PASS:%s", WIFI_SSID, WIFI_PASS);
    ESP_LOGI(TAG, "IP: 192.168.4.1");
}
