/*
 * servo_motion.c
 *
 * 这是“演示动作状态机”实现文件。
 * 模块职责：按时间推进单舵机和双舵机的演示状态机。
 * 模块本身不阻塞，也不创建额外任务，而是依赖 main.c 在主循环里周期性调用：
 * 1. write_show_demo()/write_show_demo_2() 负责把状态机置为起始状态。
 * 2. update_servo_motion_state() 根据时间推进单舵机往返动作。
 * 3. start_dual_servo_rotate()/update_dual_rotate_state() 负责双舵机联动演示。
 */

#include "servo_motion.h"
#include "servo_control.h"
#include "common.h"
#include "servo_protocol.h"
#include "esp_log.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include <string.h>

#define work g_sys.ui.work
#define message0 g_sys.ui.message0

static const char *TAG __attribute__((unused)) = "SERVO_MOTION";

// 下面这些全局状态用于保存演示动作的当前阶段和时间戳。
volatile servo_motion_state_t g_servo1_motion_state = SERVO_MOTION_IDLE;
volatile servo_motion_state_t g_servo2_motion_state = SERVO_MOTION_IDLE;
volatile uint32_t g_servo1_motion_start_time = 0;
volatile uint32_t g_servo2_motion_start_time = 0;
volatile uint8_t g_servo1_cycle_count = 0;
volatile uint8_t g_servo2_cycle_count = 0;
volatile dual_rotate_state_t g_dual_rotate_state = DUAL_ROTATE_IDLE;
volatile uint32_t g_dual_rotate_start_time = 0;

// 启动 1 号舵机往返演示。
// 调用后先直接下发一次“朝最大方向运动”的命令，后续切换由 update_servo_motion_state() 完成。
void start_servo1_demo(void)
{
    strcpy(work, "1号舵机演示");

    // 初始化状态机。
    g_servo1_motion_state = SERVO_MOTION_TO_MAX;
    g_servo1_motion_start_time = xTaskGetTickCount();
    g_servo1_cycle_count = 0;

    // 先把目标位置推到理论最大值，再由限位函数裁剪到安全范围。
    int16_t pos = limit_servo_position(1, 4095);
    WritePosEx(1, pos, 2400, 50);
    snprintf(message0, sizeof(message0), "1号舵机开始往返演示");
}

// 启动 2 号舵机往返演示。
// 逻辑与 1 号舵机一致，只是目标 ID 不同。
void start_servo2_demo(void)
{
    strcpy(work, "2号舵机演示");

    g_servo2_motion_state = SERVO_MOTION_TO_MAX;
    g_servo2_motion_start_time = xTaskGetTickCount();
    g_servo2_cycle_count = 0;

    int16_t pos = limit_servo_position(2, 4095);
    WritePosEx(2, pos, 2400, 50);
    snprintf(message0, sizeof(message0), "2号舵机开始往返演示");
}

// 周期性推进 1 号和 2 号舵机的往返状态机。
// 只要主循环持续调用，这里就会在时间到达后自动切换目标方向。
void update_servo_motion_state(void)
{
    uint32_t current_time = xTaskGetTickCount();

    // 处理 1 号舵机的状态机。
    if (g_servo1_motion_state != SERVO_MOTION_IDLE) {
        uint32_t elapsed = current_time - g_servo1_motion_start_time;
        if (elapsed >= pdMS_TO_TICKS(SERVO_MOTION_DURATION_MS)) {
            // 到达保持时间后，说明上一段动作已经完成。
            g_servo1_cycle_count++;
            if (g_servo1_cycle_count >= SERVO_MOTION_MAX_CYCLES) {
                // 演示次数达到上限，状态机归零。
                g_servo1_motion_state = SERVO_MOTION_IDLE;
                snprintf(message0, sizeof(message0), "1号舵机演示结束");
            } else {
                if (g_servo1_motion_state == SERVO_MOTION_TO_MAX) {
                    // 上一段是“去最大值”，下一段切换为“回最小值”。
                    g_servo1_motion_state = SERVO_MOTION_TO_MIN;
                    g_servo1_motion_start_time = current_time;
                    int16_t pos_min = limit_servo_position(1, 0);
                    WritePosEx(1, pos_min, 2400, 50);
                } else if (g_servo1_motion_state == SERVO_MOTION_TO_MIN) {
                    // 上一段是“回最小值”，下一段再次去最大值。
                    g_servo1_motion_state = SERVO_MOTION_TO_MAX;
                    g_servo1_motion_start_time = current_time;
                    int16_t pos_max = limit_servo_position(1, 4095);
                    WritePosEx(1, pos_max, 2400, 50);
                }
            }
        }
    }

    // 处理 2 号舵机的状态机。
    if (g_servo2_motion_state != SERVO_MOTION_IDLE) {
        uint32_t elapsed = current_time - g_servo2_motion_start_time;
        if (elapsed >= pdMS_TO_TICKS(SERVO_MOTION_DURATION_MS)) {
            g_servo2_cycle_count++;
            if (g_servo2_cycle_count >= SERVO_MOTION_MAX_CYCLES) {
                g_servo2_motion_state = SERVO_MOTION_IDLE;
                snprintf(message0, sizeof(message0), "2号舵机演示结束");
            } else {
                if (g_servo2_motion_state == SERVO_MOTION_TO_MAX) {
                    g_servo2_motion_state = SERVO_MOTION_TO_MIN;
                    g_servo2_motion_start_time = current_time;
                    int16_t pos_min = limit_servo_position(2, 0);
                    WritePosEx(2, pos_min, 2400, 50);
                } else if (g_servo2_motion_state == SERVO_MOTION_TO_MIN) {
                    g_servo2_motion_state = SERVO_MOTION_TO_MAX;
                    g_servo2_motion_start_time = current_time;
                    int16_t pos_max = limit_servo_position(2, 4095);
                    WritePosEx(2, pos_max, 2400, 50);
                }
            }
        }
    }

    // 根据当前是否仍有演示任务在运行，刷新 work 文本。
    if (g_servo1_motion_state != SERVO_MOTION_IDLE && g_servo2_motion_state != SERVO_MOTION_IDLE) {
        strcpy(work, "1号/2号舵机演示中");
    } else if (g_servo1_motion_state != SERVO_MOTION_IDLE) {
        strcpy(work, "1号舵机演示中");
    } else if (g_servo2_motion_state != SERVO_MOTION_IDLE) {
        strcpy(work, "2号舵机演示中");
    }
}

// 启动双舵机联动旋转演示。
// 启动后立即进入“向左转”阶段。
void start_dual_servo_rotate(void)
{
    strcpy(work, "双舵机联动");
    g_dual_rotate_state = DUAL_ROTATE_TO_LEFT;
    g_dual_rotate_start_time = xTaskGetTickCount();

    // 两个舵机同步收到相同目标位置，保证动作一致。
    int16_t pos1 = limit_servo_position(1, SERVO_LEFT_90_POS);
    int16_t pos2 = limit_servo_position(2, SERVO_LEFT_90_POS);
    int16_t positions[] = {pos1, pos2};
    uint16_t speeds[] = {2400, 2400};
    uint8_t accs[] = {50, 50};
    uint8_t id_list[] = {1, 2};
    SyncWritePosEx(id_list, 2, positions, speeds, accs);

    snprintf(message0, sizeof(message0), "双舵机联动：先向左转 90 度");
}

// 周期性推进双舵机联动状态机。
// 每到一个阶段的保持时间，就切换到下一个同步目标。
void update_dual_rotate_state(void)
{
    if (g_dual_rotate_state == DUAL_ROTATE_IDLE) {
        return;
    }

    uint32_t current_time = xTaskGetTickCount();
    uint32_t elapsed = current_time - g_dual_rotate_start_time;

    if (elapsed >= pdMS_TO_TICKS(DUAL_ROTATE_DURATION_MS)) {
        uint8_t id_list[] = {1, 2};
        uint16_t speeds[] = {2400, 2400};
        uint8_t accs[] = {50, 50};
        int16_t positions[2];

        switch (g_dual_rotate_state) {
            case DUAL_ROTATE_TO_LEFT:
                // 左转阶段结束后，切换到右转。
                g_dual_rotate_state = DUAL_ROTATE_TO_RIGHT;
                g_dual_rotate_start_time = current_time;
                positions[0] = limit_servo_position(1, SERVO_RIGHT_90_POS);
                positions[1] = limit_servo_position(2, SERVO_RIGHT_90_POS);
                SyncWritePosEx(id_list, 2, positions, speeds, accs);
                snprintf(message0, sizeof(message0), "双舵机联动：切到右转 90 度");
                break;

            case DUAL_ROTATE_TO_RIGHT:
                // 右转阶段结束后，回到中位。
                g_dual_rotate_state = DUAL_ROTATE_TO_CENTER;
                g_dual_rotate_start_time = current_time;
                positions[0] = limit_servo_position(1, SERVO_CENTER_POS);
                positions[1] = limit_servo_position(2, SERVO_CENTER_POS);
                SyncWritePosEx(id_list, 2, positions, speeds, accs);
                snprintf(message0, sizeof(message0), "双舵机联动：回到中位");
                break;

            case DUAL_ROTATE_TO_CENTER:
                // 回中结束后，整个联动演示完成。
                g_dual_rotate_state = DUAL_ROTATE_IDLE;
                snprintf(message0, sizeof(message0), "双舵机联动演示结束");
                strcpy(work, "系统空闲");
                break;

            default:
                g_dual_rotate_state = DUAL_ROTATE_IDLE;
                break;
        }
    }
}
