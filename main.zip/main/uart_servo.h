/*
 * uart_servo.h
 *
 * 舵机 UART 适配层。
 * 模块职责：向协议层暴露统一的 UART 收发与初始化接口。
 * 上层协议模块只关心“收几个字节、发几个字节、延时多久”，
 * 具体 UART1 的初始化和 ESP-IDF 驱动调用都封装在这一层。
 */

#ifndef UART_SERVO_H
#define UART_SERVO_H

#include <stdint.h>
#include "driver/uart.h"

// 当前工程统一使用 UART1 与舵机总线通信。
// 这里的引脚和波特率需要与实际接线保持一致。
#define SERVO_UART       UART_NUM_1
#define SERVO_TX_PIN     39
#define SERVO_RX_PIN     38
#define SERVO_BAUD       1000000
#define UART_BUF_SIZE    256

// 总线级短延时，主要用于发收切换后的稳定等待。
void ftBus_Delay(void);

// 向舵机总线发送原始字节流。
void ftUart_Send(uint8_t *nDat, int nLen);

// 从舵机总线读取指定长度的原始字节流。
int ftUart_Read(uint8_t *nDat, int nLen);

// 初始化舵机使用的 UART1 外设和驱动。
void servo_uart_init(void);

// 清空接收缓冲区，避免历史残包影响下一次协议解析。
void clear_uart_rx_buffer(void);

#endif // UART_SERVO_H
