/*
 * motion_storage.h
 *
 * 动作库存储接口。
 * 模块职责：负责动作文件的保存、加载、改名、删除和列表查询。
 */

#ifndef MOTION_STORAGE_H
#define MOTION_STORAGE_H

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

#include "esp_err.h"

// 存储层允许的动作名长度上限和列表查询最大条目数。
#define MOTION_STORAGE_NAME_MAX_LEN 24
#define MOTION_STORAGE_LIST_MAX 40

// 动作列表接口返回的一条动作摘要信息。
typedef struct {
    char name[MOTION_STORAGE_NAME_MAX_LEN];
    uint16_t frame_count;
    uint32_t total_duration_ms;
    bool is_current;
} stored_motion_info_t;

// 挂载 SPIFFS 并初始化动作库互斥锁与状态缓存。
esp_err_t motion_storage_init(void);
// 查询动作库存储是否已经准备就绪。
bool motion_storage_is_ready(void);
// 查询动作库当前是否正被长时间读写操作占用。
bool motion_storage_is_busy(void);
// 读取当前选中的动作名称。
const char *motion_storage_get_current_motion_name(void);
// 更新当前选中的动作名称；传入空值时回退到默认显示名。
void motion_storage_set_current_motion_name(const char *motion_name);
// 列举存储中的动作文件，并按名称排序写入调用方数组。
size_t motion_storage_list(stored_motion_info_t *entries, size_t max_entries);
// 把当前整套动作缓存保存成新的 JSON 文件。
esp_err_t motion_storage_save_current_full_motion(char *saved_name,
                                                  size_t saved_name_len,
                                                  uint32_t *saved_checksum);
// 从存储加载指定动作，并回填到整套动作缓存。
esp_err_t motion_storage_load_full_motion(const char *motion_name,
                                          uint32_t *loaded_checksum);
// 读取指定动作的完整 JSON 文本。
esp_err_t motion_storage_read_json_full_motion(const char *motion_name,
                                               char **json_text,
                                               size_t *json_len);
// 用新的 JSON 文本覆盖指定动作文件内容。
esp_err_t motion_storage_update_json_full_motion(const char *motion_name,
                                                 const char *json_text,
                                                 uint32_t *saved_checksum);
// 修改动作文件名，同时保持动作内容和校验值一致。
esp_err_t motion_storage_rename_full_motion(const char *motion_name,
                                            const char *new_motion_name,
                                            uint32_t *saved_checksum);
// 删除一条指定名称的动作记录。
esp_err_t motion_storage_delete_full_motion(const char *motion_name);
// 删除存储中的全部动作记录。
esp_err_t motion_storage_delete_all_full_motion(size_t *deleted_count);

#endif // MOTION_STORAGE_H
