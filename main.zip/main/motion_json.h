/*
 * motion_json.h
 *
 * 动作 JSON 编解码接口。
 * 模块职责：把整套动作缓存映射成可存储/传输的 JSON 文档，并提供反向解析入口。
 */

#ifndef MOTION_JSON_H
#define MOTION_JSON_H

#include <stddef.h>
#include <stdint.h>

#include "esp_err.h"

#include "common.h"
#include "motion_storage.h"

// 当前工程保存动作库时使用的 JSON 文档格式版本。
#define MOTION_JSON_FORMAT "motion_v2"

// 一份完整动作 JSON 文档在内存中的展开结构。
typedef struct {
    char name[MOTION_STORAGE_NAME_MAX_LEN];
    uint16_t frame_count;
    uint32_t total_duration_ms;
    uint32_t payload_checksum;
    int16_t (*positions)[FULL_MOTION_SERVO_COUNT];
    uint16_t *dts;
} motion_json_doc_t;

// 仅包含动作摘要信息的轻量级元数据结构。
typedef struct {
    char name[MOTION_STORAGE_NAME_MAX_LEN];
    uint16_t frame_count;
    uint32_t total_duration_ms;
    uint32_t payload_checksum;
} motion_json_metadata_t;

// 用指定动作名和缓存指针初始化一份 JSON 文档对象。
esp_err_t motion_json_doc_init(motion_json_doc_t *doc,
                               const char *motion_name,
                               int16_t (*positions)[FULL_MOTION_SERVO_COUNT],
                               uint16_t *dts);
// 重置 JSON 文档对象内容，清空名称、帧数和缓存指针。
void motion_json_doc_reset(motion_json_doc_t *doc);
// 根据当前帧数据重新计算总时长和载荷校验值。
void motion_json_refresh_doc_derived_fields(motion_json_doc_t *doc);
// 解析完整 JSON 文档，并校验动作名、帧数和校验值是否匹配。
esp_err_t motion_json_parse_document(const char *json_text,
                                     const char *expected_motion_name,
                                     motion_json_doc_t *doc);
// 只提取 JSON 文档中的元数据，不加载完整动作帧。
esp_err_t motion_json_extract_metadata(const char *json_text,
                                       motion_json_metadata_t *metadata);
// 把内存中的动作文档序列化为一段可释放的 JSON 文本。
esp_err_t motion_json_serialize_doc(const motion_json_doc_t *doc,
                                    char **json_text_out);

#endif // MOTION_JSON_H
