/*
 * wifi_ctrl.h
 *
 * Wi-Fi AP 模式初始化接口。
 * 模块职责：向系统提供热点模式初始化入口。
 * 工程启动后会调用这里完成网络栈、事件循环以及 AP 配置。
 */

#ifndef WIFI_CTRL_H
#define WIFI_CTRL_H

// 初始化 Wi-Fi AP 模式。
void wifi_init_ap(void);

#endif // WIFI_CTRL_H
