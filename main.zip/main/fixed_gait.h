/*
 * fixed_gait.h
 *
 * 固定步态模块对外接口。
 * 模块职责：向主控制流程提供一次性固定步态演示的启动入口。
 * 这一层只暴露“启动一次固定步态”的入口，具体关键帧、插值和平滑过渡
 * 由 fixed_gait.c 在后台任务里完成。
 */

#ifndef _FIXED_GAIT_H
#define _FIXED_GAIT_H

#include <stdint.h>
#include <stdbool.h>

// 启动一次左前腿固定步态演示。
// 如果上一次步态任务还没结束，函数会直接忽略本次请求。
void fixed_gait_start(void);

#endif // _FIXED_GAIT_H
