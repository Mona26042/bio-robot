/*
 * command_bus.c
 *
 * 命令总线实现。
 * 模块职责：封装命令队列的创建、发送、接收和状态查询，供网页与主循环解耦使用。
 */

#include "command_bus.h"

#include "esp_log.h"
#include "freertos/queue.h"

static const char *TAG = "COMMAND_BUS";

#define COMMAND_BUS_QUEUE_LENGTH 32
#define COMMAND_BUS_SEND_TIMEOUT_TICKS pdMS_TO_TICKS(10)

static QueueHandle_t s_command_queue = NULL;

// 创建命令队列；重复初始化时直接复用已有队列。
esp_err_t command_bus_init(void)
{
    if (s_command_queue != NULL) {
        return ESP_OK;
    }

    s_command_queue = xQueueCreate(COMMAND_BUS_QUEUE_LENGTH, sizeof(servo_cmd_t));
    if (s_command_queue == NULL) {
        ESP_LOGE(TAG, "Failed to create command queue");
        return ESP_ERR_NO_MEM;
    }

    return ESP_OK;
}

// 把一条控制命令压入队尾，交给主控制任务统一处理。
esp_err_t command_bus_send(servo_cmd_t cmd)
{
    if (cmd == CMD_NONE) {
        return ESP_ERR_INVALID_ARG;
    }

    if (s_command_queue == NULL) {
        ESP_LOGE(TAG, "Command queue is not initialized");
        return ESP_ERR_INVALID_STATE;
    }

    if (xQueueSendToBack(s_command_queue, &cmd, COMMAND_BUS_SEND_TIMEOUT_TICKS) != pdTRUE) {
        ESP_LOGW(TAG, "Command queue full, dropping cmd=%d", (int)cmd);
        return ESP_ERR_TIMEOUT;
    }

    return ESP_OK;
}

// 从命令队列读取一条命令；若队列为空则按超时参数等待。
bool command_bus_receive(servo_cmd_t *cmd, TickType_t timeout_ticks)
{
    if (cmd == NULL || s_command_queue == NULL) {
        return false;
    }

    return xQueueReceive(s_command_queue, cmd, timeout_ticks) == pdTRUE;
}

// 返回当前命令队列里是否还存在未消费命令。
bool command_bus_has_pending(void)
{
    return s_command_queue != NULL && uxQueueMessagesWaiting(s_command_queue) > 0;
}
