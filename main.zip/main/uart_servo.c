/*
 * uart_servo.c
 *
 * 舵机总线 UART 适配层实现。
 * 模块职责：把 ESP-IDF UART 驱动封装成协议层可直接调用的简单函数。
 * 这里把 ESP-IDF 的 uart_* 接口包装成协议模块可以直接调用的简单函数：
 * 发送、接收、短延时、初始化以及清空接收缓冲。
 */

#include "uart_servo.h"
#include "driver/uart.h"
#include "esp_log.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include <string.h>

static const char *TAG = "UART_SERVO";

// 总线收发切换后留一个很短的缓冲时间，减少时序过紧带来的丢包风险。
void ftBus_Delay(void)
{
    vTaskDelay(pdMS_TO_TICKS(2));
}

// 发送原始数据包到舵机总线。
// 遇到同步写指令时会额外输出一条日志，便于排查批量下发问题。
void ftUart_Send(uint8_t *nDat, int nLen)
{
    if (!nDat || nLen <= 0) {
        return;
    }

    // 为了日志可读性，把前一部分字节格式化成十六进制文本。
    char hex_str[512] = {0};
    char *ptr = hex_str;
    int max_chars = sizeof(hex_str) - 1;

    // 日志最多显示前 128 个字节，避免超长同步包刷屏。
    int display_len = (nLen > 128) ? 128 : nLen;
    for (int i = 0; i < display_len && ptr < hex_str + max_chars - 4; i++) {
        int written = snprintf(ptr, hex_str + max_chars - ptr, "%02X ", nDat[i]);
        if (written > 0) {
            ptr += written;
        }
    }

    if (nLen >= 5 && nDat[4] == 0x83) {
        ESP_LOGI(TAG, "UART TX sync write len=%d bytes: %s%s",
                 nLen,
                 hex_str,
                 nLen > display_len ? "..." : "");
    }

    uart_write_bytes(SERVO_UART, (const char *)nDat, nLen);
    // 等待底层发送完成，避免紧接着切换时出现包尾未发完的情况。
    uart_wait_tx_done(SERVO_UART, pdMS_TO_TICKS(20));
}

// 从舵机总线读取指定长度的字节。
// 这里统一使用 100ms 超时，兼顾实时性和兼容性。
int ftUart_Read(uint8_t *nDat, int nLen)
{
    if (!nDat || nLen <= 0) {
        return 0;
    }

    int len = uart_read_bytes(SERVO_UART, nDat, nLen, pdMS_TO_TICKS(100));
    if (len < 0) {
        ESP_LOGE(TAG, "ftUart_Read failed: %d", len);
        return 0;
    }
    return len;
}

// 初始化舵机使用的 UART1。
// 这里把波特率、数据位、停止位等参数一次性配好，并清空接收缓冲。
void servo_uart_init(void)
{
    const uart_config_t cfg = {
        .baud_rate = SERVO_BAUD,
        .data_bits = UART_DATA_8_BITS,
        .parity = UART_PARITY_DISABLE,
        .stop_bits = UART_STOP_BITS_1,
        .flow_ctrl = UART_HW_FLOWCTRL_DISABLE,
        .source_clk = UART_SCLK_APB,
    };

    ESP_ERROR_CHECK(uart_driver_install(SERVO_UART, UART_BUF_SIZE, UART_BUF_SIZE, 0, NULL, 0));
    ESP_ERROR_CHECK(uart_param_config(SERVO_UART, &cfg));
    ESP_ERROR_CHECK(uart_set_pin(SERVO_UART, SERVO_TX_PIN, SERVO_RX_PIN,
                                 UART_PIN_NO_CHANGE, UART_PIN_NO_CHANGE));
    uart_flush(SERVO_UART);
}

// 尽量清空遗留在 UART 驱动里的旧数据。
// 这通常在读写前调用，用来降低“上一帧残包影响下一帧解析”的概率。
void clear_uart_rx_buffer(void)
{
    uint8_t dummy[256];
    int len = uart_read_bytes(SERVO_UART, dummy, sizeof(dummy), pdMS_TO_TICKS(10));

    // -1 代表超时未读到数据，这里不算真正的异常。
    if (len < 0 && len != -1) {
        ESP_LOGW(TAG, "clear_uart_rx_buffer failed: %d", len);
    }
}
